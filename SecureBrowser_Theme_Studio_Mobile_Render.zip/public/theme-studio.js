/* Secure Browser Theme Studio. .SBT = SBT1 header + validated versioned JSON with embedded image assets. */
(()=>{'use strict';
 const KINDS=['start','search','logo'],IMAGE_TYPES=['image/png','image/jpeg','image/webp','image/gif'],MAX_FILE=8*1024*1024,MAX_ASSET=1_100_000;
 const COLOR_FIELDS=[['accent','Accent'],['background','Background'],['surface','Cards / search bars'],['text','Text'],['muted','Secondary text'],['border','Borders'],['buttonText','Button text']];
 const DEFAULT={name:'My Custom Theme',style:'glass',opacity:78,radius:24,dim:28,colors:{accent:'#65adff',background:'#101a2e',surface:'#203451',text:'#f4f8ff',muted:'#b5c8de',border:'#829eb5',buttonText:'#ffffff'}};
 let modal=null,draft=null,originalId=null,blobs={},objectURLs={},activeURLs={},applying=0,wasCustom=false,previewTab='start',focusBefore=null,wheelKey='accent',wheelHSV={h:210,s:60,v:100},previewUserChoice=false,previousBodyOverflow=null;
 const $id=id=>document.getElementById(id);
 const themeById=id=>Array.isArray(S.customThemes)?S.customThemes.find(t=>t.id===id):null;
 const safeColor=v=>typeof v==='string'&&/^#[\da-f]{6}$/i.test(v);
 const cleanTheme=(data)=>{
  if(!data||typeof data!=='object'||Array.isArray(data))throw Error('Invalid theme settings');
  if(typeof data.name!=='string'||!data.name.trim()||data.name.length>60)throw Error('Theme name must be between 1 and 60 characters');
  const colors={};for(const [key] of COLOR_FIELDS){if(!safeColor(data.colors?.[key]))throw Error('Invalid color: '+key);colors[key]=data.colors[key].toLowerCase();}
  const style=data.style;if(!['glass','solid','aero'].includes(style))throw Error('Unsupported theme finish');
  const intRange=(key,min,max)=>{const value=data[key];if(!Number.isInteger(value)||value<min||value>max)throw Error('Invalid '+key);return value;};
  return {name:data.name.trim(),style,opacity:intRange('opacity',20,100),radius:intRange('radius',8,40),dim:intRange('dim',0,80),colors};
 };
 function makeId(){return 'sbt-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);}
 function recordToTheme(base,id){return {...cleanTheme(base),id};}
 const setVar=(el,key,v)=>el.style.setProperty('--sbt-'+key,v);
 async function imageBlob(id,kind){try{return await dbGetK('sbt:'+id+':'+kind)||null;}catch{return null;}}
 function assetURL(blob){return blob?URL.createObjectURL(blob):null;}
 function revokeAll(map){for(const url of Object.values(map))if(url)URL.revokeObjectURL(url);}
 function uploadFile(file){return new Promise((resolve,reject)=>{
  if(!IMAGE_TYPES.includes(file.type))return reject(Error('Use a PNG, JPG, WebP, or GIF image'));
  if(file.size>MAX_FILE)return reject(Error('Image is too large (8 MB maximum)'));
  if(file.type==='image/gif')return file.size<=MAX_ASSET?resolve(file):reject(Error('Animated GIFs must be under 1.1 MB'));
  const temp=URL.createObjectURL(file),img=new Image();
  img.onload=()=>{URL.revokeObjectURL(temp);const scale=Math.min(1,2400/Math.max(img.naturalWidth,img.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
   const ctx=canvas.getContext('2d');if(!ctx){reject(Error('Image processing is unavailable'));return;}ctx.drawImage(img,0,0,canvas.width,canvas.height);
   let quality=.79,downscales=0;
   const encode=()=>canvas.toBlob(blob=>{if(blob&&blob.size<=MAX_ASSET){resolve(blob);return;}
    if(quality>.39){quality-=.15;encode();return;}
    if(downscales<2){downscales++;canvas.width=Math.max(1,Math.round(canvas.width*.76));canvas.height=Math.max(1,Math.round(canvas.height*.76));ctx.drawImage(img,0,0,canvas.width,canvas.height);quality=.7;encode();return;}
    reject(Error('Could not fit image in a theme file; try a smaller image'));
   },'image/webp',quality);
   encode();};
  img.onerror=()=>{URL.revokeObjectURL(temp);reject(Error('Image could not be loaded'));};img.src=temp;
 });}
 function loadStyle(theme){const r=document.documentElement;for(const [k,v] of Object.entries(theme.colors))setVar(r,k,v);setVar(r,'bg',theme.colors.background);setVar(r,'alpha',theme.opacity+'%');setVar(r,'radius',theme.radius+'px');setVar(r,'dim',theme.dim/100);r.dataset.sbtStyle=theme.style;}
 async function applyCustom(){const request=++applying,theme=themeById(S.appearance),R=document.documentElement;
  if(!theme){R.removeAttribute('data-sbt-style');R.style.removeProperty('--sbt-start-image');if(wasCustom){wasCustom=false;const bg=$id('bgm');if(bg)loadBg();}return;}
  wasCustom=true;R.dataset.appearance='custom';R.classList.toggle('light',false);loadStyle(theme);R.style.setProperty('--accent',theme.colors.accent);
  const media=$id('bgm');if(media){media.pause();media.hidden=true;}
  const fresh={};for(const k of KINDS)fresh[k]=assetURL(await imageBlob(theme.id,k));
  if(request!==applying){revokeAll(fresh);return;}
  revokeAll(activeURLs);activeURLs=fresh;
  if(fresh.start)R.style.setProperty('--sbt-start-image',`url("${fresh.start}")`);else R.style.removeProperty('--sbt-start-image');
  try{document.querySelector('meta[name="theme-color"]').content=theme.colors.background;}catch{}
 }
 window.SBT_applyAppearance=applyCustom;
 async function setImages(id,files){for(const kind of KINDS){const key='sbt:'+id+':'+kind;try{if(files[kind])await dbPutK(key,files[kind]);else await dbDelK(key);}catch(err){throw Error('Could not save '+kind+' image to device storage');}}}
 function rebuildOptions(){if(!Array.isArray(S.customThemes))S.customThemes=[];
  for(let i=THEMES.length-1;i>=0;i--)if(THEMES[i][0].startsWith('sbt-'))THEMES.splice(i,1);
  for(const t of S.customThemes)THEMES.push([t.id,'★ '+t.name]);
  for(const name of ['appearsel','sstheme']){const sel=$id(name);sel.querySelectorAll('[data-sbt-custom]').forEach(o=>o.remove());
   for(const t of S.customThemes){const o=document.createElement('option');o.value=t.id;o.textContent='★ '+t.name;o.dataset.sbtCustom='1';sel.append(o);}
   const add=document.createElement('option');add.dataset.sbtCustom='1';add.value='__create__';add.textContent='＋ Create custom theme…';sel.append(add);
  }
  $id('appearsel').value=S.appearance;$id('sstheme').value=S.ssTheme||'';
 }
 function updateButtons(){const current=themeById(S.appearance)||themeById(S.ssTheme);
  $id('sbt-edit').disabled=!current;$id('sbt-export').disabled=!current;$id('sbt-share').disabled=!current;$id('sbt-edit').title=current?'Edit '+current.name:'Select a custom theme first';}
 function node(tag,cls,content){const el=document.createElement(tag);if(cls)el.className=cls;if(content!==undefined)el.textContent=content;return el;}
 function uploadRow(kind,title,sub){const row=node('div','sbt-image-row'),im=node('img','sbt-image-thumb');im.alt='';const info=node('div','sbt-image-label',title);info.append(node('small',null,sub));const upload=node('button',null,'Choose');upload.type='button';const remove=node('button','sbt-remove','✕');remove.type='button';remove.title='Remove '+title;const input=node('input');input.type='file';input.accept='image/png,image/jpeg,image/webp,image/gif';input.hidden=true;
  const update=()=>{im.src=objectURLs[kind]||'assets/image-4928151514d8.png';remove.disabled=!blobs[kind];};
  upload.onclick=()=>input.click();remove.onclick=()=>{if(objectURLs[kind])URL.revokeObjectURL(objectURLs[kind]);blobs[kind]=null;objectURLs[kind]=null;update();updatePreview();};
  input.onchange=async()=>{const file=input.files?.[0];input.value='';if(!file)return;try{const processed=await uploadFile(file);if(objectURLs[kind])URL.revokeObjectURL(objectURLs[kind]);blobs[kind]=processed;objectURLs[kind]=assetURL(processed);update();updatePreview();}catch(e){toast(e.message);}};
  row.append(im,info,upload,remove,input);update();return row;
 }
 function toHSV(hex){const n=parseInt(hex.slice(1),16),r=((n>>16)&255)/255,g=((n>>8)&255)/255,b=(n&255)/255,max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min;let h=0;if(d){switch(max){case r:h=((g-b)/d)%6;break;case g:h=(b-r)/d+2;break;default:h=(r-g)/d+4;}h=(h*60+360)%360;}return {h,s:max?100*d/max:0,v:max*100};}
 function fromHSV(h,s,v){s/=100;v/=100;const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let r=0,g=0,b=0;if(h<60){r=c;g=x;}else if(h<120){r=x;g=c;}else if(h<180){g=c;b=x;}else if(h<240){g=x;b=c;}else if(h<300){r=x;b=c;}else{r=c;b=x;}return '#'+[r,g,b].map(n=>Math.max(0,Math.min(255,Math.round((n+m)*255))).toString(16).padStart(2,'0')).join('');}
 function setWheelKey(key){wheelKey=key;wheelHSV=toHSV(draft.colors[key]);renderWheel();}
 function renderWheel(){const root=$id('sbt-wheel-panel');if(!root)return;for(const [k,label] of COLOR_FIELDS){if(k===wheelKey)$id('sbt-wheel-title').textContent=label;}
  for(const item of modal.querySelectorAll('.sbt-color-item'))item.classList.toggle('active',item.dataset.sbtColor===wheelKey);
  const wheel=$id('sbt-wheel'),marker=$id('sbt-wheel-marker'),radius=wheel.clientWidth/2-10,rad=wheelHSV.h*Math.PI/180;
  marker.style.transform=`translate(-50%,-50%) translate(${Math.sin(rad)*radius}px,${-Math.cos(rad)*radius}px)`;
  wheel.style.setProperty('--wheel-color',draft.colors[wheelKey]);
  $id('sbt-wheel-sat').value=Math.round(wheelHSV.s);$id('sbt-wheel-val').value=Math.round(wheelHSV.v);$id('sbt-wheel-hex').value=draft.colors[wheelKey].toUpperCase();
 }
 function applyWheel(){draft.colors[wheelKey]=fromHSV(wheelHSV.h,wheelHSV.s,wheelHSV.v);const input=modal.querySelector('.sbt-color-item[data-sbt-color="'+wheelKey+'"] input[type=color]');if(input)input.value=draft.colors[wheelKey];updatePreview();renderWheel();}
 function makeWheel(){const wrap=node('div','sbt-wheel-panel');wrap.id='sbt-wheel-panel';wrap.innerHTML='<div class="sbt-wheel-title">Color wheel <span id="sbt-wheel-title">Accent</span></div><div class="sbt-wheel-flex"><div id="sbt-wheel" tabindex="0" role="slider" aria-label="Hue wheel" aria-valuemin="0" aria-valuemax="359"><div id="sbt-wheel-core"></div><div id="sbt-wheel-marker"></div></div><div class="sbt-wheel-right"><label for="sbt-wheel-sat">Saturation</label><input type="range" id="sbt-wheel-sat" min="0" max="100"><label for="sbt-wheel-val">Brightness</label><input type="range" id="sbt-wheel-val" min="0" max="100"><label for="sbt-wheel-hex">HEX color</label><input type="text" id="sbt-wheel-hex" maxlength="7" spellcheck="false"></div></div>';
  const wheel=wrap.querySelector('#sbt-wheel');let pointer=null;
  const point=e=>{const rect=wheel.getBoundingClientRect(),x=e.clientX-(rect.left+rect.width/2),y=e.clientY-(rect.top+rect.height/2);wheelHSV.h=(Math.atan2(y,x)*180/Math.PI+450)%360;wheel.setAttribute('aria-valuenow',String(Math.round(wheelHSV.h)));applyWheel();};
  wheel.addEventListener('pointerdown',e=>{pointer=e.pointerId;wheel.setPointerCapture(e.pointerId);point(e);});wheel.addEventListener('pointermove',e=>{if(pointer===e.pointerId)point(e);});wheel.addEventListener('pointerup',()=>pointer=null);wheel.addEventListener('pointercancel',()=>pointer=null);
  wheel.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowDown','ArrowRight','ArrowUp'].includes(e.key)){e.preventDefault();wheelHSV.h=(wheelHSV.h+((e.key==='ArrowRight'||e.key==='ArrowUp')?3:357))%360;applyWheel();}});
  wrap.querySelector('#sbt-wheel-sat').oninput=e=>{wheelHSV.s=Number(e.target.value);applyWheel();};wrap.querySelector('#sbt-wheel-val').oninput=e=>{wheelHSV.v=Number(e.target.value);applyWheel();};wrap.querySelector('#sbt-wheel-hex').onchange=e=>{if(safeColor(e.target.value)){draft.colors[wheelKey]=e.target.value.toLowerCase();wheelHSV=toHSV(draft.colors[wheelKey]);applyWheel();}else renderWheel();};
  return wrap;
 }
 function addSlider(parent,label,key,min,max,units){const wrap=node('div');const lab=node('label',null,label);const row=node('div','sbt-range');const input=node('input');input.type='range';input.min=min;input.max=max;input.value=draft[key];const output=node('output',null,String(draft[key])+units);input.oninput=()=>{draft[key]=Number(input.value);output.textContent=input.value+units;updatePreview();};row.append(input,output);wrap.append(lab,row);parent.append(wrap);}
 function updatePreview(){if(!draft||!modal)return;const preview=$id('sbt-preview');if(!preview)return;
  const v=draft.colors;for(const [k,c] of Object.entries(v))preview.style.setProperty('--p-'+(k==='background'?'bg':k==='buttonText'?'button':k),c);
  preview.style.setProperty('--p-radius',draft.radius+'px');preview.style.setProperty('--p-alpha',(draft.style==='solid'?100:draft.opacity)+'%');preview.style.setProperty('--p-dim',draft.dim+'%');preview.style.setProperty('--p-image',`url("${objectURLs[previewTab==='search'?'search':'start']||objectURLs.start||'assets/image-4928151514d8.png'}")`);
  const page=$id('sbt-p-page');page.classList.toggle('search',previewTab==='search');
  $id('sbt-p-clock').replaceChildren();if(previewTab==='search'){const img=node('img');img.alt='';img.src=objectURLs.logo||'assets/secure-search-icon.webp';$id('sbt-p-clock').append(img,document.createTextNode('Secure Search'));}else $id('sbt-p-clock').textContent='10:24';
  $id('sbt-p-placeholder').textContent=previewTab==='search'?'Search or ask a question…':'Search the web…';
  $id('sbt-p-tiles').replaceChildren();for(const label of (previewTab==='search'?['All','Images','Videos']:['🌐','▶','★']))$id('sbt-p-tiles').append(node('i',null,label));
  $id('sbt-p-title').textContent=previewTab==='search'?'Secure Search':'New Tab';
  for(const b of modal.querySelectorAll('[data-sbt-preview]'))b.classList.toggle('active',b.dataset.sbtPreview===previewTab);
 }
 function clearDraft(){revokeAll(objectURLs);objectURLs={};blobs={};draft=null;originalId=null;}
 function mobileStudio(){return document.documentElement.classList.contains('phone-ui')||window.matchMedia('(max-width:700px)').matches;}
 function setPreviewCollapsed(collapsed){if(!modal)return;const area=modal.querySelector('.sbt-preview-area'),toggle=$id('sbt-toggle-preview');area.classList.toggle('preview-collapsed',collapsed);toggle.setAttribute('aria-expanded',String(!collapsed));toggle.textContent=collapsed?'Show preview':'Hide preview';}
 function syncStudioLayout(){if(!modal)return;const mobile=mobileStudio();modal.classList.toggle('sbt-mobile',mobile);if(!mobile)setPreviewCollapsed(false);else if(!previewUserChoice)setPreviewCollapsed(window.innerHeight<530);}
 function closeEditor(){if(!modal)return;modal.hidden=true;if(previousBodyOverflow!==null){document.body.style.overflow=previousBodyOverflow;previousBodyOverflow=null;}clearDraft();try{focusBefore?.focus({preventScroll:true});}catch{}}
 async function openEditor(id=null){focusBefore=document.activeElement;clearDraft();const src=id?themeById(id):null;originalId=src?.id||null;draft=src?structuredClone(cleanTheme(src)):structuredClone(DEFAULT);
  for(const kind of KINDS){blobs[kind]=src?await imageBlob(src.id,kind):null;objectURLs[kind]=assetURL(blobs[kind]);}
  if(!modal)buildModal();previewUserChoice=false;syncStudioLayout();if(previousBodyOverflow===null)previousBodyOverflow=document.body.style.overflow;document.body.style.overflow='hidden';modal.hidden=false;renderControls();updatePreview();
  if(mobileStudio()){modal.querySelector('.sbt-content').scrollTop=0;}else $id('sbt-name').focus({preventScroll:true});
 }
 async function saveDraft(){try{const validated=cleanTheme(draft),id=originalId||makeId();await setImages(id,blobs);const idx=S.customThemes.findIndex(t=>t.id===id),theme={...validated,id};if(idx<0)S.customThemes.push(theme);else S.customThemes[idx]=theme;
  S.appearance=id;if(S.ssTheme===id||!S.ssTheme)S.ssTheme='';save();
  if(!JSON.parse(localStorage.getItem('sb-web-v2')||'{}').customThemes?.some(t=>t.id===id))throw Error('Browser storage is full — the theme was not saved');
  rebuildOptions();applyTheme();applySS();updateButtons();closeEditor();toast('Theme saved and applied');return id;
 }catch(err){toast(err.message||'Could not save theme');return null;}}
 function blobToDataURL(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('Could not read theme image'));reader.readAsDataURL(blob);});}
 async function makeSBT(theme,images){const clean=cleanTheme(theme),assets={};for(const k of KINDS)assets[k]=images[k]?await blobToDataURL(images[k]):null;
  const doc={format:'SecureBrowserTheme',version:1,theme:clean,assets};return new Blob(['SBT1\n',JSON.stringify(doc)],{type:'application/x-secure-browser-theme'});
 }
 function themeFilename(name){return (name.replace(/[^a-z\d _-]/gi,'').trim().replace(/\s+/g,'_').slice(0,48)||'Custom_Theme')+'.SBT';}
 function triggerDownload(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=themeFilename(name);document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);}
 async function exportTheme(theme,images){try{const b=await makeSBT(theme,images);triggerDownload(b,theme.name);toast('Theme exported as .SBT — ready to share');}catch(e){toast(e.message||'Could not export theme');}}
 async function exportSelected(){const t=themeById(S.appearance)||themeById(S.ssTheme);if(!t)return toast('Select a custom theme first');const files={};for(const k of KINDS)files[k]=await imageBlob(t.id,k);await exportTheme(t,files);}
 async function shareTheme(theme,images){try{const blob=await makeSBT(theme,images),file=new File([blob],themeFilename(theme.name),{type:'application/x-secure-browser-theme'});
  if(navigator.canShare?.({files:[file]})&&navigator.share){try{await navigator.share({title:theme.name+' — Secure Browser theme',files:[file]});return;}catch(e){if(e.name==='AbortError')return;}}
  triggerDownload(blob,theme.name);toast('Saved .SBT file — send it to a friend to share your theme');
 }catch(e){toast(e.message||'Could not share the theme');}}
 async function shareSelected(){const t=themeById(S.appearance)||themeById(S.ssTheme);if(!t)return toast('Select a custom theme first');const files={};for(const k of KINDS)files[k]=await imageBlob(t.id,k);await shareTheme(t,files);}
 function dataURLtoBlob(s){if(s===null||s===undefined)return null;
  if(typeof s!=='string'||s.length>2_000_000)throw Error('Image data is not valid');const m=s.match(/^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z\d+/]+={0,2})$/);if(!m)throw Error('Theme contains an unsupported image');
  const binary=atob(m[2]);if(binary.length>MAX_ASSET)throw Error('Theme image is too large');const out=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)out[i]=binary.charCodeAt(i);return new Blob([out],{type:m[1]});
 }
 async function importSBT(file){if(!file)return;try{
  if(file.size>MAX_FILE)throw Error('Theme file must be under 8 MB');if(!/\.sbt$/i.test(file.name))throw Error('Choose a .SBT theme file');
  const raw=await file.text();if(!raw.startsWith('SBT1\n'))throw Error('Not a Secure Browser .SBT theme');
  const doc=JSON.parse(raw.slice(5));if(doc?.format!=='SecureBrowserTheme'||doc.version!==1)throw Error('Unsupported .SBT version');
  const settings=cleanTheme(doc.theme);if(!doc.assets||typeof doc.assets!=='object')throw Error('Missing theme assets');
  const images={};for(const k of KINDS)images[k]=dataURLtoBlob(doc.assets[k]);
  const id=makeId();await setImages(id,images);S.customThemes.push({...settings,id});S.appearance=id;S.ssTheme='';save();
  if(!JSON.parse(localStorage.getItem('sb-web-v2')||'{}').customThemes?.some(t=>t.id===id))throw Error('Browser storage is full — the theme was not saved');
  rebuildOptions();applyTheme();applySS();updateButtons();closeEditor();toast('Imported and applied: '+settings.name);
 }catch(e){toast('Import failed: '+(e.message||'Invalid theme file'));}}
 async function removeTheme(){if(!originalId)return;const t=themeById(originalId);if(!t||!confirm('Delete the custom theme "'+t.name+'" from this device?'))return;
  for(const k of KINDS)try{await dbDelK('sbt:'+originalId+':'+k);}catch{}S.customThemes=S.customThemes.filter(x=>x.id!==originalId);
  if(S.appearance===originalId)S.appearance='glass';if(S.ssTheme===originalId)S.ssTheme='';save();rebuildOptions();applyTheme();applySS();updateButtons();closeEditor();toast('Theme deleted');
 }
 function renderControls(){const body=$id('sbt-controls');body.replaceChildren();const nameLab=node('label',null,'Theme name');const name=node('input');name.id='sbt-name';name.type='text';name.maxLength=60;name.value=draft.name;name.placeholder='Name your theme';name.oninput=()=>{draft.name=name.value;};body.append(nameLab,name);
  const finishLab=node('label',null,'Visual finish');const finish=node('select');for(const [k,v] of [['glass','Liquid Glass'],['solid','Solid'],['aero','Frutiger Aero']]){const o=node('option',null,v);o.value=k;finish.append(o);}finish.value=draft.style;finish.onchange=()=>{draft.style=finish.value;updatePreview();};body.append(finishLab,finish);
  const colors=node('fieldset'),legend=node('legend',null,'Colors'),grid=node('div','sbt-colors');for(const [k,label] of COLOR_FIELDS){const item=node('div','sbt-color-item'),inp=node('input');item.dataset.sbtColor=k;inp.type='color';inp.value=draft.colors[k];inp.setAttribute('aria-label',label+' color');inp.oninput=()=>{draft.colors[k]=inp.value;wheelKey=k;wheelHSV=toHSV(draft.colors[k]);updatePreview();renderWheel();};const select=node('button','sbt-pick-wheel','◉');select.type='button';select.title='Edit '+label+' on color wheel';select.setAttribute('aria-label',select.title);select.onclick=()=>setWheelKey(k);item.append(inp,node('span',null,label),select);grid.append(item);}colors.append(legend,grid,makeWheel());body.append(colors);setWheelKey('accent');
  addSlider(body,'Surface opacity','opacity',20,100,'%');addSlider(body,'Corner roundness','radius',8,40,'px');addSlider(body,'Background dimming','dim',0,80,'%');
  const images=node('fieldset');images.append(node('legend',null,'Custom artwork'),node('p','sbt-hint','Images are packaged in the .SBT file so your friends receive the same theme.'));images.append(uploadRow('start','Start page wallpaper','Your browser home screen'),uploadRow('search','Secure Search wallpaper','Optional; uses start wallpaper if empty'),uploadRow('logo','Secure Search logo','Optional; keeps original logo if empty'));body.append(images);
  $id('sbt-delete').hidden=!originalId;
 }
 function buildModal(){modal=node('div');modal.id='sbt-modal';modal.hidden=true;modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-label','Create custom browser theme');
  modal.innerHTML=`<div class="sbt-studio"><div class="sbt-heading"><div><strong>✦ Theme Studio</strong><small>Build and share your own Secure Browser theme</small></div><button id="sbt-close" type="button">✕ Close</button></div><div class="sbt-content"><div class="sbt-controls" id="sbt-controls"></div><div class="sbt-preview-area"><div class="sbt-preview-top"><strong>Live preview</strong><button id="sbt-toggle-preview" type="button" aria-expanded="true" aria-controls="sbt-preview-body">Hide preview</button><div class="sbt-preview-tabs"><button type="button" class="active" data-sbt-preview="start">Start page</button><button type="button" data-sbt-preview="search">Secure Search</button></div></div><div class="sbt-preview-body" id="sbt-preview-body"><div id="sbt-preview"><div class="sbt-p-top"><div class="sbt-p-dots"><i></i><i></i><i></i></div><span class="sbt-p-tab" id="sbt-p-title">New Tab</span><span class="sbt-p-plus">＋</span></div><div class="sbt-p-toolbar"><span>←</span><span>→</span><div class="sbt-p-address">🔒 securebrowser://home</div><span>☆</span></div><div class="sbt-p-page" id="sbt-p-page"><div class="sbt-p-page-inner"><div class="sbt-p-clock" id="sbt-p-clock">10:24</div><div class="sbt-p-search"><span id="sbt-p-placeholder">Search the web…</span><b>⌕</b></div><div class="sbt-p-tiles" id="sbt-p-tiles"><i>🌐</i><i>▶</i><i>★</i></div></div></div></div><div class="sbt-p-note">Preview updates instantly as you adjust colors, rounded corners, transparency, and images. Save &amp; Apply changes your real browser.</div></div></div></div><div class="sbt-actions"><button id="sbt-delete" class="sbt-danger" type="button">Delete theme</button><span class="sbt-spacer"></span><button id="sbt-share-draft" type="button">Share .SBT</button><button id="sbt-export-draft" type="button">Export .SBT</button><button id="sbt-save" class="sbt-primary" type="button">Save &amp; Apply</button></div></div>`;
  document.body.append(modal);$id('sbt-close').onclick=closeEditor;$id('sbt-toggle-preview').onclick=()=>{previewUserChoice=true;setPreviewCollapsed(!modal.querySelector('.sbt-preview-area').classList.contains('preview-collapsed'));};$id('sbt-save').onclick=saveDraft;$id('sbt-export-draft').onclick=()=>exportTheme(draft,blobs);$id('sbt-share-draft').onclick=()=>shareTheme(draft,blobs);$id('sbt-delete').onclick=removeTheme;
  modal.addEventListener('pointerdown',e=>{if(e.target===modal)closeEditor();});modal.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();closeEditor();}});
  for(const button of modal.querySelectorAll('[data-sbt-preview]'))button.onclick=()=>{previewTab=button.dataset.sbtPreview;updatePreview();};
 }
 function initialize(){if(!Array.isArray(S.customThemes))S.customThemes=[];
  S.customThemes=S.customThemes.filter(t=>{try{cleanTheme(t);return typeof t.id==='string'&&/^sbt-[\w-]{4,60}$/.test(t.id);}catch{return false;}});
  if(!themeById(S.appearance)&&!['glass','solid','aero','oled','aurora','paper','terminal'].includes(S.appearance)){S.appearance='glass';save();}
  rebuildOptions();const buttons=node('div');buttons.id='sbt-shortcuts';
  const create=node('button',null,'✦ Create theme'),edit=node('button',null,'Edit theme'),imp=node('button',null,'Import .SBT'),exp=node('button',null,'Export .SBT'),share=node('button',null,'Share .SBT');
  edit.id='sbt-edit';exp.id='sbt-export';share.id='sbt-share';create.onclick=()=>openEditor();edit.onclick=()=>openEditor(themeById(S.appearance)?.id||themeById(S.ssTheme)?.id);exp.onclick=exportSelected;share.onclick=shareSelected;
  const inp=node('input');inp.type='file';inp.accept='.sbt,application/x-secure-browser-theme';inp.id='sbt-file-input';imp.onclick=()=>inp.click();inp.onchange=async()=>{const f=inp.files?.[0];inp.value='';await importSBT(f);};
  buttons.append(create,edit,imp,exp,share,inp);const panel=$id('panel');panel.insertBefore(buttons,panel.querySelector('label[for="sstheme"]').nextElementSibling.nextElementSibling);
  window.SBT_openEditor=openEditor;window.SBT_chooseCreate=()=>openEditor();window.SBT_refresh=()=>{rebuildOptions();updateButtons();};
  $id('appearsel').addEventListener('change',()=>{updateButtons();});$id('sstheme').addEventListener('change',updateButtons);
  updateButtons();window.addEventListener('resize',()=>{if(modal&&!modal.hidden)syncStudioLayout();},{passive:true});if(themeById(S.appearance))applyTheme();
 }
 initialize();
})();
