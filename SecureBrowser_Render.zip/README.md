# Secure Browser for Render

The supplied Secure Browser app, ported to a persistent Node.js web service. Original tabs, themes, bookmarks, Secure Search, Input Summary content gate, media search and YouTube handling are retained.

## Deploy on Render

1. Extract the ZIP and upload the contents to a GitHub, GitLab or Bitbucket repository. Keep `package.json`, `package-lock.json`, `server.js`, `render.yaml` and `public/` at the repository root. Do not upload `node_modules` or secrets.
2. In https://dashboard.render.com select **New → Blueprint**, then connect the repository. Render reads `render.yaml`.
3. Review the plan before deploying. The blueprint selects **0.5 CPU / 512 MB**, an always-on **paid** web service (`plan: 0.5c-512mb`). Review Render's current price. You can change the plan to `free` for testing, subject to the limits below.
4. Deploy, wait for the `/healthz` check to pass, then open your assigned `https://…onrender.com` URL.
5. On iPhone/iPad, open the new URL in Safari and add it to the Home Screen again. Bookmarks and settings are stored per browser origin; data from the old Netlify address does not automatically transfer.

For manual **Web Service** setup, use the Dockerfile included at the root of the ZIP:

| Setting | Value |
| --- | --- |
| Runtime | Docker |
| Dockerfile path | `./Dockerfile` |
| Docker build context | `.` |
| Health check | `/healthz` |
| Docker command | Leave blank; the Dockerfile starts Node |
| Environment | `NODE_ENV=production` |

Deploy the whole project as a Web Service. A Static Site cannot run the proxy or APIs. The ZIP now includes a real text Dockerfile and a Docker-based render.yaml. No separate iframe add-on, rewrite rule or Netlify function is needed. Render supplies HTTPS and `PORT`; the server binds to `0.0.0.0:$PORT`.

## Docker parse error: unknown instruction PK

PK is the ZIP signature. This means a deployment tool supplied the compressed archive itself as the Dockerfile. This package contains a real text Dockerfile at its root. In a source-ZIP upload flow, use the archive as the source bundle and select ./Dockerfile as the Dockerfile path. If the field accepts a Dockerfile rather than a source archive, a ZIP cannot be used in that field. Render itself documents Git-source or prebuilt-image deployment; an intermediary ZIP uploader must unpack the source before building.

## Changes

- One Express process serves the UI, `/proxy` and all six existing `/api/*` routes.
- Removed Netlify functions, configuration, CLI dependency and hard-coded backend address.
- Increased the default upstream deadline from 8.5 to 30 seconds.
- Streams media, images, fonts, JSON and downloads with backpressure instead of buffering every response. Default stream limit is 256 MiB per response, replacing the old 5.5 MiB cap.
- Preserves 206 status, Content-Range and Accept-Ranges for media seeking. Partial HTML/CSS/JS is fetched in full before rewriting.
- Bounds rewritten documents to 12 MiB and active proxy requests to 16. Busy requests return 503 with Retry-After.
- Cancels upstream requests on client disconnect, adds a health check, and drains connections during shutdown.
- Rewrites inline module imports alongside existing HTML, CSS and external module rewriting.
- Keeps third-party pages sandboxed. Cookie/storage reads that throw receive disposable per-document storage. This does not persist logins, send cookies upstream or expose the browser shell's saved data.
- Makes retry / original-site fallback available on desktop as well as Apple Home Screen mode.
- Preserves the Input Summary keyword content gate. It is a heuristic for summaries, not a comprehensive content/browsing filter.

## Iframe and reliability limits

Render hosts the backend; its hosting headers do not override another website's iframe policy. This app uses its existing rewriting proxy to fetch and display eligible pages.

This remains a best-effort web proxy, not a full remote browser. Websites requiring real-origin cookies, authentication, service workers, dynamically constructed module URLs, WebSockets, DRM, passkeys, CAPTCHAs or anti-bot clearance can still fail or appear incomplete. Use the toolbar's external-link button or **Open original website** for those sites. Existing iPhone YouTube/Safari handling is retained.

The iframe intentionally omits `allow-same-origin` when sharing the app's origin. Adding it would let third-party scripts access the shell's saved data. Use the original site for passwords and sensitive forms, as the existing app UI advises.

Render Free services sleep after 15 idle minutes and can take about a minute to restart. They may also be suspended for unusually high outbound traffic. A paid always-on service avoids free-tier sleeping; it does not eliminate upstream blocking. Monitor bandwidth and memory. Reduce concurrency/size limits for a small instance or increase capacity for heavier usage.

## Configuration

Set variables in Render's Environment panel. `.env.example` documents these; `npm start` does not automatically load `.env`. Locally you can use `node --env-file=.env server.js`.

| Variable | Default | Purpose |
| --- | --- | --- |
| PORT | 3000 locally | Render supplies the public listening port |
| PROXY_TIMEOUT_MS | 30000 | Total upstream deadline, capped at 120000 ms |
| PROXY_MAX_REWRITE_MB | 12 | Buffered HTML/CSS/JS limit, capped at 32 MiB |
| PROXY_MAX_STREAM_MB | 256 | Streaming limit per response, capped at 1024 MiB |
| PROXY_MAX_BODY_MB | 10 | Request body limit, capped at 32 MiB |
| PROXY_MAX_CONCURRENT | 16 | Active proxy requests, capped at 128 |
| ALLOWED_HOSTS | unset | Optional comma-separated allowed domains, including subdomains; include required asset/CDN hosts |
| YOUTUBE_API_KEY | unset | Optional official metadata/search key; existing public fallback remains |

The proxy blocks private/loopback destinations and checks DNS at connection time. Browser cookies and credentials are not forwarded upstream. There is no user authentication or per-user rate limiter; concurrency and response limits bound per-instance resource use. A public deployment exposes a public proxy. Use the domain allow-list or an authenticated access layer for restricted use. The allow-list affects `/proxy`, not existing search providers.

## Local use

```sh
npm ci
npm test
npm start
```

Open http://localhost:3000. Opening the HTML as a file does not start the server APIs.

The test suite covers existing summaries/media/filter behavior and proxy health/UI routes, rewriting, large-file streaming, byte ranges, partial stylesheet refetch, redirects, private targets, POST bodies, HEAD/204, CORS, size limits and timeouts. Proxy tests use controlled upstream fixtures; passing tests do not mean every public website works.

This ZIP has not been deployed to Render. After deployment, check `/healthz`, browse a basic website, follow a link, try Secure Search and verify the fallback. Render networking and iOS behavior require testing on those platforms.

## References

- [Render Express deployment](https://render.com/docs/deploy-node-express-app)
- [Web services and port binding](https://render.com/docs/web-services)
- [Blueprint settings](https://render.com/docs/blueprint-spec)
- [Free-tier limitations](https://render.com/docs/free)
- [Iframe restrictions](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/X-Frame-Options)

## iPhone search scrolling update

Secure Search now constrains the page width, disables horizontal page panning/overscroll and preserves vertical scrolling plus pinch zoom. Search categories fit on one row on small screens, and 16px search inputs avoid focus-triggered iPhone zoom. Wide result text wraps within the viewport.

## Phone-only Customize update

On iPhone and Android phones, Customize is a scrollable bottom sheet under half the screen height. Minimize/Expand keeps the start page visible while editing. Adding an image, video or text automatically minimizes the sheet; choosing a background also reveals the preview. Done ends layout editing. Phone item editors include size and horizontal/vertical position sliders. iPad and desktop retain their original sidebar and controls.


## Tabs and welcome setup update

Customize now has **Vertical tabs** (side rail, collapsible with the ‹ button) and **Tab containers**, both off by default. Containers are named, color-coded tab sets: long-press the + button to open a tab in one, or use a tab's long-press menu to move it. Containers organize tabs only; the proxy does not keep separate cookies or storage per container. A first-launch welcome flow chooses theme, style, accent, clock, dimming, wallpaper and tab options; run it again from Customize.


## Wallpapers and Secure Search themes

Customize and the welcome setup offer four built-in wallpapers (Dusk, Aurora, Ocean, Nebula) next to the upload button. The Secure Search theme setting adds Midnight OLED, Aurora, Paper and Terminal packs on top of the Glass, Solid and Frutiger Aero styles; "Match style" keeps the current look.


## Theme dropdowns and wallpaper quality

Start page theme and Secure Search theme are now dropdowns offering Glass, Solid, Frutiger Aero, Midnight OLED, Aurora, Paper and Terminal. Secure Search follows the start page theme unless it has its own. Wallpapers no longer get a CSS filter or oversized layer unless blur is turned on, and the built-in ones are 1440×3120.


## Auto-open broken pages

When a page fails to load, stays blank, or takes more than 20 seconds, Secure Browser now opens the original site in Safari (or a new tab outside the iPhone Home Screen app) automatically. Turn this off in Customize → Tabs. If the browser blocks the automatic open, the old "Open in Safari" card still appears.
