# Secure Browser for Render

> **Render error `"/SecureBrowser_Render.zip": not found`?** Your Render service is building an older Dockerfile that tries to copy a ZIP archive. Extract this project ZIP, replace the actual repository files (especially `Dockerfile`), and redeploy the newest commit with a cleared build cache. See [RENDER_DEPLOY_FIX.md](RENDER_DEPLOY_FIX.md).

The supplied Secure Browser app, ported to a persistent Node.js web service. Original tabs, themes, bookmarks, Secure Search, Input Summary content gate, media search and YouTube handling are retained.

## New: Error Center, smarter Input Summary, and advanced theme controls

- **Custom Error Center:** a branded, theme-aware error page for confirmed website errors such as 404, 403, 5xx, unreachable sites and timeouts. Provides Retry, Go Home, Open Original, copy-address and expandable troubleshooting information. `public/error.html` includes an original inline vector illustration until custom images are supplied.
- **Smarter Input Summary:** switch between Quick read and Detailed extracts, copy cited information and page links, toggle linked sources, and click suggested follow-up searches. Answers continue to come from accessible source text rather than an invented AI answer. Inappropriate queries remain excluded from Input Summary.
- **Advanced Theme Studio:** separate toolbar/background/text colors, toolbar opacity, tab roundness, rounded/serif/monospace fonts, classic/chevron/long toolbar icon sets, start search position, and full/subtle/off animation controls. Each option appears in the editor’s real-page previews and is persisted in `.SBT` exports.
- **Older `.SBT` files remain supported.** Added properties have validated defaults; shared files still use the original version 1 `.SBT` container.

**Error detection limitations:** cross-origin pages loaded in direct iframe mode can prevent the browser from observing errors; the most dependable custom error detection uses normal Secure Browser proxy mode. Websites may also return HTTP 200 with their own misleading error content, which cannot reliably be identified as an error. There is no third-party AI model configured; Input Summary remains source-extractive.

**Quick check:** `/error.html?code=404&url=https%3A%2F%2Fexample.org%2Fmissing` shows an example error. To customize a theme, use **Customize → Create theme**, then scroll to **Advanced customization**.

## Deploy on Render

1. Extract the ZIP and upload the contents to a GitHub, GitLab or Bitbucket repository. Keep `package.json`, `package-lock.json`, `server.js`, `render.yaml` and `public/` at the repository root. Do not upload `node_modules` or secrets.
2. In https://dashboard.render.com select **New → Blueprint**, then connect the repository. Render reads `render.yaml`.
3. Review the plan before deploying. The blueprint selects **0.5 CPU / 512 MB**, an always-on **paid** web service (`plan: 0.5c-512mb`). Review Render's current price. You can change the plan to `free` for testing, subject to the limits below.
4. Deploy, wait for the `/healthz` check to pass, then open your assigned `https://…onrender.com` URL.
5. On iPhone/iPad, open the new URL in Safari and add it to the Home Screen again. Bookmarks and settings are stored per browser origin; data from the old Netlify address does not automatically transfer.

For manual **Web Service** setup, use the Dockerfile included at the root of the ZIP:

| Setting | Value |
| --- | --- |
| Runtime | Docker |
| Dockerfile path | `./Dockerfile` |
| Docker build context | `.` |
| Health check | `/healthz` |
| Docker command | Leave blank; the Dockerfile starts Node |
| Environment | `NODE_ENV=production` |

Deploy the whole project as a Web Service. A Static Site cannot run the proxy or APIs. The ZIP now includes a real text Dockerfile and a Docker-based render.yaml. No separate iframe add-on, rewrite rule or Netlify function is needed. Render supplies HTTPS and `PORT`; the server binds to `0.0.0.0:$PORT`.

## Docker parse error: unknown instruction PK

PK is the ZIP signature. This means a deployment tool supplied the compressed archive itself as the Dockerfile. This package contains a real text Dockerfile at its root. In a source-ZIP upload flow, use the archive as the source bundle and select ./Dockerfile as the Dockerfile path. If the field accepts a Dockerfile rather than a source archive, a ZIP cannot be used in that field. Render itself documents Git-source or prebuilt-image deployment; an intermediary ZIP uploader must unpack the source before building.

## Changes

- One Express process serves the UI, `/proxy` and all six existing `/api/*` routes.
- Removed Netlify functions, configuration, CLI dependency and hard-coded backend address.
- Increased the default upstream deadline from 8.5 to 30 seconds.
- Streams media, images, fonts, JSON and downloads with backpressure instead of buffering every response. Default stream limit is 256 MiB per response, replacing the old 5.5 MiB cap.
- Preserves 206 status, Content-Range and Accept-Ranges for media seeking. Partial HTML/CSS/JS is fetched in full before rewriting.
- Bounds rewritten documents to 12 MiB and active proxy requests to 16. Busy requests return 503 with Retry-After.
- Cancels upstream requests on client disconnect, adds a health check, and drains connections during shutdown.
- Rewrites inline module imports alongside existing HTML, CSS and external module rewriting.
- Keeps third-party pages sandboxed. Cookie/storage reads that throw receive disposable per-document storage. This does not persist logins, send cookies upstream or expose the browser shell's saved data.
- Makes retry / original-site fallback available on desktop as well as Apple Home Screen mode.
- Preserves the Input Summary keyword content gate. It is a heuristic for summaries, not a comprehensive content/browsing filter.

## Iframe and reliability limits

Render hosts the backend; its hosting headers do not override another website's iframe policy. This app uses its existing rewriting proxy to fetch and display eligible pages.

This remains a best-effort web proxy, not a full remote browser. Websites requiring real-origin cookies, authentication, service workers, dynamically constructed module URLs, WebSockets, DRM, passkeys, CAPTCHAs or anti-bot clearance can still fail or appear incomplete. Use the toolbar's external-link button or **Open original website** for those sites. Existing iPhone YouTube/Safari handling is retained.

The iframe intentionally omits `allow-same-origin` when sharing the app's origin. Adding it would let third-party scripts access the shell's saved data. Use the original site for passwords and sensitive forms, as the existing app UI advises.

Render Free services sleep after 15 idle minutes and can take about a minute to restart. They may also be suspended for unusually high outbound traffic. A paid always-on service avoids free-tier sleeping; it does not eliminate upstream blocking. Monitor bandwidth and memory. Reduce concurrency/size limits for a small instance or increase capacity for heavier usage.

## Configuration

Set variables in Render's Environment panel. `.env.example` documents these; `npm start` does not automatically load `.env`. Locally you can use `node --env-file=.env server.js`.

| Variable | Default | Purpose |
| --- | --- | --- |
| PORT | 3000 locally | Render supplies the public listening port |
| PROXY_TIMEOUT_MS | 30000 | Total upstream deadline, capped at 120000 ms |
| PROXY_MAX_REWRITE_MB | 12 | Buffered HTML/CSS/JS limit, capped at 32 MiB |
| PROXY_MAX_STREAM_MB | 256 | Streaming limit per response, capped at 1024 MiB |
| PROXY_MAX_BODY_MB | 10 | Request body limit, capped at 32 MiB |
| PROXY_MAX_CONCURRENT | 16 | Active proxy requests, capped at 128 |
| ALLOWED_HOSTS | unset | Optional comma-separated allowed domains, including subdomains; include required asset/CDN hosts |
| YOUTUBE_API_KEY | unset | Optional official metadata/search key; existing public fallback remains |

The proxy blocks private/loopback destinations and checks DNS at connection time. Browser cookies and credentials are not forwarded upstream. There is no user authentication or per-user rate limiter; concurrency and response limits bound per-instance resource use. A public deployment exposes a public proxy. Use the domain allow-list or an authenticated access layer for restricted use. The allow-list affects `/proxy`, not existing search providers.

## Local use

```sh
npm ci
npm test
npm start
```

Open http://localhost:3000. Opening the HTML as a file does not start the server APIs.

The test suite covers existing summaries/media/filter behavior and proxy health/UI routes, rewriting, large-file streaming, byte ranges, partial stylesheet refetch, redirects, private targets, POST bodies, HEAD/204, CORS, size limits and timeouts. Proxy tests use controlled upstream fixtures; passing tests do not mean every public website works.

This ZIP has not been deployed to Render. After deployment, check `/healthz`, browse a basic website, follow a link, try Secure Search and verify the fallback. Render networking and iOS behavior require testing on those platforms.

## References

- [Render Express deployment](https://render.com/docs/deploy-node-express-app)
- [Web services and port binding](https://render.com/docs/web-services)
- [Blueprint settings](https://render.com/docs/blueprint-spec)
- [Free-tier limitations](https://render.com/docs/free)
- [Iframe restrictions](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/X-Frame-Options)

## iPhone search scrolling update

Secure Search now constrains the page width, disables horizontal page panning/overscroll and preserves vertical scrolling plus pinch zoom. Search categories fit on one row on small screens, and 16px search inputs avoid focus-triggered iPhone zoom. Wide result text wraps within the viewport.

## Phone-only Customize update

On iPhone and Android phones, Customize is a scrollable bottom sheet under half the screen height. Minimize/Expand keeps the start page visible while editing. Adding an image, video or text automatically minimizes the sheet; choosing a background also reveals the preview. Done ends layout editing. Phone item editors include size and horizontal/vertical position sliders. iPad and desktop retain their original sidebar and controls.


## Tabs and welcome setup update

Customize now has **Vertical tabs** (side rail, collapsible with the ‹ button) and **Tab containers**, both off by default. Containers are named, color-coded tab sets: long-press the + button to open a tab in one, or use a tab's long-press menu to move it. Containers organize tabs only; the proxy does not keep separate cookies or storage per container. A first-launch welcome flow chooses theme, style, accent, clock, dimming, wallpaper and tab options; run it again from Customize.


## Wallpapers and Secure Search themes

Customize and the welcome setup offer four built-in wallpapers (Dusk, Aurora, Ocean, Nebula) next to the upload button. The Secure Search theme setting adds Midnight OLED, Aurora, Paper and Terminal packs on top of the Glass, Solid and Frutiger Aero styles; "Match style" keeps the current look.


## Theme dropdowns and wallpaper quality

Start page theme and Secure Search theme are now dropdowns offering Glass, Solid, Frutiger Aero, Midnight OLED, Aurora, Paper and Terminal. Secure Search follows the start page theme unless it has its own. Wallpapers no longer get a CSS filter or oversized layer unless blur is turned on, and the built-in ones are 1440×3120.


## Auto-open broken pages

When a page fails to load, stays blank, or takes more than 20 seconds, Secure Browser now opens the original site in Safari (or a new tab outside the iPhone Home Screen app) automatically. Turn this off in Customize → Tabs. If the browser blocks the automatic open, the old "Open in Safari" card still appears.


## Sandboxed pages and Cache Storage

Proxied sites run in a sandbox without allow-same-origin on purpose, which blocks Cache Storage and service workers and made some sites crash on startup. The proxy runtime now provides in-memory stand-ins for window.caches and navigator.serviceWorker (nothing is saved between visits). Redeploy the server for this to take effect.


## Speed

GET redirects are followed on the server (each hop is still checked), DNS answers are cached for 60 seconds, rewritten pages and static files are gzip-compressed, images in /assets are cached for a day, and the default concurrent proxy requests went from 16 to 40. If you set PROXY_MAX_CONCURRENT in the Render dashboard, change it there too.


## Page error log

Customize has a "Copy recent page errors" button. It copies the last 30 uncaught script errors from websites (page address, message, script and line) so a broken site can be diagnosed.

## Custom Theme Studio and `.SBT` sharing

Open **Customize → Start page theme → ＋ Create custom theme…** (or **✦ Create theme** directly beneath the theme selectors). The Theme Studio includes:

- Named themes, with Glass, Solid, or Frutiger Aero finishes.
- Seven editable colors with both native color pickers and a built-in **color wheel**, saturation/brightness sliders, and HEX editing.
- Surface opacity, rounded corners, and wallpaper dimming controls.
- Separate images for the Start Page and Secure Search, plus an optional Secure Search logo. PNG, JPG, WebP, and small GIF images are supported. Static uploads are resized/converted to WebP when needed and re-encoded to avoid distributing embedded photo metadata. Images are stored in IndexedDB, not localStorage.
- A live mini-browser preview with **Start page** and **Secure Search** tabs. The real app changes only when you choose **Save & Apply**.
- **Edit theme**, **Delete theme**, **Export .SBT**, **Share .SBT** (native share sheet where supported), and **Import .SBT**. New/imported themes appear in both theme dropdowns. Select **Match start page** if Secure Search should use the same custom theme.

`.SBT` files are Secure Browser's own `SBT1`-prefixed, versioned JSON format. They embed the theme's color settings and image assets, so sending the file to someone transfers the whole design. Opening an `.SBT` in a different browser will **not** install it as a browser theme; import it from Secure Browser's Customize panel. The file is **not encrypted or DRM-protected**, and text tools can inspect its JSON.

Theme files must be under 8 MB; individual images are limited to about 1.1 MB after processing. Animated GIFs above this limit are rejected to preserve animation. Only trusted image MIME types and approved color/appearance values are accepted by the importer; imported files cannot run arbitrary JavaScript or CSS.

Themes are saved locally to the current browser origin. If you clear site data, reinstall as a different origin, or move to a different device, import a previously exported `.SBT` to restore your design. The `.SBT` transfer is client-side and does not require a Render database or server-side account.

### Theme Studio on phones

Theme Studio automatically switches to a mobile layout when Secure Browser detects a phone (including phones in landscape) or when its window is narrow. The compact Start Page / Secure Search preview appears above scrollable theme controls; on taller phones it remains visible while scrolling. Tap **Hide preview** for more editing space or **Show preview** to bring it back. Short landscape displays start with the preview hidden to maximize space. Save & Apply, Share .SBT, and Export .SBT stay accessible at the bottom, with safe-area padding for notched devices. The existing .SBT format and desktop theme editor are unchanged.


### Polished wallpaper editor (latest update)

The Theme Studio now displays large wallpaper cards that accept taps/clicks or drag-and-drop. Uploading a background **updates the actual mini-browser preview** after image processing, automatically selects its corresponding Start Page or Secure Search preview tab, and displays a checkmarked upload confirmation. A **Change wallpaper** button also appears inside the preview. On desktop, you may paste a copied image into the open Theme Studio. Use **Image sizing** (fill screen or fit entire image) and **Image position** to control how images appear in the preview, actual Start Page, and Secure Search. A separate optional Search logo is still available.

When saved, background images are stored in the browser's IndexedDB database, and are included in `.SBT` exports. Previous `.SBT` files remain importable; new files include optional sizing and positioning fields with safe defaults. On iOS, Photos/Files can also offer HEIC/HEIF images if the current browser supports decoding them; converted static images are stored in a portable format. Image processing feedback prevents saving/exporting an unfinished upload. Existing mobile support and Render deployment configuration remain intact.


## Pixel-matched Theme Studio previews (Nov 2026)

Theme Studio no longer draws a separate imaginary browser mockup. Its Start Page preview
uses the same CSS and actual Start Page DOM as the main browser, and Secure Search
previews its actual `secure-search.html` page and `theme-search.css`.

Use the Start Page / Secure Search tabs, Desktop / Phone toggle, and Full screen
control to see the page before saving. Color, wallpaper fit and position, dimming,
surface opacity, and corner size are set using the same CSS variables as the live
layout. Save & Apply applies the theme to both Start Page and Secure Search;
custom themes still export and import as `.SBT` files.

### Custom theme tab button color
Theme Studio now includes **Tab button background** in Colors & surfaces. It controls the filled browser tab strip, the New Tab (+) button, and Secure Search category tabs (All, Images, Videos, Maps). Active and hover buttons are subtly accent-tinted rather than being transparent/outline-only. The color appears in both real-page previews and is saved in exported `.SBT` themes. Old `.SBT` files remain importable and default their tab color to the theme's card/surface color.

### Built-in error page demo (`ERR.test`)

Enter `ERR.test` in the browser's address bar, on the Start Page, or into Secure Search to open a **local** preview of the Custom Error Center. The first page shows **404 (Not Found)**. The browser's refresh button, Ctrl/Cmd+R, the tab menu's Reload command, and the error page's **Next Error** button advance through the 11 supported error states; after the final connection error the sequence returns to 404. A full browser tab refresh (F5) also restores and advances the current demo on the same device. This special address does **not** contact a real website; it exists only inside Secure Browser. Use **Go Home** to exit.

## Satellite maps (Maps tab)

- The existing Secure Search **Maps** tab now opens an interactive **satellite-imagery map** rather than the old OpenStreetMap street-map embed. Place results, search queries, selected-place markers, the list of locations, and the **View on OpenStreetMap** links remain unchanged.
- Drag to pan, scroll/pinch or use +/- to zoom, use the target button to recenter, and toggle optional place labels. Controls support phone-sized screens. Satellite view is the default and does not require a user account.
- Place discovery still uses the existing OpenStreetMap-backed results. Imagery and labels come from **Esri World Imagery** and **World Boundaries and Places** services. The personal-use map layout has no visible source overlay. The tiles require internet connectivity and are supplied by an external service; their availability and geographic resolution vary.
- **Licensing:** Esri's public World Imagery services have service terms and usage restrictions. Check [Esri's terms](https://www.esri.com/en-us/legal/terms/web-site-service) before commercial or large-scale deployment; a commercial license or paid provider may be necessary. Neither imagery nor tiles are packaged in the project.
- Implementation is self-contained in `public/satellite-map.html`, `public/satellite-map.js`, and `public/satellite-math.js`; no extra map JavaScript CDN, token, or npm package is needed.


### Satellite close-up zoom

The satellite Maps view now zooms to level 23 and automatically falls back to lower-resolution imagery when the selected area has no high-resolution coverage. Zooming beyond the source imagery resolution magnifies pixels rather than inventing new satellite detail. Extra footer text beneath the map has been removed. The on-map credits overlay is removed in the personal-use layout; refer to the provider notice below.

## Clean satellite map interface

The Maps panel no longer displays the map-provider text as a bottom-of-map banner. The previous **ⓘ map information** button is removed, along with its popup and the extra map-only footer. Provider source details are retained in `MAP_SOURCES.md` for reference when configuring licensing/attribution. Note that a separate browser description may not satisfy Esri's near-map attribution requirements. The rest of the map (zoom up to level 23, gestures, label toggle, marker and recenter) is unchanged.

## Satellite zoom: missing-data tile fix

The satellite map now appends `?blankTile=false` to ArcGIS imagery and label tile requests. Some missing Esri tiles previously returned HTTP 200 with a graphic saying “Map Data Not Yet Available”; this request flag changes them into a missing tile response. The existing parent-tile fallback then enlarges the best available imagery instead of displaying the placeholder graphic, including at zoom 23. The sharpness depends on coverage in the selected region. The external map source still needs an internet connection.

Run `node tests/satellite-map.test.cjs` and `node tests/satellite-map-interaction.test.cjs` for regression tests.

## Secure Browser Apps & Secure Maps (Nov 2026)

- The Start Page now has an **Apps** button. The browser-owned catalog in `public/secure-apps.js` lists approved apps; Secure Maps is the first entry. Add future apps to this catalog (with their local HTML pages) and they will appear in the launcher.
- Secure Maps (`/secure-maps.html`) opens inside a native Secure Browser tab. It has a full-page, zoomable **Esri World Imagery** satellite map, a left-hand search panel backed by the existing Photon/OSM `api/media?kind=maps`, recentering, a copyable location URL, and desktop/mobile layouts.
- The **Panoramax** toggle displays photo coverage over the same Esri map (blue photo markers and short sequence connections). Clicking a marker, or choosing **View nearby street photo**, opens a panorama beside the satellite map. The 360° Panoramax viewer uses the official `@panoramax/web-viewer` library and federated public catalogue. Panoramax supports photo-to-photo movement where sequences are available; it is not rendered 3D geometry.
- Secure Maps remembers the last chosen location locally; Share Map copies an address preserving the current location. Existing Secure Search Maps remains unchanged apart from a shortcut to open the selected location in Secure Maps.
- **Panoramax photos are community-submitted** and coverage varies by region. No Google API key is needed. The client uses `/api/panoramax/nearby?bbox=west,south,east,north`, a bounded, cached server-side proxy to `https://api.panoramax.xyz/api/search`; no arbitrary URL can be supplied. The photo renderer is fetched at runtime from jsDelivr, so that CDN and the Panoramax instance must be accessible on the deployed browser.
- Existing Render Docker support, `.SBT` Theme Studio, custom backgrounds, Input Summary, `ERR.test`, and satellite maps are retained.

### Attribution/licensing

Esri imagery and individual Panoramax photographs have their own attribution and reuse conditions. Public deployment or redistribution must comply with those conditions. Photos and site labels remain subject to source accuracy, availability, and outages. Panoramax viewer built-in metadata/credits should be retained as required by photo licenses. See `MAP_SOURCES.md` and Panoramax project documentation.

### Quick verification

```
node --test tests/secure-maps.test.cjs
npm test
```

The full Render/proxy integration suite needs `npm ci` in an environment with network access. Automated tests cover the STAC query route, bounds validation, app routing, existing feature compatibility, and response handling. Satellite imagery and Panoramax viewer remote services must also be checked after Render deploy.


## Secure Maps: Mapillary + Panoramax blue Street View coverage (November 2026)

The Start Page **Apps** launcher includes **Secure Maps**. It opens directly into the full-screen Esri satellite map (up to zoom 23) with a small floating search box. Searching opens a scrollable list just below the search box, and selecting a place centers the map. The full-width sidebar and top information bar have been removed. The bottom-right **Street View** button is black translucent glass, matching the black glass zoom/recenter/labels buttons. It toggles the blue Mapillary roads and photo dots plus Panoramax photo coverage. Clicking a blue line/dot opens street-level imagery without any extra View button.

### Mapillary access

Secure Maps uses the **default Mapillary client token** already included in this version. There is no in-app API key button or edit form. The owner of the Render deployment can optionally set `MAPILLARY_CLIENT_TOKEN` in Render's environment settings to replace the built-in client token without changing the UI. Only client tokens should be used; the token is visible to browsers making imagery requests.

Street View coverage is on by default (unless previously switched off); click the black glass **Street View** control to toggle blue Mapillary sequences and Panoramax photos. Sequence lines can appear at zoom 6+, Mapillary image dots at zoom 14+, and Panoramax markers at zoom 11+, subject to provider coverage and connectivity.

### Files added or changed

- `public/mapillary-vector.js`: minimal self-contained vector-tile decoder for Mapillary sequence and photo point layers; no extra npm dependencies.
- `public/secure-mapillary.html`: MapillaryJS street-level image viewer, loaded on demand from the official npm CDN.
- `public/satellite-map.js`: toggled blue imagery overlay, Mapillary vector-tile loading and tile caching, clickable provider features, while retaining Esri and Panoramax.
- `public/secure-maps.html`, `public/secure-maps.js`, `public/secure-maps.css`: floating search with scrollable results, one glass Street View control, split-view viewer, mobile support.
- `server.js`: optional public Mapillary client-token config route.
- `tests/mapillary-coverage.test.cjs`: decoder fixture and integration checks.

Third-party imagery providers' licenses and attribution rules apply even for personal projects; sources and links are in `MAP_SOURCES.md`.


## Default Mapillary coverage key / blue roads fix (November 2026)

- Secure Maps now comes with the provided **Mapillary client access token** configured by default. No extra token entry is required for a fresh install. The `MAPILLARY_CLIENT_TOKEN` Render environment variable still overrides the packaged default; the API key editor has been removed from Secure Maps.
- Street View Coverage is **on by default** in the Secure Maps app; click the coverage button to hide it, and the preference is remembered.
- Mapillary sequence features draw blue road paths **without requiring an image ID**. This fixes legitimate photo-covered roads previously missing from the overlay.
- Blue road clicks search for an actual nearby photo rather than trying to treat a sequence ID as a photo ID. When no nearby photo is found, the map zooms to photo-detail level and lets you choose a dot.
- Dense Mapillary tile responses up to 8 MiB are accepted by the in-browser decoder, with the existing fetch and memory limits retained.
- A client token shipped with a public web app is publicly visible. Only use a **client** token, not a private user or secret token. If needed, replace/rotate the token in Mapillary's developer portal.

The code checks and offline test fixtures passed. Live Mapillary API connectivity and the supplied key's status could not be verified in this environment; confirm the blue layer after deployment.

### Faster map zoom
Secure Maps now caches satellite tiles between zoom levels and avoids redownloading duplicate fallback tiles. When zooming quickly it displays already-loaded imagery immediately, then fetches sharper tiles for the settled zoom. Mapillary/Panoramax blue streets are kept aligned while the map moves, with stale Mapillary requests cancelled when the viewport changes. These improvements do not change available imagery resolution.


### November 2026: Mapillary blue-road reliability fix
- Street View Coverage now starts enabled on each Secure Maps load (old saved off state no longer silently disables it).
- Coverage tiles are loaded through a bounded, same-origin `/api/mapillary/tile/:z/:x/:y` endpoint, with a direct Mapillary fallback. This reduces cross-origin and browser-blocking failures.
- Parent and satellite-map iframe resynchronize the Mapillary token and coverage state on load to avoid missing the startup message.
- Genuine Mapillary road sequences show as blue lines, image points at close zoom, and overview dots at wide zoom.
- If the Mapillary client token is rejected or the imagery service is unreachable, Secure Maps displays an error instead of silently pretending there is no coverage. Temporary network errors retry automatically.
- The existing black glass map controls, Esri satellite caching, Panoramax, `.SBT` themes, and other browser systems are unchanged.
- Live Mapillary response availability must be tested on your deployed Render instance; a token with invalid permissions cannot be fixed by rendering code alone.

### Street View + map dragging update
The latest Secure Maps update fixes the map resetting while being dragged and improves Mapillary blue road coverage. The Street View toggle overlays real Mapillary sequence tiles and Panoramax image coverage on the Esri satellite map. Mapillary roads load first from lightweight coverage tiles. Selecting a road resolves its nearest real image through the browser's Render backend. The map still requires reachable Esri, Mapillary and Panoramax services and a valid Mapillary client token.

### Street View coverage troubleshooting

Secure Maps combines the Esri satellite base with Mapillary and Panoramax street-level coverage. The blue overlay requires geotagged imagery from Mapillary/Panoramax **at the current map location**; Google Street View imagery is not included.

The new fallback obtains real Mapillary image coordinates from `/api/mapillary/photos?bbox=...` when the public vector tile lines are absent. On-map messages report when there are no photos in view, or when Mapillary returns an error. If no blue dots appear, zoom out a few levels; if the status reports an authentication problem, confirm the Mapillary client token is active in your developer dashboard.

For comparison, inspect the same coordinates at https://www.mapillary.com/app/ with all captures visible. The Mapillary Graph API requires a working client token; the default token has not been tested against Mapillary in this offline environment.
