# Satellite map source references

- Satellite imagery: Esri World Imagery. Sources include Esri, Vantor, Earthstar Geographics, and the GIS User Community (credits can vary by tile/location).
- Place search: OpenStreetMap contributors, via the existing geocoding provider.
- Provider policy: https://location.arcgis.com/help/licensing-and-attribution/
- Source copyright: https://www.openstreetmap.org/copyright

The personal map interface currently hides in-app credits. Esri states that attribution is required with Esri basemaps even for private-use applications. A credit only in a separate browser description may not meet those terms. This document is for reference, not a substitute for complying with the provider's attribution requirements.

### Secure Maps street imagery
- Panoramax STAC API: https://api.panoramax.xyz/api
- Panoramax viewer documentation: https://docs.panoramax.fr/web-viewer/
- Photo copyright, author, and license details depend on the selected image. The Panoramax photo viewer supplies source metadata and built-in credits as appropriate.
- Secure Maps displays photo point coverage from Panoramax separately from Esri World Imagery tiles; no Google Street View or Google Maps integration is used.
