# Render Docker error fix — Secure Browser Theme Studio

## What the error means

`failed to calculate checksum ... "/SecureBrowser_Render.zip": not found` means the **Dockerfile that Render actually used** contains a `COPY` or `ADD` instruction for a file named `SecureBrowser_Render.zip` that is absent from the Docker build context (or excluded by `.dockerignore`).

This project does **not** need a ZIP file inside the Docker build. Its bundled `Dockerfile` copies the extracted source code directly and does not reference `SecureBrowser_Render.zip`.

## Fix your Render service

1. Download the corrected project ZIP and **extract it locally**.
2. In your GitHub/GitLab repository connected to Render, upload/replace the extracted **files and folders** at the repository root. Do not upload the ZIP as the only repository file.
3. In particular, **replace any old `Dockerfile`** that says `COPY SecureBrowser_Render.zip` or `ADD SecureBrowser_Render.zip` with the `Dockerfile` included here. Replace `render.yaml` as well if you use Render Blueprints.
4. In Render's service settings, ensure the **Dockerfile Path** is `./Dockerfile`, the **Docker Build Context** is `.`, and **Root Directory** is blank if these files are in the repository root.
5. Commit and push the changes. Deploy the newest commit using **Manual Deploy → Clear build cache & deploy** if Render keeps building the previous version.
6. If your repository intentionally nests the project in a subfolder, either move these files to the repository root or adjust Render's Root Directory / Dockerfile Path accordingly.

The corrected bundle keeps Theme Studio, custom color wheels, uploaded backgrounds, `.SBT` export/import, and the existing browser functionality.

## Expected source tree

```
Dockerfile
.dockerignore
render.yaml
package.json
package-lock.json
server.js
search-core.js
media-core.js
summary-core.js
youtube-core.js
secure-index.json
public/
  index.html
  theme-studio.js
  theme-studio.css
  ...
```

**Note:** You cannot deploy a ZIP by putting it into the Dockerfile field. That field must refer to the text `Dockerfile` within the extracted source repository.
