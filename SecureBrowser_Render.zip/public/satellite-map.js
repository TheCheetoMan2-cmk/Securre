/* Lightweight interactive satellite map, independent of external map libraries.
 * Uses Esri World Imagery; place search/results continue to come from the
 * existing Secure Search OpenStreetMap provider.
 */
(() => {
  'use strict';
  const M = window.SatelliteMath;
  if (!M) return;
  const viewport = document.getElementById('satellite-map');
  const imagery = document.getElementById('imagery-layer');
  const labels = document.getElementById('labels-layer');
  const marker = document.getElementById('marker');
  const markerLabel = document.getElementById('marker-label');
  const warning = document.getElementById('load-warning');
  const fallback = document.getElementById('fallback-link');
  const toggle = document.getElementById('labels-toggle');
  const isSecureMaps = paramsReady();
  const coverageSvg = isSecureMaps ? document.getElementById('coverage-layer') : null;
  function paramsReady(){return new URLSearchParams(location.search).get('panoramax') === '1';}
  let coverageOn = false;
  let coverageItems = [];
  let coverageTimer = null;
  let coverageRequest = 0;
  let coverageLastKey = '';
  let mapillaryToken = '';
  let mapillaryCache = new Map();
  let mapillaryPending = new Map();
  let mapillaryTimer = null;
  let mapillaryRetryTimer = null;
  let mapillaryGen = 0;
  let mapillaryFailed = false;
  let mapillaryError = '';
  let mapillaryFailureCount = 0;
  const mapillaryRetryUntil = new Map();
  let mapillaryViewKey = '';
  const mapillaryAbortControllers = new Set();
  const IMAGE_SERVICE = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/';
  const LABEL_SERVICE = 'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/';
  const params = new URLSearchParams(location.search);
  const startLat = Number(params.get('lat'));
  const startLng = Number(params.get('lng'));
  const hasStart = params.has('lat') && params.has('lng') && M.validLocation(startLat, startLng);
  let center = hasStart ? { lat: startLat, lng: startLng } : { lat: 37.7749, lng: -122.4194 };
  let target = { ...center };
  let zoom = M.clamp(Math.round(Number(params.get('zoom')) || 14), M.MIN_ZOOM, M.MAX_ZOOM);
  let placeLabel = String(params.get('name') || 'Selected location').slice(0, 90);
  let showLabels = true; // The label layer is suppressed at extreme zoom, where it becomes unreadable.
  const tileLayers = [{ element: imagery, items: new Map(), base: IMAGE_SERVICE }, { element: labels, items: new Map(), base: LABEL_SERVICE }];
  let loadedImagery = false;
  let failedImagery = 0;
  let shownTiles = 0;
  let warningTimer;
  // Defer network requests during a fast wheel/pinch sequence. Already-loaded
  // imagery still paints instantly from the shared source cache.
  let deferTileRequests = false;
  let zoomIdleTimer = null;

  // Share decoded source images across zoom levels and neighbouring 256px
  // view tiles. The browser HTTP cache alone cannot prevent blank redraws or
  // repeated failed-tile fallback chains when canvases are discarded.
  const sourceCache = new Map();
  const missingCache = new Map();
  const sourcePending = new Map();
  const SOURCE_CACHE_LIMIT = 220;
  const MISSING_CACHE_LIMIT = 900;
  const MISSING_RETRY_MS = 90000;
  const sourceKey = (layer, source) => `${layer.base}${source.zoom}/${source.y}/${source.x}`;
  function rememberSource(key, image) {
    sourceCache.delete(key);
    sourceCache.set(key, image);
    missingCache.delete(key);
    while (sourceCache.size > SOURCE_CACHE_LIMIT) sourceCache.delete(sourceCache.keys().next().value);
  }
  function cachedSource(key) {
    const image = sourceCache.get(key);
    if (image) { sourceCache.delete(key); sourceCache.set(key, image); }
    return image;
  }
  function missingSource(key) {
    const timestamp = missingCache.get(key);
    if (timestamp === undefined) return false;
    if (Date.now() - timestamp < MISSING_RETRY_MS) return true;
    missingCache.delete(key);
    return false;
  }
  function rememberMissing(key) {
    missingCache.delete(key);
    missingCache.set(key, Date.now());
    while (missingCache.size > MISSING_CACHE_LIMIT) missingCache.delete(missingCache.keys().next().value);
  }
  function createTile(layer, viewX, viewY) {
    const tile = document.createElement('div');
    tile.className = 'map-tile';
    const image = document.createElement('img');
    image.alt = '';
    image.draggable = false;
    image.decoding = 'async';
    image.referrerPolicy = 'no-referrer';
    const canvas = document.createElement('canvas');
    canvas.width = M.TILE_SIZE;
    canvas.height = M.TILE_SIZE;
    const context = canvas.getContext('2d');
    if (context) {
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = 'high';
      tile.appendChild(canvas);
    } else tile.appendChild(image);

    const tileZoom = zoom;
    const isImagery = layer === tileLayers[0];
    const requestedZoom = Math.min(tileZoom, isImagery ? M.NATIVE_MAX_ZOOM : M.LABEL_MAX_ZOOM);
    const minSourceZoom = isImagery ? Math.min(tileZoom, M.MIN_FALLBACK_ZOOM) : Math.min(tileZoom, 12);
    let paintedZoom = -1;

    function paint(sourceImage, sourceZoom, preview = false) {
      if (!context) return;
      // A real tile beats a provisional up/down-scaled preview; newer
      // high-detail tiles never get overwritten by a late, blurry parent.
      const priority = preview ? -0.5 : sourceZoom;
      if (priority < paintedZoom) return;
      const factor = 2 ** (tileZoom - sourceZoom);
      const clip = M.TILE_SIZE / factor;
      const sx = ((viewX % factor + factor) % factor) * clip;
      const sy = (viewY % factor) * clip;
      context.clearRect(0, 0, M.TILE_SIZE, M.TILE_SIZE);
      context.drawImage(sourceImage, sx, sy, clip, clip, 0, 0, M.TILE_SIZE, M.TILE_SIZE);
      paintedZoom = priority;
      if (isImagery) { loadedImagery = true; warning.hidden = true; }
    }

    // Draw the best already-loaded parent tile BEFORE starting a request. Zoom
    // in from 19 to 23 therefore shows a cropped aerial photo immediately.
    if (context) {
      for (let z = requestedZoom; z >= minSourceZoom; z--) {
        const source = M.sourceTile(viewX, viewY, tileZoom, z);
        const cached = cachedSource(sourceKey(layer, source));
        if (cached) { paint(cached, z); break; }
      }
      // When zooming OUT, use already-loaded children as an immediate preview
      // while waiting for the correct lower-zoom image. Partial mosaics are
      // preferable to the black/blank tiles the old renderer showed.
      if (paintedZoom < 0 && tileZoom < M.MAX_ZOOM) {
        for (let depth = 1; depth <= 2 && tileZoom + depth <= M.MAX_ZOOM; depth++) {
          const cells = 2 ** depth, size = M.TILE_SIZE / cells;
          let drawn = 0;
          for (let dy = 0; dy < cells; dy++) for (let dx = 0; dx < cells; dx++) {
            const source = { zoom: tileZoom + depth, x: M.wrapTileX(viewX * cells + dx, tileZoom + depth), y: viewY * cells + dy };
            const cached = cachedSource(sourceKey(layer, source));
            if (cached) { context.drawImage(cached, 0, 0, 256, 256, dx * size, dy * size, size, size); drawn++; }
          }
          if (drawn) { paintedZoom = -0.5; if (isImagery) { loadedImagery = true; warning.hidden = true; } break; }
        }
      }
    }

    function requestTile(sourceZoom) {
      const source = M.sourceTile(viewX, viewY, tileZoom, sourceZoom);
      const key = sourceKey(layer, source);
      if (!context) {
        image.style.width = `${source.size}px`;
        image.style.height = `${source.size}px`;
        image.style.left = `${source.offsetX}px`;
        image.style.top = `${source.offsetY}px`;
      }
      const cached = cachedSource(key);
      if (cached) {
        paint(cached, sourceZoom);
        if (!context) image.src = cached.src;
        return;
      }
      const fallbackRequest = () => {
        if (sourceZoom > minSourceZoom) requestTile(sourceZoom - 1);
        else if (isImagery && paintedZoom < 0) { failedImagery++; scheduleWarning(); }
        else if (!isImagery && paintedZoom < 0) tile.remove();
      };
      if (missingSource(key)) { fallbackRequest(); return; }
      // Only ONE image download per source URL even when several overzoomed
      // display tiles share the same parent. All interested tiles subscribe.
      if (context && sourcePending.has(key)) {
        sourcePending.get(key).push({
          success: loaded => { if (tile.isConnected) paint(loaded, sourceZoom); },
          failure: fallbackRequest
        });
        return;
      }
      const listeners = [{
        success: loaded => { if (tile.isConnected) paint(loaded, sourceZoom); },
        failure: fallbackRequest
      }];
      if (context) sourcePending.set(key, listeners);
      image.onload = () => {
        rememberSource(key, image);
        const waiting = sourcePending.get(key) || listeners;
        sourcePending.delete(key);
        for (const listener of waiting) listener.success(image);
      };
      image.onerror = () => {
        rememberMissing(key);
        const waiting = sourcePending.get(key) || listeners;
        sourcePending.delete(key);
        for (const listener of waiting) listener.failure();
      };
      // blankTile=false makes Esri return 404 for missing high-zoom imagery,
      // not an image containing the words "Map Data Not Yet Available".
      image.src = `${key}?blankTile=false`;
    }
    if (deferTileRequests) tile.startRequest = () => requestTile(requestedZoom);
    else requestTile(requestedZoom);
    return tile;
  }

  function renderLayer(layer, bounds) {
    const required = new Set();
    const n = 2 ** zoom;
    const candidates = [];
    const cx = (bounds.left + viewport.clientWidth / 2) / M.TILE_SIZE;
    const cy = (bounds.top + viewport.clientHeight / 2) / M.TILE_SIZE;
    for (let y = bounds.y1; y <= bounds.y2; y++) {
      if (y < 0 || y >= n) continue;
      for (let x = bounds.x1; x <= bounds.x2; x++) {
        const key = `${zoom}/${y}/${x}`;
        required.add(key);
        const existing = layer.items.get(key);
        if (existing) {
          if (!deferTileRequests && existing.startRequest) {
            const start = existing.startRequest;
            existing.startRequest = null;
            start();
          }
          existing.style.left = `${x * M.TILE_SIZE - bounds.left}px`;
          existing.style.top = `${y * M.TILE_SIZE - bounds.top}px`;
        } else candidates.push({ x, y, key, distance: (x + .5 - cx) ** 2 + (y + .5 - cy) ** 2 });
      }
    }
    // The middle of the viewport gets first access to the browser's limited
    // concurrent connections; off-screen overscan tiles load afterwards.
    candidates.sort((a, b) => a.distance - b.distance);
    for (const { x, y, key } of candidates) {
      const tile = createTile(layer, x, y);
      layer.items.set(key, tile);
      tile.style.left = `${x * M.TILE_SIZE - bounds.left}px`;
      tile.style.top = `${y * M.TILE_SIZE - bounds.top}px`;
      layer.element.appendChild(tile);
    }
    for (const [key, tile] of layer.items) {
      if (!required.has(key)) { tile.remove(); layer.items.delete(key); }
    }
  }
  function scheduleWarning() {
    clearTimeout(warningTimer);
    warningTimer = setTimeout(() => {
      if (!loadedImagery && failedImagery && shownTiles) warning.hidden = false;
    }, 1500);
  }
  function render() {
    const w = viewport.clientWidth, h = viewport.clientHeight;
    if (!w || !h) return;
    const pixel = M.toPixel(center.lat, center.lng, zoom);
    const left = pixel.x - w / 2, top = pixel.y - h / 2;
    const bounds = {
      left, top,
      x1: Math.floor(left / M.TILE_SIZE) - 1,
      x2: Math.floor((left + w) / M.TILE_SIZE) + 1,
      y1: Math.floor(top / M.TILE_SIZE) - 1,
      y2: Math.floor((top + h) / M.TILE_SIZE) + 1
    };
    shownTiles = (bounds.x2 - bounds.x1 + 1) * (bounds.y2 - bounds.y1 + 1);
    renderLayer(tileLayers[0], bounds);
    if (isSecureMaps) { scheduleCoverageDraw(); scheduleCoverage(); scheduleMapillary(); }
    const labelsAvailable = zoom <= M.LABEL_MAX_ZOOM;
    labels.hidden = !showLabels || !labelsAvailable;
    toggle.disabled = !labelsAvailable;
    toggle.title = !labelsAvailable ? 'Place labels are hidden at very close zoom' : (showLabels ? 'Hide place labels' : 'Show place labels');
    if (showLabels && labelsAvailable) renderLayer(tileLayers[1], bounds);
    else {
      for (const image of tileLayers[1].items.values()) image.remove();
      tileLayers[1].items.clear();
    }
    const mp = M.toPixel(target.lat, target.lng, zoom);
    let dx = mp.x - pixel.x;
    const world = M.TILE_SIZE * 2 ** zoom;
    if (dx > world / 2) dx -= world;
    if (dx < -world / 2) dx += world;
    const x = w / 2 + dx, y = h / 2 + mp.y - pixel.y;
    marker.style.display = x > -40 && x < w + 40 && y > -40 && y < h + 50 ? 'block' : 'none';
    marker.style.left = `${x}px`;
    marker.style.top = `${y}px`;
    document.getElementById('zoom-in').disabled = zoom >= M.MAX_ZOOM;
    document.getElementById('zoom-out').disabled = zoom <= M.MIN_ZOOM;
  }
  let coverageDrawTimer = null;
  let lastCoveragePaint = null;
  function scheduleCoverageDraw(){
    if (!coverageOn || !coverageSvg) return;
    // Cheap GPU transform keeps the blue paths aligned with the map during a
    // gesture. Rebuilding thousands of SVG lines on every pointer movement
    // caused visible stuttering on phones.
    if (lastCoveragePaint) {
      const old = lastCoveragePaint;
      const ratio = 2 ** (zoom - old.zoom);
      const previous = M.toPixel(old.center.lat, old.center.lng, old.zoom);
      const current = M.toPixel(center.lat, center.lng, zoom);
      const world = M.TILE_SIZE * 2 ** zoom;
      let dx = previous.x * ratio - current.x;
      if (dx > world / 2) dx -= world;
      if (dx < -world / 2) dx += world;
      const tx = viewport.clientWidth / 2 - old.width / 2 * ratio + dx;
      const ty = viewport.clientHeight / 2 - old.height / 2 * ratio + previous.y * ratio - current.y;
      coverageSvg.style.transformOrigin = '0 0';
      coverageSvg.style.transform = `translate(${tx}px, ${ty}px) scale(${ratio})`;
    }
    clearTimeout(coverageDrawTimer);
    coverageDrawTimer = setTimeout(() => { coverageDrawTimer = null; drawCoverage(); }, 90);
  }
  // Panoramax imagery is layered over the existing Esri satellite tiles.
  // Lines are drawn ONLY between consecutive, nearby photos in the same
  // Panoramax sequence. This is photo coverage, not Google Street View data.
  const NS = 'http://www.w3.org/2000/svg';
  function bindCoverageTap(el,action){
    // Pointer gestures must bubble to the map, even when they begin on a
    // blue line. A small tap activates the photo; dragging pans the map.
    el.__coverageAction=action;
    el.setAttribute('role','button');el.setAttribute('tabindex','0');
    el.addEventListener('keydown',e=>{
      if(e.key==='Enter'||e.key===' '){e.preventDefault();action()}
    });
  }
  function sendCoverageMessage(type, detail) {
    if(window.parent!==window)window.parent.postMessage({type,...detail},location.origin);
  }
  function mapPoint(lat,lng){
    const w=viewport.clientWidth,h=viewport.clientHeight;
    const c=M.toPixel(center.lat,center.lng,zoom),p=M.toPixel(lat,lng,zoom);
    let dx=p.x-c.x;const world=256*2**zoom;
    if(dx>world/2)dx-=world;if(dx<-world/2)dx+=world;
    return {x:w/2+dx,y:h/2+(p.y-c.y)};
  }
  function distanceMeters(a,b){
    const r=Math.PI/180,dlat=(a.lat-b.lat)*r,dlng=(a.lng-b.lng)*r;
    const h=Math.sin(dlat/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(dlng/2)**2;
    return 12742000*Math.asin(Math.min(1,Math.sqrt(h)));
  }
  function selectPanoramax(photo) {
    if(!photo)return;
    // Keep the Esri map aligned with the panorama's own coordinates.
    target={lat:photo.lat,lng:photo.lng};center={...target};placeLabel='Street-level photo';markerLabel.textContent=placeLabel;render();
    sendCoverageMessage('secure-maps:panoramax-select',{picture:photo.id,sequence:photo.sequence,lat:photo.lat,lng:photo.lng,date:photo.date});
  }
  // Official Mapillary public vector tiles contain real photographed image dots
  // and connected sequences. Never invent blue road coverage from street data.
  // The base map remains Esri; only these clickable coverage paths overlay it.
  function setMapillaryToken(raw){
    const next=/^[A-Za-z0-9_|.-]{12,500}$/.test(raw||'')?String(raw):'';
    if(next===mapillaryToken)return;
    mapillaryToken=next;mapillaryGen++;mapillaryViewKey='';
    clearTimeout(mapillaryRetryTimer);
    for(const controller of mapillaryAbortControllers)controller.abort();
    mapillaryAbortControllers.clear();mapillaryCache.clear();mapillaryPending.clear();
    mapillaryFailed=false;mapillaryError='';mapillaryFailureCount=0;mapillaryRetryUntil.clear();drawCoverage();scheduleMapillary();
    sendCoverageMessage('secure-maps:mapillary-status',{configured:!!next,count:0});
  }
  function scheduleMapillary(){
    clearTimeout(mapillaryTimer);
    if(!isSecureMaps||!coverageOn||!mapillaryToken)return;
    // The sequence layer is available through z14, but z14 tiles also
    // contain a huge image layer. Load roads at z13 (or lower) first, so
    // missing / oversized photo tiles cannot hide all blue streets.
    const z=Math.min(13,Math.max(0,zoom));
    const p=M.toPixel(center.lat,center.lng,z);
    const key=z+'/'+Math.floor(p.x/256)+'/'+Math.floor(p.y/256);
    mapillaryViewKey=key;
    // Crucially do NOT abort all in-flight coverage requests while panning.
    // Frequent aborts at tile boundaries could prevent ANY blue coverage
    // from appearing during normal map movement.
    mapillaryTimer=setTimeout(loadMapillary,170);
  }
  async function loadMapillary(){
    if(!coverageOn||!mapillaryToken)return;
    // Mapillary publishes tiles to source zoom 14, then tile coordinates are
    // scaled to match Esri's additional close-up zooms (up to level 23).
    const z=Math.min(13,Math.max(0,zoom)),scale=2**(zoom-z);
    const c=M.toPixel(center.lat,center.lng,z),w=viewport.clientWidth,h=viewport.clientHeight;
    const x1=Math.floor((c.x-w/(2*scale))/256)-1,x2=Math.floor((c.x+w/(2*scale))/256)+1;
    const y1=Math.floor((c.y-h/(2*scale))/256)-1,y2=Math.floor((c.y+h/(2*scale))/256)+1;
    const n=2**z,wanted=[];
    for(let y=y1;y<=y2;y++)for(let x=x1;x<=x2;x++){
      if(y<0||y>=n)continue;
      const xx=((x%n)+n)%n;wanted.push({z,x:xx,y,key:z+'/'+xx+'/'+y});
    }
    // Prioritize photo tiles nearest the map center, then fill the whole view.
    wanted.sort((a,b)=>(a.x-c.x/256)**2+(a.y-c.y/256)**2 - ((b.x-c.x/256)**2+(b.y-c.y/256)**2));
    const visibleTiles=wanted.slice(0,48);
    // Photo dots are a progressive enhancement; request at most 3 larger z14
    // tiles after we have asked for street roads. A z14 failure must never
    // prevent z13 blue roads from appearing.
    const photos=[];
    if(zoom>=16){
      const z14=M.toPixel(center.lat,center.lng,14);
      const px=Math.floor(z14.x/256),py=Math.floor(z14.y/256);
      for(const [dx,dy] of [[0,0],[-1,0],[0,-1]]){
        const x=M.wrapTileX(px+dx,14),y=py+dy;
        if(y>=0&&y<2**14)photos.push({z:14,x,y,key:'14/'+x+'/'+y,optional:true});
      }
    }
    const generation=mapillaryGen;
    const todo=visibleTiles.filter(t=>!mapillaryCache.has(t.key)&&!mapillaryPending.has(t.key)&&Date.now()>=(mapillaryRetryUntil.get(t.key)||0));
    const download=async t=>{
      const controller=typeof AbortController!=='undefined'?new AbortController():null;
      if(controller)mapillaryAbortControllers.add(controller);
      const job=(async()=>{
        // Same-origin first: avoids Mapillary CORS failures and lets Render
        // report real 401/403/429 errors. A direct request is a backup only.
        const localUrl=`/api/mapillary/tile/${t.z}/${t.x}/${t.y}`;
        let response;
        try{
          response=await fetch(localUrl,controller?{signal:controller.signal}:{ });
          if(response.ok)return window.SecureMapillaryVector.decode(await response.arrayBuffer());
          if([401,403,429].includes(response.status)){
            const problem=new Error(response.status===429?'Mapillary rate limited':'Mapillary token rejected');
            problem.status=response.status;throw problem;
          }
        }catch(error){
          if(error?.name==='AbortError'||[401,403,429].includes(error?.status))throw error;
        }
        const directUrl=`https://tiles.mapillary.com/maps/vtp/mly1_public/2/${t.z}/${t.x}/${t.y}?access_token=${encodeURIComponent(mapillaryToken)}`;
        response=await fetch(directUrl,controller?{mode:'cors',signal:controller.signal}:{mode:'cors'});
        if(!response.ok){const problem=new Error('Mapillary coverage HTTP '+response.status);problem.status=response.status;throw problem;}
        const bytes=await response.arrayBuffer();
        if(bytes.byteLength>12*1024*1024)throw Error('Coverage tile too large');
        return window.SecureMapillaryVector.decode(bytes);
      })();
      mapillaryPending.set(t.key,job);
      try{const value=await job;if(generation!==mapillaryGen)return;
        mapillaryCache.set(t.key,value);
        while(mapillaryCache.size>75)mapillaryCache.delete(mapillaryCache.keys().next().value);
        mapillaryFailed=false;mapillaryError='';mapillaryRetryUntil.delete(t.key);
      }catch(error){if(generation===mapillaryGen&&error?.name!=='AbortError'){
        if(t.optional){mapillaryRetryUntil.set(t.key,Date.now()+60000);return;}
        mapillaryFailed=true;mapillaryFailureCount++;
        mapillaryError=[401,403].includes(error?.status)?'Mapillary client token was rejected':error?.status===429?'Mapillary is rate limiting coverage':'Could not load Mapillary coverage';
        mapillaryRetryUntil.set(t.key,Date.now()+([401,403].includes(error?.status)?45000:8000));
      }}
      finally{
        if(controller)mapillaryAbortControllers.delete(controller);
        if(mapillaryPending.get(t.key)===job)mapillaryPending.delete(t.key);
        if(generation===mapillaryGen)scheduleCoverageDraw();
      }
    };
    // Incremental batches prevent a flood of 30+ large vector-tile requests.
    for(let i=0;i<todo.length&&generation===mapillaryGen;i+=6){
      await Promise.allSettled(todo.slice(i,i+6).map(download));
    }
    if(generation===mapillaryGen&&photos.length){
      const extra=photos.filter(t=>!mapillaryCache.has(t.key)&&!mapillaryPending.has(t.key)&&Date.now()>=(mapillaryRetryUntil.get(t.key)||0));
      // Optional photo loads happen only after blue road loads finish.
      await Promise.allSettled(extra.map(download));
    }
    if(generation!==mapillaryGen)return;
    let count=0;for(const t of visibleTiles){const v=mapillaryCache.get(t.key);if(v)count+=(v.image?.length||0)+(v.sequence?.length||0)}
    sendCoverageMessage('secure-maps:mapillary-status',{configured:true,count,failed:mapillaryFailed&&!count,error:mapillaryFailed&&!count?mapillaryError:'',retryable:mapillaryFailed});
    // Transient rate limits and network failures should eventually recover
    // without requiring the user to pan away and back or reload the page.
    if(mapillaryFailed&&!count&&mapillaryError!=='Mapillary client token was rejected'){
      clearTimeout(mapillaryRetryTimer);
      mapillaryRetryTimer=setTimeout(()=>{if(coverageOn&&generation===mapillaryGen)scheduleMapillary()},9500);
    }
  }
  function selectMapillary(imageId,pt){
    if(!/^\d{4,25}$/.test(String(imageId||'')))return;
    if(pt&&M.validLocation(pt.lat,pt.lng)){
      target={lat:pt.lat,lng:pt.lng};center={...target};placeLabel='Mapillary photo';markerLabel.textContent=placeLabel;render();
    }
    sendCoverageMessage('secure-maps:mapillary-select',{imageId:String(imageId),lat:pt?.lat,lng:pt?.lng});
  }
  // Sequence features identify a photo *sequence*, not necessarily an image.
  // The Mapillary public vector tiles usually expose `id` on the sequence
  // layer, and actual image IDs only on the zoom-14 `image` layer.
  // Look for the nearest real image when the user clicks a blue road.
  function nearestCachedMapillaryImage(lat,lng){
    let closest=null,dist=Infinity;
    for(const [key,tile] of mapillaryCache){
      const [z,x,y]=key.split('/').map(Number);
      if(z!==14||!tile?.image?.length)continue;
      for(const feature of tile.image){
        const imageId=String(feature.props?.id||feature.id||'');
        const point=feature.paths?.[0];
        if(!/^\d{4,25}$/.test(imageId)||!point||point.length!==2)continue;
        const loc=M.fromPixel((x+point[0])*256,(y+point[1])*256,z);
        const d=distanceMeters({lat,lng},loc);
        if(d<dist){dist=d;closest={id:imageId,loc}}
      }
    }
    return dist<=220?closest:null;
  }
  async function openMapillaryRoad(lat,lng){
    if(!M.validLocation(lat,lng)||!mapillaryToken)return;
    let closest=nearestCachedMapillaryImage(lat,lng);
    if(!closest){
      // Use the same-origin Render lookup first. Direct Graph API calls from
      // iframes can be blocked by CORS, leaving clickable roads that do nothing.
      try{
        const url='/api/mapillary/nearest-image?lat='+encodeURIComponent(lat)+'&lng='+encodeURIComponent(lng);
        const response=await fetch(url);
        if(!response.ok)throw Error('Mapillary image lookup failed');
        const result=await response.json();
        const imageId=String(result?.image?.imageId||'');
        if(/^\d{4,25}$/.test(imageId)&&M.validLocation(Number(result.image.lat),Number(result.image.lng)))
          closest={id:imageId,loc:{lat:Number(result.image.lat),lng:Number(result.image.lng)}};
      }catch{sendCoverageMessage('secure-maps:notice',{message:'Street imagery is temporarily unavailable. Please try again.'});return;}
    }
    if(closest){selectMapillary(closest.id,closest.loc);return;}
    sendCoverageMessage('secure-maps:notice',{message:'No Mapillary photo found close to this road.'});
  }
  function drawMapillary(width,height){
    if(!coverageOn||!mapillaryToken)return;
    const sourceZ=Math.min(13,Math.max(0,zoom));
    const p=M.toPixel(center.lat,center.lng,zoom),world=256*2**zoom;
    let roads=0,dots=0;
    for(const [key,tile] of mapillaryCache){
      const [z,x,y]=key.split('/').map(Number);
      // z13 sequence tiles provide lightweight blue street coverage.
      // z14 photo tiles are optional, requested only when zoomed in.
      const roadTile=z===sourceZ;
      const photoTile=z===14 && zoom>=16;
      if(!roadTile&&!photoTile)continue;
      const factor=2**(zoom-z);
      const tileCoord=(tx,ty,fracX,fracY)=>{
        let dx=(tx+fracX)*256*factor-p.x;
        if(dx>world/2)dx-=world;if(dx<-world/2)dx+=world;
        return [width/2+dx,height/2+(ty+fracY)*256*factor-p.y];
      };
      const corner=tileCoord(x,y,0,0),span=256*factor;
      if(corner[0]>width+40||corner[0]+span< -40||corner[1]>height+40||corner[1]+span< -40)continue;
      if(roadTile) for(const feat of tile.sequence||[]){
        if(roads>3300)break;
        // The `sequence` layer typically contains a UUID `id` and geometry,
        // NOT a numeric `image_id`. Draw it regardless of photo ID.
        if(feat.type!==2)continue;
        for(const path of feat.paths||[]){
          if(path.length<2)continue;
          const coords=[];
          for(const [fx,fy] of path.slice(0,400))coords.push(tileCoord(x,y,fx,fy));
          if(!coords.some(([px,py])=>px>-50&&px<width+50&&py>-50&&py<height+50))continue;
          const el=document.createElementNS(NS,'path');el.setAttribute('d',coords.map(([px,py],i)=>(i?'L':'M')+px.toFixed(1)+' '+py.toFixed(1)).join(' '));
          el.classList.add('mapillary-line');el.setAttribute('aria-label','Open Mapillary street photo');
          bindCoverageTap(el,(click)=>{
            const segment=click ? [click.x,click.y] : coords[Math.floor(coords.length/2)];
            const c=M.toPixel(center.lat,center.lng,zoom);
            const geo=M.fromPixel(c.x+segment[0]-width/2,c.y+segment[1]-height/2,zoom);
            void openMapillaryRoad(geo.lat,geo.lng);
          });coverageSvg.append(el);roads++;
        }
      }
      // At worldwide zoom levels Mapillary provides an overview layer rather
      // than the detailed sequence layer. Show real coverage markers there too.
      if(roadTile && zoom<6)for(const feat of tile.overview||[]){
        if(dots>450)break;
        const pair=feat.paths?.[0];if(!pair)continue;
        const [px,py]=tileCoord(x,y,pair[0],pair[1]);
        if(px<-8||py<-8||px>width+8||py>height+8)continue;
        const dot=document.createElementNS(NS,'circle');dot.setAttribute('cx',px.toFixed(1));dot.setAttribute('cy',py.toFixed(1));
        dot.setAttribute('r',3.5);dot.classList.add('mapillary-dot');dot.setAttribute('aria-label','Zoom in to Mapillary street coverage');
        bindCoverageTap(dot,()=>{const geo=M.fromPixel((x+pair[0])*256*factor,(y+pair[1])*256*factor,zoom);
          if(M.validLocation(geo.lat,geo.lng)){center=geo;zoom=12;render();}
        });coverageSvg.append(dot);dots++;
      }
      // Mapillary's overview dots cover zoom <6, sequence paths cover 6+,
      // and precise photo locations become available from zoom level 14.
      if(photoTile)for(const feat of tile.image||[]){
        if(dots>1100)break;
        const id=String(feat.props.id||feat.id||'');if(!/^\d{4,25}$/.test(id))continue;
        const pair=feat.paths?.[0];if(!pair)continue;
        const [px,py]=tileCoord(x,y,pair[0],pair[1]);
        if(px<-10||py<-10||px>width+10||py>height+10)continue;
        const dot=document.createElementNS(NS,'circle');dot.setAttribute('cx',px.toFixed(1));dot.setAttribute('cy',py.toFixed(1));
        dot.setAttribute('r',zoom>=17?5:3.5);dot.classList.add('mapillary-dot');dot.setAttribute('aria-label','Open Mapillary photo');
        bindCoverageTap(dot,()=>{const geo=M.fromPixel((x+pair[0])*256*factor,(y+pair[1])*256*factor,zoom);selectMapillary(id,geo)});
        coverageSvg.append(dot);dots++;
      }
    }
  }
  function drawCoverage(){
    coverageSvg.hidden=!coverageOn;
    if(coverageSvg.hidden){lastCoveragePaint=null;coverageSvg.style.transform='';return;}
    const width=viewport.clientWidth,height=viewport.clientHeight;
    coverageSvg.style.transform='';
    lastCoveragePaint={center:{...center},zoom,width,height};
    coverageSvg.setAttribute('viewBox',`0 0 ${width} ${height}`);
    coverageSvg.replaceChildren();
    const points=new Map();const sequences=new Map();
    for(const photo of (zoom>=11?coverageItems:[])){
      const p=mapPoint(photo.lat,photo.lng);
      if(p.x<-18||p.y<-18||p.x>width+18||p.y>height+18)continue;
      points.set(photo.id,p);
      if(!sequences.has(photo.sequence))sequences.set(photo.sequence,[]);
      sequences.get(photo.sequence).push(photo);
    }
    for(const photos of sequences.values()){
      photos.sort((a,b)=>Number.isFinite(a.index)&&Number.isFinite(b.index)?a.index-b.index:a.date.localeCompare(b.date));
      for(let i=1;i<photos.length;i++){
        const a=photos[i-1],b=photos[i];
        if(distanceMeters(a,b)>85)continue;
        const p=points.get(a.id),q=points.get(b.id);
        if(!p||!q)continue;
        const line=document.createElementNS(NS,'line');line.setAttribute('x1',p.x);line.setAttribute('y1',p.y);
        line.setAttribute('x2',q.x);line.setAttribute('y2',q.y);line.classList.add('panoramax-line');
        bindCoverageTap(line,()=>selectPanoramax(b));
        coverageSvg.append(line);
      }
    }
    // Cap plotted dots to avoid rendering hundreds on mobile.
    for(const photo of coverageItems.slice(0,620)){
      const p=points.get(photo.id);if(!p)continue;
      const dot=document.createElementNS(NS,'circle');dot.setAttribute('cx',p.x);dot.setAttribute('cy',p.y);
      dot.setAttribute('r',zoom>16?'4.1':'3.2');dot.classList.add('panoramax-dot');
      dot.setAttribute('aria-label','Open Panoramax street-level photo');
      bindCoverageTap(dot,()=>selectPanoramax(photo));
      coverageSvg.append(dot);
    }
    drawMapillary(width,height);
  }
  async function loadCoverage(force=false){
    if(!isSecureMaps||!coverageOn||zoom<11){coverageItems=[];drawCoverage();return;}
    const w=viewport.clientWidth,h=viewport.clientHeight,c=M.toPixel(center.lat,center.lng,zoom);
    const left=M.fromPixel(c.x-w*.6,c.y+h*.6,zoom);
    const right=M.fromPixel(c.x+w*.6,c.y-h*.6,zoom);
    const west=Math.max(-179.999,center.lng-M.clamp(Math.abs(center.lng-left.lng),.001,.058));
    const east=Math.min(179.999,center.lng+M.clamp(Math.abs(right.lng-center.lng),.001,.058));
    const south=Math.max(-84.9,center.lat-M.clamp(Math.abs(center.lat-left.lat),.001,.045));
    const north=Math.min(84.9,center.lat+M.clamp(Math.abs(right.lat-center.lat),.001,.045));
    const bbox=[west,south,east,north].map(x=>x.toFixed(5)).join(',');
    const key=bbox;if(!force && coverageLastKey===key)return;
    coverageLastKey=key;const request=++coverageRequest;
    try{
      const response=await fetch('/api/panoramax/nearby?bbox='+encodeURIComponent(bbox));
      if(!response.ok)throw new Error('Unavailable');
      const data=await response.json();
      if(request!==coverageRequest)return;
      coverageItems=Array.isArray(data.features)?data.features:[];
      drawCoverage();sendCoverageMessage('secure-maps:coverage-status',{count:coverageItems.length,failed:false});
    }catch{
      if(request!==coverageRequest)return;
      coverageItems=[];drawCoverage();coverageLastKey='';
      sendCoverageMessage('secure-maps:coverage-status',{count:0,failed:true});
    }
  }
  function scheduleCoverage(){
    if(!coverageOn)return;
    clearTimeout(coverageTimer);coverageTimer=setTimeout(loadCoverage,220);
  }
  function chooseNearest(){
    if(!coverageItems.length){scheduleCoverage();sendCoverageMessage('secure-maps:coverage-status',{count:0,failed:false});return;}
    const sorted=[...coverageItems].sort((a,b)=>distanceMeters(a,target)-distanceMeters(b,target));
    const photo=sorted[0];
    if(distanceMeters(photo,target)>2000){sendCoverageMessage('secure-maps:coverage-status',{count:coverageItems.length,tooFar:true});return;}
    selectPanoramax(photo);
  }
  function moveBy(dx, dy) {
    const p = M.toPixel(center.lat, center.lng, zoom);
    center = M.fromPixel(p.x - dx, p.y - dy, zoom);
    render();
  }
  function zoomTo(value, x = viewport.clientWidth / 2, y = viewport.clientHeight / 2) {
    const next = M.clamp(value, M.MIN_ZOOM, M.MAX_ZOOM);
    if (zoom === next) return;
    const p = M.toPixel(center.lat, center.lng, zoom);
    const anchor = M.fromPixel(p.x + x - viewport.clientWidth / 2, p.y + y - viewport.clientHeight / 2, zoom);
    zoom = next;
    const focus = M.toPixel(anchor.lat, anchor.lng, zoom);
    center = M.fromPixel(focus.x - x + viewport.clientWidth / 2, focus.y - y + viewport.clientHeight / 2, zoom);
    loadedImagery = false;
    failedImagery = 0;
    warning.hidden = true;
    // Do not download every intermediate zoom level during rapid scrolling.
    deferTileRequests = true;
    render();
    clearTimeout(zoomIdleTimer);
    zoomIdleTimer = setTimeout(() => {
      deferTileRequests = false;
      render();
    }, 115);
  }
  function selectLocation(lat, lng, label) {
    if (!M.validLocation(lat, lng)) return;
    target = { lat, lng };
    center = { lat, lng };
    placeLabel = typeof label === 'string' && label.trim() ? label.trim().slice(0, 90) : 'Selected location';
    markerLabel.textContent = placeLabel;
    fallback.href = 'https://www.openstreetmap.org/?mlat=' + encodeURIComponent(lat) + '&mlon=' + encodeURIComponent(lng) + '#map=' + zoom + '/' + encodeURIComponent(lat) + '/' + encodeURIComponent(lng);
    render();
  }

  const pointers = new Map();
  let drag = null;
  let pinch = null;
  let coverageTap = null;
  function point(e) { const rect = viewport.getBoundingClientRect(); return { x: e.clientX - rect.left, y: e.clientY - rect.top }; }
  function initializeGesture() {
    if (pointers.size === 1) {
      const only = pointers.values().next().value;
      drag = { x: only.x, y: only.y, center: { ...center } };
      pinch = null;
    } else if (pointers.size === 2) {
      const [a, b] = [...pointers.values()];
      pinch = { dist: Math.hypot(a.x - b.x, a.y - b.y), zoom, center: { ...center }, x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      drag = null;
    }
  }
  viewport.addEventListener('pointerdown', e => {
    if (isSecureMaps) window.parent?.postMessage({ type: 'secure-maps:map-pointer' }, location.origin);
    if (e.target.closest('button,a')) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    const p=point(e);
    coverageTap=pointers.size===0&&e.target?.__coverageAction
      ? {id:e.pointerId,x:p.x,y:p.y,action:e.target.__coverageAction,cancelled:false}
      : null;
    pointers.set(e.pointerId,p);
    viewport.setPointerCapture(e.pointerId);
    viewport.classList.add('dragging');
    initializeGesture();
  });
  viewport.addEventListener('pointermove', e => {
    if (!pointers.has(e.pointerId)) return;
    const currentPoint=point(e);
    pointers.set(e.pointerId,currentPoint);
    if(coverageTap&&(pointers.size>1||Math.hypot(currentPoint.x-coverageTap.x,currentPoint.y-coverageTap.y)>9)) coverageTap.cancelled=true;
    if (pointers.size === 1 && drag) {
      const p = pointers.values().next().value;
      const original = M.toPixel(drag.center.lat, drag.center.lng, zoom);
      center = M.fromPixel(original.x - (p.x - drag.x), original.y - (p.y - drag.y), zoom);
      render();
    } else if (pointers.size === 2 && pinch) {
      const [a, b] = [...pointers.values()];
      const dist = Math.max(1, Math.hypot(a.x - b.x, a.y - b.y));
      const newZoom = M.clamp(Math.round(pinch.zoom + Math.log2(dist / Math.max(1, pinch.dist))), M.MIN_ZOOM, M.MAX_ZOOM);
      if (newZoom !== zoom) zoomTo(newZoom, pinch.x, pinch.y);
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      const original = M.toPixel(pinch.center.lat, pinch.center.lng, zoom);
      center = M.fromPixel(original.x - (mx - pinch.x), original.y - (my - pinch.y), zoom);
      render();
    }
  });
  function endPointer(e) {
    const tap=coverageTap;
    coverageTap=null;
    // Only trigger on a genuine tap, never when finishing a drag or pinch.
    if(e.type==='pointerup'&&tap&&!tap.cancelled&&tap.id===e.pointerId&&pointers.size===1){
      const p=point(e);
      if(Math.hypot(p.x-tap.x,p.y-tap.y)<9) tap.action(p);
    }
    pointers.delete(e.pointerId);
    if (!pointers.size) viewport.classList.remove('dragging');
    initializeGesture();
  }
  viewport.addEventListener('pointerup', endPointer);
  viewport.addEventListener('pointercancel', endPointer);
  viewport.addEventListener('lostpointercapture', endPointer);
  viewport.addEventListener('wheel', e => {
    e.preventDefault();
    const p = point(e);
    zoomTo(zoom + (e.deltaY < 0 ? 1 : -1), p.x, p.y);
  }, { passive: false });
  viewport.addEventListener('dblclick', e => {
    if (e.target.closest('button,a')) return;
    const p = point(e);
    zoomTo(zoom + 1, p.x, p.y);
  });
  viewport.addEventListener('keydown', e => {
    if (e.target !== viewport) return;
    const pan = { ArrowLeft: [-80, 0], ArrowRight: [80, 0], ArrowUp: [0, -80], ArrowDown: [0, 80] }[e.key];
    if (pan) { e.preventDefault(); moveBy(-pan[0], -pan[1]); }
    else if (e.key === '+' || e.key === '=') { e.preventDefault(); zoomTo(zoom + 1); }
    else if (e.key === '-') { e.preventDefault(); zoomTo(zoom - 1); }
  });
  document.getElementById('zoom-in').addEventListener('click', () => zoomTo(zoom + 1));
  document.getElementById('zoom-out').addEventListener('click', () => zoomTo(zoom - 1));
  document.getElementById('recenter').addEventListener('click', () => { center = { ...target }; render(); });
  toggle.addEventListener('click', () => {
    showLabels = !showLabels;
    toggle.setAttribute('aria-pressed', String(showLabels));
    toggle.setAttribute('aria-label', showLabels ? 'Hide place labels' : 'Show place labels');
    toggle.title = showLabels ? 'Hide place labels' : 'Show place labels';
    render();
  });
  window.addEventListener('message', event => {
    if (event.origin !== location.origin || event.source !== window.parent || event.data?.type !== 'secure-browser:satellite-center') return;
    const lat = Number(event.data.lat), lng = Number(event.data.lng);
    selectLocation(lat, lng, event.data.label);
    if (isSecureMaps) { coverageLastKey=''; scheduleCoverage(); }
  });
  window.addEventListener('message',event=>{
    if (!isSecureMaps || event.origin!==location.origin || event.source!==window.parent)return;
    if (event.data?.type==='secure-maps:coverage-toggle'){
      coverageOn=!!event.data.enabled;coverageSvg.hidden=!coverageOn;
      if(!coverageOn)clearTimeout(mapillaryRetryTimer);
      if(coverageOn){coverageLastKey='';loadCoverage(true);scheduleMapillary()}else{coverageRequest++;coverageItems=[];drawCoverage()}
    }
    if (event.data?.type==='secure-maps:find-nearest')chooseNearest();
    if (event.data?.type==='secure-maps:mapillary-token')setMapillaryToken(event.data.token);
    if (event.data?.type==='secure-maps:hello')sendCoverageMessage('secure-browser:satellite-ready',{});
  });
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => render()).observe(viewport);
  else window.addEventListener('resize', render);
  selectLocation(center.lat, center.lng, placeLabel);
  window.parent?.postMessage({ type: 'secure-browser:satellite-ready' }, location.origin);
})();
