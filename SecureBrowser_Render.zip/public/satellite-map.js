/* Lightweight interactive satellite map, independent of external map libraries.
 * Uses Esri World Imagery; place search/results continue to come from the
 * existing Secure Search OpenStreetMap provider.
 */
(() => {
  'use strict';
  const M = window.SatelliteMath;
  if (!M) return;
  const viewport = document.getElementById('satellite-map');
  const imagery = document.getElementById('imagery-layer');
  const labels = document.getElementById('labels-layer');
  const marker = document.getElementById('marker');
  const markerLabel = document.getElementById('marker-label');
  const warning = document.getElementById('load-warning');
  const fallback = document.getElementById('fallback-link');
  const toggle = document.getElementById('labels-toggle');
  const IMAGE_SERVICE = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/';
  const LABEL_SERVICE = 'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/';
  const params = new URLSearchParams(location.search);
  const startLat = Number(params.get('lat'));
  const startLng = Number(params.get('lng'));
  const hasStart = params.has('lat') && params.has('lng') && M.validLocation(startLat, startLng);
  let center = hasStart ? { lat: startLat, lng: startLng } : { lat: 37.7749, lng: -122.4194 };
  let target = { ...center };
  let zoom = M.clamp(Math.round(Number(params.get('zoom')) || 14), M.MIN_ZOOM, M.MAX_ZOOM);
  let placeLabel = String(params.get('name') || 'Selected location').slice(0, 90);
  let showLabels = true; // The label layer is suppressed at extreme zoom, where it becomes unreadable.
  const tileLayers = [{ element: imagery, items: new Map(), base: IMAGE_SERVICE }, { element: labels, items: new Map(), base: LABEL_SERVICE }];
  let loadedImagery = false;
  let failedImagery = 0;
  let shownTiles = 0;
  let warningTimer;
  // Defer network requests during a fast wheel/pinch sequence. Already-loaded
  // imagery still paints instantly from the shared source cache.
  let deferTileRequests = false;
  let zoomIdleTimer = null;

  // Share decoded source images across zoom levels and neighbouring 256px
  // view tiles. The browser HTTP cache alone cannot prevent blank redraws or
  // repeated failed-tile fallback chains when canvases are discarded.
  const sourceCache = new Map();
  const missingCache = new Map();
  const sourcePending = new Map();
  const SOURCE_CACHE_LIMIT = 220;
  const MISSING_CACHE_LIMIT = 900;
  const MISSING_RETRY_MS = 90000;
  const sourceKey = (layer, source) => `${layer.base}${source.zoom}/${source.y}/${source.x}`;
  function rememberSource(key, image) {
    sourceCache.delete(key);
    sourceCache.set(key, image);
    missingCache.delete(key);
    while (sourceCache.size > SOURCE_CACHE_LIMIT) sourceCache.delete(sourceCache.keys().next().value);
  }
  function cachedSource(key) {
    const image = sourceCache.get(key);
    if (image) { sourceCache.delete(key); sourceCache.set(key, image); }
    return image;
  }
  function missingSource(key) {
    const timestamp = missingCache.get(key);
    if (timestamp === undefined) return false;
    if (Date.now() - timestamp < MISSING_RETRY_MS) return true;
    missingCache.delete(key);
    return false;
  }
  function rememberMissing(key) {
    missingCache.delete(key);
    missingCache.set(key, Date.now());
    while (missingCache.size > MISSING_CACHE_LIMIT) missingCache.delete(missingCache.keys().next().value);
  }
  function createTile(layer, viewX, viewY) {
    const tile = document.createElement('div');
    tile.className = 'map-tile';
    const image = document.createElement('img');
    image.alt = '';
    image.draggable = false;
    image.decoding = 'async';
    image.referrerPolicy = 'no-referrer';
    const canvas = document.createElement('canvas');
    canvas.width = M.TILE_SIZE;
    canvas.height = M.TILE_SIZE;
    const context = canvas.getContext('2d');
    if (context) {
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = 'high';
      tile.appendChild(canvas);
    } else tile.appendChild(image);

    const tileZoom = zoom;
    const isImagery = layer === tileLayers[0];
    const requestedZoom = Math.min(tileZoom, isImagery ? M.NATIVE_MAX_ZOOM : M.LABEL_MAX_ZOOM);
    const minSourceZoom = isImagery ? Math.min(tileZoom, M.MIN_FALLBACK_ZOOM) : Math.min(tileZoom, 12);
    let paintedZoom = -1;

    function paint(sourceImage, sourceZoom, preview = false) {
      if (!context) return;
      // A real tile beats a provisional up/down-scaled preview; newer
      // high-detail tiles never get overwritten by a late, blurry parent.
      const priority = preview ? -0.5 : sourceZoom;
      if (priority < paintedZoom) return;
      const factor = 2 ** (tileZoom - sourceZoom);
      const clip = M.TILE_SIZE / factor;
      const sx = ((viewX % factor + factor) % factor) * clip;
      const sy = (viewY % factor) * clip;
      context.clearRect(0, 0, M.TILE_SIZE, M.TILE_SIZE);
      context.drawImage(sourceImage, sx, sy, clip, clip, 0, 0, M.TILE_SIZE, M.TILE_SIZE);
      paintedZoom = priority;
      if (isImagery) { loadedImagery = true; warning.hidden = true; }
    }

    // Draw the best already-loaded parent tile BEFORE starting a request. Zoom
    // in from 19 to 23 therefore shows a cropped aerial photo immediately.
    if (context) {
      for (let z = requestedZoom; z >= minSourceZoom; z--) {
        const source = M.sourceTile(viewX, viewY, tileZoom, z);
        const cached = cachedSource(sourceKey(layer, source));
        if (cached) { paint(cached, z); break; }
      }
      // When zooming OUT, use already-loaded children as an immediate preview
      // while waiting for the correct lower-zoom image. Partial mosaics are
      // preferable to the black/blank tiles the old renderer showed.
      if (paintedZoom < 0 && tileZoom < M.MAX_ZOOM) {
        for (let depth = 1; depth <= 2 && tileZoom + depth <= M.MAX_ZOOM; depth++) {
          const cells = 2 ** depth, size = M.TILE_SIZE / cells;
          let drawn = 0;
          for (let dy = 0; dy < cells; dy++) for (let dx = 0; dx < cells; dx++) {
            const source = { zoom: tileZoom + depth, x: M.wrapTileX(viewX * cells + dx, tileZoom + depth), y: viewY * cells + dy };
            const cached = cachedSource(sourceKey(layer, source));
            if (cached) { context.drawImage(cached, 0, 0, 256, 256, dx * size, dy * size, size, size); drawn++; }
          }
          if (drawn) { paintedZoom = -0.5; if (isImagery) { loadedImagery = true; warning.hidden = true; } break; }
        }
      }
    }

    function requestTile(sourceZoom) {
      const source = M.sourceTile(viewX, viewY, tileZoom, sourceZoom);
      const key = sourceKey(layer, source);
      if (!context) {
        image.style.width = `${source.size}px`;
        image.style.height = `${source.size}px`;
        image.style.left = `${source.offsetX}px`;
        image.style.top = `${source.offsetY}px`;
      }
      const cached = cachedSource(key);
      if (cached) {
        paint(cached, sourceZoom);
        if (!context) image.src = cached.src;
        return;
      }
      const fallbackRequest = () => {
        if (sourceZoom > minSourceZoom) requestTile(sourceZoom - 1);
        else if (isImagery && paintedZoom < 0) { failedImagery++; scheduleWarning(); }
        else if (!isImagery && paintedZoom < 0) tile.remove();
      };
      if (missingSource(key)) { fallbackRequest(); return; }
      // Only ONE image download per source URL even when several overzoomed
      // display tiles share the same parent. All interested tiles subscribe.
      if (context && sourcePending.has(key)) {
        sourcePending.get(key).push({
          success: loaded => { if (tile.isConnected) paint(loaded, sourceZoom); },
          failure: fallbackRequest
        });
        return;
      }
      const listeners = [{
        success: loaded => { if (tile.isConnected) paint(loaded, sourceZoom); },
        failure: fallbackRequest
      }];
      if (context) sourcePending.set(key, listeners);
      image.onload = () => {
        rememberSource(key, image);
        const waiting = sourcePending.get(key) || listeners;
        sourcePending.delete(key);
        for (const listener of waiting) listener.success(image);
      };
      image.onerror = () => {
        rememberMissing(key);
        const waiting = sourcePending.get(key) || listeners;
        sourcePending.delete(key);
        for (const listener of waiting) listener.failure();
      };
      // blankTile=false makes Esri return 404 for missing high-zoom imagery,
      // not an image containing the words "Map Data Not Yet Available".
      image.src = `${key}?blankTile=false`;
    }
    if (deferTileRequests) tile.startRequest = () => requestTile(requestedZoom);
    else requestTile(requestedZoom);
    return tile;
  }

  function renderLayer(layer, bounds) {
    const required = new Set();
    const n = 2 ** zoom;
    const candidates = [];
    const cx = (bounds.left + viewport.clientWidth / 2) / M.TILE_SIZE;
    const cy = (bounds.top + viewport.clientHeight / 2) / M.TILE_SIZE;
    for (let y = bounds.y1; y <= bounds.y2; y++) {
      if (y < 0 || y >= n) continue;
      for (let x = bounds.x1; x <= bounds.x2; x++) {
        const key = `${zoom}/${y}/${x}`;
        required.add(key);
        const existing = layer.items.get(key);
        if (existing) {
          if (!deferTileRequests && existing.startRequest) {
            const start = existing.startRequest;
            existing.startRequest = null;
            start();
          }
          existing.style.left = `${x * M.TILE_SIZE - bounds.left}px`;
          existing.style.top = `${y * M.TILE_SIZE - bounds.top}px`;
        } else candidates.push({ x, y, key, distance: (x + .5 - cx) ** 2 + (y + .5 - cy) ** 2 });
      }
    }
    // The middle of the viewport gets first access to the browser's limited
    // concurrent connections; off-screen overscan tiles load afterwards.
    candidates.sort((a, b) => a.distance - b.distance);
    for (const { x, y, key } of candidates) {
      const tile = createTile(layer, x, y);
      layer.items.set(key, tile);
      tile.style.left = `${x * M.TILE_SIZE - bounds.left}px`;
      tile.style.top = `${y * M.TILE_SIZE - bounds.top}px`;
      layer.element.appendChild(tile);
    }
    for (const [key, tile] of layer.items) {
      if (!required.has(key)) { tile.remove(); layer.items.delete(key); }
    }
  }
  function scheduleWarning() {
    clearTimeout(warningTimer);
    warningTimer = setTimeout(() => {
      if (!loadedImagery && failedImagery && shownTiles) warning.hidden = false;
    }, 1500);
  }
  function render() {
    const w = viewport.clientWidth, h = viewport.clientHeight;
    if (!w || !h) return;
    const pixel = M.toPixel(center.lat, center.lng, zoom);
    const left = pixel.x - w / 2, top = pixel.y - h / 2;
    const bounds = {
      left, top,
      x1: Math.floor(left / M.TILE_SIZE) - 1,
      x2: Math.floor((left + w) / M.TILE_SIZE) + 1,
      y1: Math.floor(top / M.TILE_SIZE) - 1,
      y2: Math.floor((top + h) / M.TILE_SIZE) + 1
    };
    shownTiles = (bounds.x2 - bounds.x1 + 1) * (bounds.y2 - bounds.y1 + 1);
    renderLayer(tileLayers[0], bounds);
    const labelsAvailable = zoom <= M.LABEL_MAX_ZOOM;
    labels.hidden = !showLabels || !labelsAvailable;
    toggle.disabled = !labelsAvailable;
    toggle.title = !labelsAvailable ? 'Place labels are hidden at very close zoom' : (showLabels ? 'Hide place labels' : 'Show place labels');
    if (showLabels && labelsAvailable) renderLayer(tileLayers[1], bounds);
    else {
      for (const image of tileLayers[1].items.values()) image.remove();
      tileLayers[1].items.clear();
    }
    const mp = M.toPixel(target.lat, target.lng, zoom);
    let dx = mp.x - pixel.x;
    const world = M.TILE_SIZE * 2 ** zoom;
    if (dx > world / 2) dx -= world;
    if (dx < -world / 2) dx += world;
    const x = w / 2 + dx, y = h / 2 + mp.y - pixel.y;
    marker.style.display = x > -40 && x < w + 40 && y > -40 && y < h + 50 ? 'block' : 'none';
    marker.style.left = `${x}px`;
    marker.style.top = `${y}px`;
    document.getElementById('zoom-in').disabled = zoom >= M.MAX_ZOOM;
    document.getElementById('zoom-out').disabled = zoom <= M.MIN_ZOOM;
  }
  function moveBy(dx, dy) {
    const p = M.toPixel(center.lat, center.lng, zoom);
    center = M.fromPixel(p.x - dx, p.y - dy, zoom);
    render();
  }
  function zoomTo(value, x = viewport.clientWidth / 2, y = viewport.clientHeight / 2) {
    const next = M.clamp(value, M.MIN_ZOOM, M.MAX_ZOOM);
    if (zoom === next) return;
    const p = M.toPixel(center.lat, center.lng, zoom);
    const anchor = M.fromPixel(p.x + x - viewport.clientWidth / 2, p.y + y - viewport.clientHeight / 2, zoom);
    zoom = next;
    const focus = M.toPixel(anchor.lat, anchor.lng, zoom);
    center = M.fromPixel(focus.x - x + viewport.clientWidth / 2, focus.y - y + viewport.clientHeight / 2, zoom);
    loadedImagery = false;
    failedImagery = 0;
    warning.hidden = true;
    // Do not download every intermediate zoom level during rapid scrolling.
    deferTileRequests = true;
    render();
    clearTimeout(zoomIdleTimer);
    zoomIdleTimer = setTimeout(() => {
      deferTileRequests = false;
      render();
    }, 115);
  }
  function selectLocation(lat, lng, label) {
    if (!M.validLocation(lat, lng)) return;
    target = { lat, lng };
    center = { lat, lng };
    placeLabel = typeof label === 'string' && label.trim() ? label.trim().slice(0, 90) : 'Selected location';
    markerLabel.textContent = placeLabel;
    fallback.href = 'https://www.openstreetmap.org/?mlat=' + encodeURIComponent(lat) + '&mlon=' + encodeURIComponent(lng) + '#map=' + zoom + '/' + encodeURIComponent(lat) + '/' + encodeURIComponent(lng);
    render();
  }

  const pointers = new Map();
  let drag = null;
  let pinch = null;
  function point(e) { const rect = viewport.getBoundingClientRect(); return { x: e.clientX - rect.left, y: e.clientY - rect.top }; }
  function initializeGesture() {
    if (pointers.size === 1) {
      const only = pointers.values().next().value;
      drag = { x: only.x, y: only.y, center: { ...center } };
      pinch = null;
    } else if (pointers.size === 2) {
      const [a, b] = [...pointers.values()];
      pinch = { dist: Math.hypot(a.x - b.x, a.y - b.y), zoom, center: { ...center }, x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      drag = null;
    }
  }
  viewport.addEventListener('pointerdown', e => {
    if (e.target.closest('button,a')) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    const p=point(e);
    pointers.set(e.pointerId,p);
    viewport.setPointerCapture(e.pointerId);
    viewport.classList.add('dragging');
    initializeGesture();
  });
  viewport.addEventListener('pointermove', e => {
    if (!pointers.has(e.pointerId)) return;
    const currentPoint=point(e);
    pointers.set(e.pointerId,currentPoint);
    if (pointers.size === 1 && drag) {
      const p = pointers.values().next().value;
      const original = M.toPixel(drag.center.lat, drag.center.lng, zoom);
      center = M.fromPixel(original.x - (p.x - drag.x), original.y - (p.y - drag.y), zoom);
      render();
    } else if (pointers.size === 2 && pinch) {
      const [a, b] = [...pointers.values()];
      const dist = Math.max(1, Math.hypot(a.x - b.x, a.y - b.y));
      const newZoom = M.clamp(Math.round(pinch.zoom + Math.log2(dist / Math.max(1, pinch.dist))), M.MIN_ZOOM, M.MAX_ZOOM);
      if (newZoom !== zoom) zoomTo(newZoom, pinch.x, pinch.y);
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      const original = M.toPixel(pinch.center.lat, pinch.center.lng, zoom);
      center = M.fromPixel(original.x - (mx - pinch.x), original.y - (my - pinch.y), zoom);
      render();
    }
  });
  function endPointer(e) {
    pointers.delete(e.pointerId);
    if (!pointers.size) viewport.classList.remove('dragging');
    initializeGesture();
  }
  viewport.addEventListener('pointerup', endPointer);
  viewport.addEventListener('pointercancel', endPointer);
  viewport.addEventListener('lostpointercapture', endPointer);
  viewport.addEventListener('wheel', e => {
    e.preventDefault();
    const p = point(e);
    zoomTo(zoom + (e.deltaY < 0 ? 1 : -1), p.x, p.y);
  }, { passive: false });
  viewport.addEventListener('dblclick', e => {
    if (e.target.closest('button,a')) return;
    const p = point(e);
    zoomTo(zoom + 1, p.x, p.y);
  });
  viewport.addEventListener('keydown', e => {
    if (e.target !== viewport) return;
    const pan = { ArrowLeft: [-80, 0], ArrowRight: [80, 0], ArrowUp: [0, -80], ArrowDown: [0, 80] }[e.key];
    if (pan) { e.preventDefault(); moveBy(-pan[0], -pan[1]); }
    else if (e.key === '+' || e.key === '=') { e.preventDefault(); zoomTo(zoom + 1); }
    else if (e.key === '-') { e.preventDefault(); zoomTo(zoom - 1); }
  });
  document.getElementById('zoom-in').addEventListener('click', () => zoomTo(zoom + 1));
  document.getElementById('zoom-out').addEventListener('click', () => zoomTo(zoom - 1));
  document.getElementById('recenter').addEventListener('click', () => { center = { ...target }; render(); });
  toggle.addEventListener('click', () => {
    showLabels = !showLabels;
    toggle.setAttribute('aria-pressed', String(showLabels));
    toggle.setAttribute('aria-label', showLabels ? 'Hide place labels' : 'Show place labels');
    toggle.title = showLabels ? 'Hide place labels' : 'Show place labels';
    render();
  });
  window.addEventListener('message', event => {
    if (event.origin !== location.origin || event.source !== window.parent || event.data?.type !== 'secure-browser:satellite-center') return;
    const lat = Number(event.data.lat), lng = Number(event.data.lng);
    selectLocation(lat, lng, event.data.label);
  });
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => render()).observe(viewport);
  else window.addEventListener('resize', render);
  selectLocation(center.lat, center.lng, placeLabel);
  window.parent?.postMessage({ type: 'secure-browser:satellite-ready' }, location.origin);
})();
