/* Lightweight interactive satellite map, independent of external map libraries.
 * Uses Esri World Imagery; place search/results continue to come from the
 * existing Secure Search OpenStreetMap provider.
 */
(() => {
  'use strict';
  const M = window.SatelliteMath;
  if (!M) return;
  const viewport = document.getElementById('satellite-map');
  const imagery = document.getElementById('imagery-layer');
  const labels = document.getElementById('labels-layer');
  const marker = document.getElementById('marker');
  const markerLabel = document.getElementById('marker-label');
  const warning = document.getElementById('load-warning');
  const fallback = document.getElementById('fallback-link');
  const toggle = document.getElementById('labels-toggle');
  const IMAGE_SERVICE = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/';
  const LABEL_SERVICE = 'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/';
  const params = new URLSearchParams(location.search);
  const startLat = Number(params.get('lat'));
  const startLng = Number(params.get('lng'));
  const hasStart = params.has('lat') && params.has('lng') && M.validLocation(startLat, startLng);
  let center = hasStart ? { lat: startLat, lng: startLng } : { lat: 37.7749, lng: -122.4194 };
  let target = { ...center };
  let zoom = M.clamp(Math.round(Number(params.get('zoom')) || 14), M.MIN_ZOOM, M.MAX_ZOOM);
  let placeLabel = String(params.get('name') || 'Selected location').slice(0, 90);
  let showLabels = true;
  const tileLayers = [{ element: imagery, items: new Map(), base: IMAGE_SERVICE }, { element: labels, items: new Map(), base: LABEL_SERVICE }];
  let loadedImagery = false;
  let failedImagery = 0;
  let shownTiles = 0;
  let warningTimer;

  function renderLayer(layer, bounds) {
    const required = new Set();
    const n = 2 ** zoom;
    for (let y = bounds.y1; y <= bounds.y2; y++) {
      if (y < 0 || y >= n) continue;
      for (let x = bounds.x1; x <= bounds.x2; x++) {
        const worldX = M.wrapTileX(x, zoom);
        const key = `${zoom}/${y}/${worldX}`;
        required.add(key);
        let image = layer.items.get(key);
        if (!image) {
          image = document.createElement('img');
          image.alt = '';
          image.draggable = false;
          image.decoding = 'async';
          image.referrerPolicy = 'no-referrer';
          image.src = `${layer.base}${zoom}/${y}/${worldX}`;
          if (layer === tileLayers[0]) {
            image.addEventListener('load', () => { loadedImagery = true; warning.hidden = true; });
            image.addEventListener('error', () => { failedImagery += 1; scheduleWarning(); });
          } else {
            image.addEventListener('error', () => image.remove());
          }
          layer.items.set(key, image);
          layer.element.appendChild(image);
        }
        image.style.left = `${x * M.TILE_SIZE - bounds.left}px`;
        image.style.top = `${y * M.TILE_SIZE - bounds.top}px`;
      }
    }
    for (const [key, image] of layer.items) {
      if (!required.has(key)) {
        image.remove();
        layer.items.delete(key);
      }
    }
  }
  function scheduleWarning() {
    clearTimeout(warningTimer);
    warningTimer = setTimeout(() => {
      if (!loadedImagery && failedImagery && shownTiles) warning.hidden = false;
    }, 1500);
  }
  function render() {
    const w = viewport.clientWidth, h = viewport.clientHeight;
    if (!w || !h) return;
    const pixel = M.toPixel(center.lat, center.lng, zoom);
    const left = pixel.x - w / 2, top = pixel.y - h / 2;
    const bounds = {
      left, top,
      x1: Math.floor(left / M.TILE_SIZE) - 1,
      x2: Math.floor((left + w) / M.TILE_SIZE) + 1,
      y1: Math.floor(top / M.TILE_SIZE) - 1,
      y2: Math.floor((top + h) / M.TILE_SIZE) + 1
    };
    shownTiles = (bounds.x2 - bounds.x1 + 1) * (bounds.y2 - bounds.y1 + 1);
    renderLayer(tileLayers[0], bounds);
    labels.hidden = !showLabels;
    if (showLabels) renderLayer(tileLayers[1], bounds);
    else {
      for (const image of tileLayers[1].items.values()) image.remove();
      tileLayers[1].items.clear();
    }
    const mp = M.toPixel(target.lat, target.lng, zoom);
    let dx = mp.x - pixel.x;
    const world = M.TILE_SIZE * 2 ** zoom;
    if (dx > world / 2) dx -= world;
    if (dx < -world / 2) dx += world;
    const x = w / 2 + dx, y = h / 2 + mp.y - pixel.y;
    marker.style.display = x > -40 && x < w + 40 && y > -40 && y < h + 50 ? 'block' : 'none';
    marker.style.left = `${x}px`;
    marker.style.top = `${y}px`;
    document.getElementById('zoom-in').disabled = zoom >= M.MAX_ZOOM;
    document.getElementById('zoom-out').disabled = zoom <= M.MIN_ZOOM;
  }
  function moveBy(dx, dy) {
    const p = M.toPixel(center.lat, center.lng, zoom);
    center = M.fromPixel(p.x - dx, p.y - dy, zoom);
    render();
  }
  function zoomTo(value, x = viewport.clientWidth / 2, y = viewport.clientHeight / 2) {
    const next = M.clamp(value, M.MIN_ZOOM, M.MAX_ZOOM);
    if (zoom === next) return;
    const p = M.toPixel(center.lat, center.lng, zoom);
    const anchor = M.fromPixel(p.x + x - viewport.clientWidth / 2, p.y + y - viewport.clientHeight / 2, zoom);
    zoom = next;
    const focus = M.toPixel(anchor.lat, anchor.lng, zoom);
    center = M.fromPixel(focus.x - x + viewport.clientWidth / 2, focus.y - y + viewport.clientHeight / 2, zoom);
    loadedImagery = false;
    failedImagery = 0;
    warning.hidden = true;
    render();
  }
  function selectLocation(lat, lng, label) {
    if (!M.validLocation(lat, lng)) return;
    target = { lat, lng };
    center = { lat, lng };
    placeLabel = typeof label === 'string' && label.trim() ? label.trim().slice(0, 90) : 'Selected location';
    markerLabel.textContent = placeLabel;
    fallback.href = 'https://www.openstreetmap.org/?mlat=' + encodeURIComponent(lat) + '&mlon=' + encodeURIComponent(lng) + '#map=' + zoom + '/' + encodeURIComponent(lat) + '/' + encodeURIComponent(lng);
    render();
  }

  const pointers = new Map();
  let drag = null;
  let pinch = null;
  function point(e) { const rect = viewport.getBoundingClientRect(); return { x: e.clientX - rect.left, y: e.clientY - rect.top }; }
  function initializeGesture() {
    if (pointers.size === 1) {
      const only = pointers.values().next().value;
      drag = { x: only.x, y: only.y, center: { ...center } };
      pinch = null;
    } else if (pointers.size === 2) {
      const [a, b] = [...pointers.values()];
      pinch = { dist: Math.hypot(a.x - b.x, a.y - b.y), zoom, center: { ...center }, x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      drag = null;
    }
  }
  viewport.addEventListener('pointerdown', e => {
    if (e.target.closest('button,a')) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    pointers.set(e.pointerId, point(e));
    viewport.setPointerCapture(e.pointerId);
    viewport.classList.add('dragging');
    initializeGesture();
  });
  viewport.addEventListener('pointermove', e => {
    if (!pointers.has(e.pointerId)) return;
    pointers.set(e.pointerId, point(e));
    if (pointers.size === 1 && drag) {
      const p = pointers.values().next().value;
      const original = M.toPixel(drag.center.lat, drag.center.lng, zoom);
      center = M.fromPixel(original.x - (p.x - drag.x), original.y - (p.y - drag.y), zoom);
      render();
    } else if (pointers.size === 2 && pinch) {
      const [a, b] = [...pointers.values()];
      const dist = Math.max(1, Math.hypot(a.x - b.x, a.y - b.y));
      const newZoom = M.clamp(Math.round(pinch.zoom + Math.log2(dist / Math.max(1, pinch.dist))), M.MIN_ZOOM, M.MAX_ZOOM);
      if (newZoom !== zoom) zoomTo(newZoom, pinch.x, pinch.y);
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      const original = M.toPixel(pinch.center.lat, pinch.center.lng, zoom);
      center = M.fromPixel(original.x - (mx - pinch.x), original.y - (my - pinch.y), zoom);
      render();
    }
  });
  function endPointer(e) {
    pointers.delete(e.pointerId);
    if (!pointers.size) viewport.classList.remove('dragging');
    initializeGesture();
  }
  viewport.addEventListener('pointerup', endPointer);
  viewport.addEventListener('pointercancel', endPointer);
  viewport.addEventListener('lostpointercapture', endPointer);
  viewport.addEventListener('wheel', e => {
    e.preventDefault();
    const p = point(e);
    zoomTo(zoom + (e.deltaY < 0 ? 1 : -1), p.x, p.y);
  }, { passive: false });
  viewport.addEventListener('dblclick', e => {
    if (e.target.closest('button,a')) return;
    const p = point(e);
    zoomTo(zoom + 1, p.x, p.y);
  });
  viewport.addEventListener('keydown', e => {
    if (e.target !== viewport) return;
    const pan = { ArrowLeft: [-80, 0], ArrowRight: [80, 0], ArrowUp: [0, -80], ArrowDown: [0, 80] }[e.key];
    if (pan) { e.preventDefault(); moveBy(-pan[0], -pan[1]); }
    else if (e.key === '+' || e.key === '=') { e.preventDefault(); zoomTo(zoom + 1); }
    else if (e.key === '-') { e.preventDefault(); zoomTo(zoom - 1); }
  });
  document.getElementById('zoom-in').addEventListener('click', () => zoomTo(zoom + 1));
  document.getElementById('zoom-out').addEventListener('click', () => zoomTo(zoom - 1));
  document.getElementById('recenter').addEventListener('click', () => { center = { ...target }; render(); });
  toggle.addEventListener('click', () => {
    showLabels = !showLabels;
    toggle.setAttribute('aria-pressed', String(showLabels));
    toggle.setAttribute('aria-label', showLabels ? 'Hide place labels' : 'Show place labels');
    toggle.title = showLabels ? 'Hide place labels' : 'Show place labels';
    render();
  });
  window.addEventListener('message', event => {
    if (event.origin !== location.origin || event.source !== window.parent || event.data?.type !== 'secure-browser:satellite-center') return;
    const lat = Number(event.data.lat), lng = Number(event.data.lng);
    selectLocation(lat, lng, event.data.label);
  });
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => render()).observe(viewport);
  else window.addEventListener('resize', render);
  selectLocation(center.lat, center.lng, placeLabel);
  window.parent?.postMessage({ type: 'secure-browser:satellite-ready' }, location.origin);
})();
