(()=>{'use strict';
 const $=id=>document.getElementById(id);
 const map=$('satelliteFrame'),picture=$('photoFrame');
 const params=new URLSearchParams(location.search);
 const valid=(lat,lng)=>Number.isFinite(lat)&&Number.isFinite(lng)&&Math.abs(lat)<=85&&Math.abs(lng)<=180;
 const storageKey='secure-maps:last-location-v1';
 const readLast=()=>{try{return JSON.parse(localStorage.getItem(storageKey))}catch{return null}};
 let selected={lat:48.8566,lng:2.3522,label:'Paris, France'};
 const paramLat=Number(params.get('lat')),paramLng=Number(params.get('lng'));
 if(params.has('lat')&&params.has('lng')&&valid(paramLat,paramLng))selected={lat:paramLat,lng:paramLng,label:(params.get('name')||'Selected location').slice(0,120)};
 else if(readLast()&&valid(Number(readLast().lat),Number(readLast().lng)))selected=readLast();
 let mapReady=false,requestNo=0,selectedPlaceId=-1,coverageCount=0,coverageLoaded=false;
 let toastTimer;
 function toast(msg){const e=$('toast');e.textContent=msg;e.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.classList.remove('visible'),2800)}
 function addText(parent,tag,text,cls){const e=document.createElement(tag);e.textContent=text||'';if(cls)e.className=cls;parent.append(e);return e}
 function styleTheme(){
  let state={};try{state=JSON.parse(localStorage.getItem('sb-web-v2'))||{}}catch{}
  const root=document.documentElement;const custom=(state.customThemes||[]).find(t=>t.id===state.appearance);
  const safeColor=x=>/^#[a-f0-9]{6}$/i.test(x||'');
  const colors=custom?.colors||{};
  const pairs={'--sm-bg':colors.background,'--sm-panel':colors.toolbar||colors.surface,'--sm-surface':colors.surface,'--sm-ink':colors.text,'--sm-muted':colors.muted,'--sm-accent':colors.accent,'--sm-line':colors.border};
  for(const [key,val] of Object.entries(pairs)){if(safeColor(val))root.style.setProperty(key,val);else root.style.removeProperty(key)}
  if(safeColor(state.accent)&&!custom)root.style.setProperty('--sm-accent',state.accent);
  root.style.fontFamily=custom?.font==='mono'?'ui-monospace,monospace':custom?.font==='serif'?'Georgia,serif':custom?.font==='rounded'?'Trebuchet MS,system-ui':'system-ui,-apple-system,Segoe UI,sans-serif';
 }
 styleTheme();window.addEventListener('storage',e=>{if(e.key==='sb-web-v2')styleTheme()});
 window.addEventListener('message',e=>{if(e.origin===location.origin&&e.data?.type==='secure-browser:appearance')styleTheme()});
 function centerMap(place){
  if(!$('photoPanel').classList.contains('sm-hide'))closePanorama();
  if(!place||!valid(Number(place.lat),Number(place.lng)))return;
  selected={lat:Number(place.lat),lng:Number(place.lng),label:String(place.label||place.name||'Selected location').slice(0,120)};
  try{localStorage.setItem(storageKey,JSON.stringify(selected))}catch{}
  $('currentPlace').textContent=selected.label;
  if(mapReady)map.contentWindow.postMessage({type:'secure-browser:satellite-center',...selected},location.origin);
  else{const src=new URL('satellite-map.html',location.href);src.searchParams.set('panoramax','1');src.searchParams.set('lat',selected.lat);src.searchParams.set('lng',selected.lng);src.searchParams.set('zoom','14');src.searchParams.set('name',selected.label);map.src=src.href;}
  $('coverageStatus').textContent='Loading street-photo coverage…';coverageLoaded=false;
 }
 const getQuery=()=>String($('placeInput').value||'').trim().slice(0,150);
 async function search(term){
  term=String(term||'').trim().slice(0,150);if(!term)return;
  $('placeInput').value=term;const token=++requestNo;
  $('placesHeading').textContent='Location results';$('placeStatus').textContent='Searching locations…';$('placeResults').replaceChildren();
  try{
   const response=await fetch('/api/media?kind=maps&q='+encodeURIComponent(term),{headers:{Accept:'application/json'}});
   if(!response.ok)throw new Error('Search request failed');
   const json=await response.json();if(token!==requestNo)return;
   const places=(json.items||[]).filter(p=>valid(Number(p.lat),Number(p.lng)));
   $('placeStatus').textContent=places.length?places.length+' matching locations':'No matching locations. Try a broader search.';
   places.slice(0,10).forEach((place,index)=>{
    const b=document.createElement('button');b.type='button';b.className='sm-result';
    const icon=addText(b,'span','⌖','sm-result-icon');icon.setAttribute('aria-hidden','true');
    const content=document.createElement('span');addText(content,'strong',String(place.name||'Unnamed location').slice(0,160));addText(content,'small',String(place.kind||'Place').slice(0,70));b.append(content);
    b.addEventListener('click',()=>{selectPlace(place,index);b.blur()});$('placeResults').append(b);
   });
   if(places.length)selectPlace(places[0],0);
  }catch{if(token===requestNo)$('placeStatus').textContent='Place search is temporarily unavailable. Please try again.';}
 }
 function selectPlace(place,index){
  selectedPlaceId=index;
  [...$('placeResults').children].forEach((e,i)=>{e.classList.toggle('active',i===index);e.setAttribute('aria-pressed',String(i===index))});
  centerMap({lat:place.lat,lng:place.lng,label:place.name});
 }
 function showPanorama(photo){
  if(!photo?.picture||!photo?.sequence)return;
  if(!/^[\w:-]{6,128}$/.test(photo.picture)||!/^[\w:-]{6,128}$/.test(photo.sequence))return;
  const url=new URL('secure-panoramax.html',location.href);
  url.searchParams.set('picture',photo.picture);url.searchParams.set('sequence',photo.sequence);
  picture.src=url.href;
  $('photoPanel').classList.remove('sm-hide');$('photoCloseTop').classList.remove('sm-hide');
  $('photoDetails').textContent=photo.date?String(photo.date).slice(0,10):'Street-level photo';
  // The viewer's published share URLs use pic/seq parameters. Keep a stable
  // public fallback link for any browser blocking the Panoramax CDN.
  const external=new URL('https://explore.panoramax.fr/');external.searchParams.set('pic',photo.picture);external.searchParams.set('seq',photo.sequence);
  $('photoExternal').href=external.href;
 }
 function closePanorama(){picture.removeAttribute('src');$('photoPanel').classList.add('sm-hide');$('photoCloseTop').classList.add('sm-hide')}
 window.addEventListener('message',event=>{
  if(event.origin!==location.origin||event.source!==map.contentWindow||!event.data)return;
  const data=event.data;
  if(data.type==='secure-browser:satellite-ready'){
   mapReady=true;map.contentWindow.postMessage({type:'secure-browser:satellite-center',...selected},location.origin);
   map.contentWindow.postMessage({type:'secure-maps:coverage-toggle',enabled:$('coverageToggle').checked},location.origin);
  }
  if(data.type==='secure-maps:coverage-status'){
   coverageLoaded=true;coverageCount=Number(data.count)||0;
   $('coverageStatus').textContent=data.failed?'Street photos temporarily unavailable.':data.tooFar?'Photos found, but none close to this location.':coverageCount?coverageCount+' nearby photo points available.':'No Panoramax photos here. Try another area or zoom in.';
   $('mapHint').textContent=data.failed?'Street-photo service temporarily unavailable':coverageCount?'Tap a blue mark to enter street view':'No blue photo coverage in this area';
  }
  if(data.type==='secure-maps:panoramax-select')showPanorama(data);
 });
 $('placeForm').addEventListener('submit',e=>{e.preventDefault();search(getQuery())});
 $('quickLocations').addEventListener('click',e=>{const b=e.target.closest('button[data-search]');if(b)search(b.dataset.search)});
 $('coverageToggle').addEventListener('change',e=>{map.contentWindow?.postMessage({type:'secure-maps:coverage-toggle',enabled:e.target.checked},location.origin);$('mapHint').textContent=e.target.checked?'Blue marks = available Panoramax photos':'Photo coverage hidden';if(!e.target.checked)$('coverageStatus').textContent='Photo coverage is turned off.'});
 $('nearest').addEventListener('click',()=>{
  if(!$('coverageToggle').checked){$('coverageToggle').checked=true;$('coverageToggle').dispatchEvent(new Event('change'))}
  if(!coverageLoaded)toast('Loading Panoramax coverage…');
  else if(!coverageCount)toast('No street photos found here yet. Try another place.');
  map.contentWindow?.postMessage({type:'secure-maps:find-nearest'},location.origin);
 });
 $('streetAction').addEventListener('click',()=>$('nearest').click());
 $('closePhoto').addEventListener('click',closePanorama);$('photoCloseTop').addEventListener('click',closePanorama);
 $('shareMap').addEventListener('click',async()=>{
  const url=new URL('secure-maps.html',location.href);url.searchParams.set('lat',selected.lat);url.searchParams.set('lng',selected.lng);url.searchParams.set('name',selected.label);
  try{await navigator.clipboard.writeText(url.href);toast('Map link copied')}catch{toast('Copy unavailable on this device')}
 });
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('photoPanel').classList.contains('sm-hide'))closePanorama()});
 if(params.has('q'))search(params.get('q'));
 centerMap(selected);
})();
