(()=>{'use strict';
 const $=id=>document.getElementById(id);
 const map=$('satelliteFrame'),params=new URLSearchParams(location.search);
 const valid=(lat,lng)=>Number.isFinite(lat)&&Number.isFinite(lng)&&Math.abs(lat)<=85&&Math.abs(lng)<=180;
 const storageKey='secure-maps:last-location-v1';
 const readLast=()=>{try{return JSON.parse(localStorage.getItem(storageKey))}catch{return null}};
 let selected={lat:48.8566,lng:2.3522,label:'Paris, France'};
 const paramLat=Number(params.get('lat')),paramLng=Number(params.get('lng'));
 const previous=readLast();
 if(params.has('lat')&&params.has('lng')&&valid(paramLat,paramLng))selected={lat:paramLat,lng:paramLng,label:(params.get('name')||'Selected location').slice(0,120)};
 else if(previous&&valid(Number(previous.lat),Number(previous.lng)))selected={lat:Number(previous.lat),lng:Number(previous.lng),label:String(previous.label||'Selected location').slice(0,120)};
 let mapReady=false,requestNo=0;
 function styleTheme(){
  let state={};try{state=JSON.parse(localStorage.getItem('sb-web-v2'))||{}}catch{}
  const root=document.documentElement,custom=(state.customThemes||[]).find(t=>t.id===state.appearance);
  const safeColor=x=>/^#[a-f0-9]{6}$/i.test(x||'');
  const colors=custom?.colors||{};
  const pairs={'--sm-bg':colors.background,'--sm-panel':colors.toolbar||colors.surface,'--sm-surface':colors.surface,'--sm-ink':colors.text,'--sm-muted':colors.muted,'--sm-accent':colors.accent,'--sm-line':colors.border};
  for(const [key,val] of Object.entries(pairs)){if(safeColor(val))root.style.setProperty(key,val);else root.style.removeProperty(key)}
  if(safeColor(state.accent)&&!custom)root.style.setProperty('--sm-accent',state.accent);
  root.style.fontFamily=custom?.font==='mono'?'ui-monospace,monospace':custom?.font==='serif'?'Georgia,serif':custom?.font==='rounded'?'Trebuchet MS,system-ui':'system-ui,-apple-system,Segoe UI,sans-serif';
 }
 styleTheme();
 window.addEventListener('storage',e=>{if(e.key==='sb-web-v2')styleTheme()});
 window.addEventListener('message',e=>{if(e.origin===location.origin&&e.data?.type==='secure-browser:appearance')styleTheme()});
 function centerMap(place){
  if(!place||!valid(Number(place.lat),Number(place.lng)))return;
  selected={lat:Number(place.lat),lng:Number(place.lng),label:String(place.label||place.name||'Selected location').slice(0,120)};
  try{localStorage.setItem(storageKey,JSON.stringify(selected))}catch{}
  if(mapReady)map.contentWindow.postMessage({type:'secure-browser:satellite-center',...selected},location.origin);
  else{const src=new URL('satellite-map.html',location.href);
   src.searchParams.set('lat',selected.lat);src.searchParams.set('lng',selected.lng);src.searchParams.set('zoom','14');src.searchParams.set('name',selected.label);map.src=src.href;}
 }
 const getQuery=()=>String($('placeInput').value||'').trim().slice(0,150);
 function openSearchResults(){$('searchDropdown').hidden=false;$('placeInput').setAttribute('aria-expanded','true')}
 function closeSearchResults(){$('searchDropdown').hidden=true;$('placeInput').setAttribute('aria-expanded','false')}
 function addText(parent,tag,text,cls){const el=document.createElement(tag);el.textContent=text||'';if(cls)el.className=cls;parent.append(el);return el}
 function selectPlace(place,index){
  [...$('placeResults').children].forEach((el,i)=>{el.classList.toggle('active',i===index);el.setAttribute('aria-pressed',String(i===index))});
  centerMap({lat:place.lat,lng:place.lng,label:place.name});closeSearchResults();
 }
 async function search(term){
  term=String(term||'').trim().slice(0,150);if(!term)return;
  $('placeInput').value=term;const request=++requestNo;
  $('placesHeading').textContent='Search results';$('placeStatus').textContent='Searching locations…';$('placeResults').replaceChildren();openSearchResults();
  try{
   const response=await fetch('/api/media?kind=maps&q='+encodeURIComponent(term),{headers:{Accept:'application/json'}});
   if(!response.ok)throw Error('Place search failed');
   const json=await response.json();if(request!==requestNo)return;
   const places=(json.items||[]).filter(p=>valid(Number(p.lat),Number(p.lng))).slice(0,12);
   $('placeStatus').textContent=places.length?places.length+' matching locations':'No results. Try a broader search.';
   places.forEach((place,index)=>{
    const button=document.createElement('button');button.type='button';button.className='sm-result';
    const icon=addText(button,'span','⌖','sm-result-icon');icon.setAttribute('aria-hidden','true');
    const content=document.createElement('span');addText(content,'strong',String(place.name||'Unnamed location').slice(0,160));
    addText(content,'small',String(place.kind||'Place').slice(0,70));button.append(content);
    button.addEventListener('click',()=>selectPlace(place,index));$('placeResults').append(button);
   });
  }catch{if(request===requestNo)$('placeStatus').textContent='Search temporarily unavailable. Please try again.'}
 }
 window.addEventListener('message',e=>{
  if(e.origin!==location.origin||e.source!==map.contentWindow||e.data?.type!=='secure-browser:satellite-ready')return;
  if(mapReady)return; // Do not reset the map on later ready/refresh messages.
  mapReady=true;map.contentWindow.postMessage({type:'secure-browser:satellite-center',...selected},location.origin);
 });
 $('placeForm').addEventListener('submit',e=>{e.preventDefault();search(getQuery())});
 $('placeInput').addEventListener('input',()=>{if(!getQuery()){++requestNo;closeSearchResults();$('placeResults').replaceChildren()}});
 $('placeInput').addEventListener('focus',()=>{if(getQuery()&&$('placeResults').children.length)openSearchResults()});
 $('closeSearch').addEventListener('click',closeSearchResults);
 document.addEventListener('pointerdown',e=>{if(!$('searchArea').contains(e.target))closeSearchResults()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('searchDropdown').hidden)closeSearchResults()});
 if(params.has('q'))search(params.get('q'));
 centerMap(selected);
})();
