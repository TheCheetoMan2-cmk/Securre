(()=>{'use strict';
 const $=id=>document.getElementById(id);
 const map=$('satelliteFrame'),picture=$('photoFrame');
 const params=new URLSearchParams(location.search);
 const valid=(lat,lng)=>Number.isFinite(lat)&&Number.isFinite(lng)&&Math.abs(lat)<=85&&Math.abs(lng)<=180;
 const storageKey='secure-maps:last-location-v1';
 const readLast=()=>{try{return JSON.parse(localStorage.getItem(storageKey))}catch{return null}};
 let selected={lat:48.8566,lng:2.3522,label:'Paris, France'};
 const paramLat=Number(params.get('lat')),paramLng=Number(params.get('lng'));
 if(params.has('lat')&&params.has('lng')&&valid(paramLat,paramLng))selected={lat:paramLat,lng:paramLng,label:(params.get('name')||'Selected location').slice(0,120)};
 else if(readLast()&&valid(Number(readLast().lat),Number(readLast().lng)))selected=readLast();
 let mapReady=false,requestNo=0,selectedPlaceId=-1,coverageCount=0,coverageLoaded=false;
 // This application uses a preset Mapillary client token. There is no token editor in Secure Maps.
 const DEFAULT_MAPILLARY_TOKEN='MLY|29451732037753946|8d55c6c7797eee19807cc62dc3b64806';
 const mapillaryTokenValid=v=>/^[A-Za-z0-9_|.-]{12,500}$/.test(v||'');
 let coverageEnabled=true, mapillaryCount=0, mapillaryFailed=false, mapillaryError='', lastCoverageAlert=0;
 let mapillaryToken=DEFAULT_MAPILLARY_TOKEN;
 // Always start with Street View ON. Stale disabled preferences from older
 // releases previously left users with a blank coverage map after upgrades.
 function sendMapillaryToken(){if(mapReady)map.contentWindow.postMessage({type:'secure-maps:mapillary-token',token:mapillaryToken},location.origin)}
 function updateCoverageStatus(){
  if(!coverageEnabled){$('coverageStatus').textContent='Street coverage is off.';$('mapHint').textContent='Turn on Street View Coverage to show blue roads and dots';return;}
  let message=[];
  if(mapillaryTokenValid(mapillaryToken))message.push(mapillaryCount?(mapillaryCount+' Mapillary features'):(mapillaryFailed?'Mapillary unavailable':'Mapillary loading / no coverage'));
  else message.push('Mapillary token needed');
  message.push(coverageCount?coverageCount+' Panoramax photos':'Panoramax searching / no photos');
  $('coverageStatus').textContent=message.join(' · ');
  $('mapHint').textContent=mapillaryCount||coverageCount?'Tap a blue street or photo dot to view images':(mapillaryFailed?(mapillaryError||'Mapillary coverage is temporarily unavailable'):'Searching for blue streets and photos…');
  $('coverageToggle').classList.toggle('sm-coverage-error',coverageEnabled&&mapillaryFailed&&!mapillaryCount&&!coverageCount);
  $('coverageToggle').title=coverageEnabled&&mapillaryFailed&&!mapillaryCount?(mapillaryError||'Mapillary coverage unavailable'):(coverageEnabled?'Hide blue street photo coverage':'Show blue street photo coverage');
 }
 function setCoverage(enabled){
  coverageEnabled=!!enabled;
  const button=$('coverageToggle');button.setAttribute('aria-pressed',String(coverageEnabled));
  button.title=coverageEnabled?'Hide blue street photo coverage':'Show blue street photo coverage';
  if(mapReady)map.contentWindow.postMessage({type:'secure-maps:coverage-toggle',enabled:coverageEnabled},location.origin);
  updateCoverageStatus();

 }
 // A Render environment token may be configured by the deployer, but not edited in the UI.
 fetch('/api/mapillary/config',{credentials:'same-origin'}).then(r=>r.ok?r.json():{}).then(c=>{
  if(mapillaryTokenValid(c.clientToken)&&mapillaryToken!==c.clientToken){mapillaryToken=c.clientToken;sendMapillaryToken();updateCoverageStatus()}
 }).catch(()=>{});
 let toastTimer;
 function toast(msg){const e=$('toast');e.textContent=msg;e.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.classList.remove('visible'),2800)}
 function addText(parent,tag,text,cls){const e=document.createElement(tag);e.textContent=text||'';if(cls)e.className=cls;parent.append(e);return e}
 function styleTheme(){
  let state={};try{state=JSON.parse(localStorage.getItem('sb-web-v2'))||{}}catch{}
  const root=document.documentElement;const custom=(state.customThemes||[]).find(t=>t.id===state.appearance);
  const safeColor=x=>/^#[a-f0-9]{6}$/i.test(x||'');
  const colors=custom?.colors||{};
  const pairs={'--sm-bg':colors.background,'--sm-panel':colors.toolbar||colors.surface,'--sm-surface':colors.surface,'--sm-ink':colors.text,'--sm-muted':colors.muted,'--sm-accent':colors.accent,'--sm-line':colors.border};
  for(const [key,val] of Object.entries(pairs)){if(safeColor(val))root.style.setProperty(key,val);else root.style.removeProperty(key)}
  if(safeColor(state.accent)&&!custom)root.style.setProperty('--sm-accent',state.accent);
  root.style.fontFamily=custom?.font==='mono'?'ui-monospace,monospace':custom?.font==='serif'?'Georgia,serif':custom?.font==='rounded'?'Trebuchet MS,system-ui':'system-ui,-apple-system,Segoe UI,sans-serif';
 }
 styleTheme();window.addEventListener('storage',e=>{if(e.key==='sb-web-v2')styleTheme()});
 window.addEventListener('message',e=>{if(e.origin===location.origin&&e.data?.type==='secure-browser:appearance')styleTheme()});
 function centerMap(place){
  if(!$('photoPanel').classList.contains('sm-hide'))closePanorama();
  if(!place||!valid(Number(place.lat),Number(place.lng)))return;
  selected={lat:Number(place.lat),lng:Number(place.lng),label:String(place.label||place.name||'Selected location').slice(0,120)};
  try{localStorage.setItem(storageKey,JSON.stringify(selected))}catch{}
  if(mapReady)map.contentWindow.postMessage({type:'secure-browser:satellite-center',...selected},location.origin);
  else{const src=new URL('satellite-map.html',location.href);src.searchParams.set('panoramax','1');src.searchParams.set('lat',selected.lat);src.searchParams.set('lng',selected.lng);src.searchParams.set('zoom','14');src.searchParams.set('name',selected.label);map.src=src.href;}
  coverageCount=0;mapillaryCount=0;coverageLoaded=false;updateCoverageStatus();
 }
 const getQuery=()=>String($('placeInput').value||'').trim().slice(0,150);
 async function search(term){
  term=String(term||'').trim().slice(0,150);if(!term)return;
  $('placeInput').value=term;const token=++requestNo;
  openSearchResults();$('placesHeading').textContent='Search results';$('placeStatus').textContent='Searching locations…';$('placeResults').replaceChildren();
  try{
   const response=await fetch('/api/media?kind=maps&q='+encodeURIComponent(term),{headers:{Accept:'application/json'}});
   if(!response.ok)throw new Error('Search request failed');
   const json=await response.json();if(token!==requestNo)return;
   const places=(json.items||[]).filter(p=>valid(Number(p.lat),Number(p.lng)));
   $('placeStatus').textContent=places.length?places.length+' matching locations':'No matching locations. Try a broader search.';
   places.slice(0,25).forEach((place,index)=>{
    const b=document.createElement('button');b.type='button';b.className='sm-result';
    const icon=addText(b,'span','⌖','sm-result-icon');icon.setAttribute('aria-hidden','true');
    const content=document.createElement('span');addText(content,'strong',String(place.name||'Unnamed location').slice(0,160));addText(content,'small',String(place.kind||'Place').slice(0,70));b.append(content);
    b.addEventListener('click',()=>{selectPlace(place,index);closeSearchResults();b.blur()});$('placeResults').append(b);
   });
   if(places.length)selectPlace(places[0],0);
  }catch{if(token===requestNo)$('placeStatus').textContent='Place search is temporarily unavailable. Please try again.';}
 }
 function selectPlace(place,index){
  selectedPlaceId=index;
  [...$('placeResults').children].forEach((e,i)=>{e.classList.toggle('active',i===index);e.setAttribute('aria-pressed',String(i===index))});
  centerMap({lat:place.lat,lng:place.lng,label:place.name});
 }
 function showPanorama(photo){
  if(!photo?.picture||!photo?.sequence)return;
  if(!/^[\w:-]{6,128}$/.test(photo.picture)||!/^[\w:-]{6,128}$/.test(photo.sequence))return;
  const url=new URL('secure-panoramax.html',location.href);
  url.searchParams.set('picture',photo.picture);url.searchParams.set('sequence',photo.sequence);
  picture.src=url.href;
  $('photoProvider').textContent='Panoramax';$('photoFooterText').textContent='Community imagery via Panoramax';
  $('photoPanel').classList.remove('sm-hide');closeSearchResults();
  $('photoDetails').textContent=photo.date?String(photo.date).slice(0,10):'Street-level photo';
  // The viewer's published share URLs use pic/seq parameters. Keep a stable
  // public fallback link for any browser blocking the Panoramax CDN.
  const external=new URL('https://explore.panoramax.fr/');external.searchParams.set('pic',photo.picture);external.searchParams.set('seq',photo.sequence);
  $('photoExternal').href=external.href;
 }
 function showMapillary(photo){
  const id=String(photo?.imageId||'');if(!/^\d{4,25}$/.test(id))return;
  if(!mapillaryTokenValid(mapillaryToken)){toast('Mapillary coverage is unavailable.');return}
  const url=new URL('secure-mapillary.html',location.href);
  picture.src=url.href;
  const onLoad=()=>{if(picture.contentWindow)picture.contentWindow.postMessage({type:'secure-maps:mapillary-open',token:mapillaryToken,imageId:id},location.origin)};
  picture.addEventListener('load',onLoad,{once:true});
  $('photoProvider').textContent='Mapillary';$('photoFooterText').textContent='© Mapillary contributors · Tap arrows to move between photographs';
  $('photoDetails').textContent='Street-level image';
  $('photoPanel').classList.remove('sm-hide');closeSearchResults();
  const external=new URL('https://www.mapillary.com/app/');external.searchParams.set('pKey',id);
  $('photoExternal').href=external.href;
 }
 function closePanorama(){picture.removeAttribute('src');$('photoPanel').classList.add('sm-hide')}
 function syncMapConfig(){
  if(!map.contentWindow)return;
  const recipient=map.contentWindow;
  // Idempotent settings only. A HELLO in this function previously caused
  // ready -> hello -> ready indefinitely, snapping the map back each time.
  recipient.postMessage({type:'secure-maps:coverage-toggle',enabled:coverageEnabled},location.origin);
  recipient.postMessage({type:'secure-maps:mapillary-token',token:mapillaryToken},location.origin);
 }
 // HELLO is a one-time fallback per iframe load, not a response to READY.
 map.addEventListener('load',()=>{
  mapReady=false;
  map.contentWindow?.postMessage({type:'secure-maps:hello'},location.origin);
 });
 window.addEventListener('message',event=>{
  if(event.origin!==location.origin||event.source!==map.contentWindow||!event.data)return;
  const data=event.data;
  if(data.type==='secure-browser:satellite-ready'){
   // The iframe already starts from the selected URL. Only a real user
   // search should send satellite-center; never recenter on a ready message.
   mapReady=true;syncMapConfig();
  }
  if(data.type==='secure-maps:coverage-status'){
   coverageLoaded=true;coverageCount=Number(data.count)||0;
   updateCoverageStatus();
  }
  if(data.type==='secure-maps:map-pointer')closeSearchResults();
  if(data.type==='secure-maps:panoramax-select')showPanorama(data);
  if(data.type==='secure-maps:mapillary-select')showMapillary(data);
  if(data.type==='secure-maps:mapillary-status'){mapillaryCount=Number(data.count)||0;mapillaryFailed=!!data.failed;mapillaryError=String(data.error||'').slice(0,120);updateCoverageStatus();if(mapillaryFailed&&!mapillaryCount&&mapillaryError&&Date.now()-lastCoverageAlert>45000){lastCoverageAlert=Date.now();toast(mapillaryError)}}
  if(data.type==='secure-maps:notice'&&typeof data.message==='string')toast(data.message.slice(0,140));
 });
 function openSearchResults(){
  $('searchDropdown').hidden=false;
  $('placeInput').setAttribute('aria-expanded','true');
 }
 function closeSearchResults(){
  $('searchDropdown').hidden=true;
  $('placeInput').setAttribute('aria-expanded','false');
 }
 $('placeForm').addEventListener('submit',e=>{e.preventDefault();search(getQuery())});
 $('placeInput').addEventListener('input',()=>{if(!getQuery()){++requestNo;closeSearchResults();$('placeResults').replaceChildren()}});
 $('placeInput').addEventListener('focus',()=>{if(getQuery()&&$('placeResults').children.length)openSearchResults()});
 $('closeSearch').addEventListener('click',closeSearchResults);
 document.addEventListener('pointerdown',e=>{if(!$('searchArea').contains(e.target))closeSearchResults()});
 $('coverageToggle').addEventListener('click',()=>setCoverage(!coverageEnabled));
 $('closePhoto').addEventListener('click',closePanorama);
 document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){
   if(!$('searchDropdown').hidden)closeSearchResults();
   else if(!$('photoPanel').classList.contains('sm-hide'))closePanorama();
  }
 });
 if(params.has('q'))search(params.get('q'));
 centerMap(selected);setCoverage(coverageEnabled);
})();
