/* Minimal Mapbox Vector Tile decoder for the public Mapillary sequence/image layers.
 * Uses no third-party code; it never executes code from map tiles.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.SecureMapillaryVector=api;})(typeof window!=='undefined'?window:globalThis,function(){
 'use strict';
 const utf8=new TextDecoder('utf-8');
 class Reader{
  constructor(bytes){this.b=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);this.i=0;this.end=this.b.length;}
  varint(){let n=0n,shift=0n;for(let j=0;j<10;j++){if(this.i>=this.end)throw Error('Truncated vector tile');const c=this.b[this.i++];n|=BigInt(c&127)<<shift;if(!(c&128))return n;shift+=7n;}throw Error('Invalid vector tile varint');}
  num(){return Number(this.varint());}
  bytes(){const length=this.num(),end=this.i+length;if(length<0||end>this.end)throw Error('Invalid vector tile length');const v=this.b.subarray(this.i,end);this.i=end;return v;}
  skip(w){if(w===0){this.varint();return}if(w===2){this.bytes();return}if(w===1||w===5){this.i+=w===1?8:4;if(this.i>this.end)throw Error('Truncated tile');return}throw Error('Unsupported tile wire type')}
  each(callback){while(this.i<this.end){const t=this.num(),field=Math.floor(t/8),wire=t&7;if(!field)throw Error('Invalid vector tile field');callback(field,wire,this)}}
 }
 function packed(bytes){const r=new Reader(bytes),values=[];while(r.i<r.end){if(values.length>300000)break;values.push(r.num())}return values;}
 function value(bytes){const r=new Reader(bytes);let v=null;r.each((f,w,p)=>{if(f===1&&w===2)v=utf8.decode(p.bytes());else if(f===2&&w===5){const b=p.b.subarray(p.i,p.i+4);v=new DataView(b.buffer,b.byteOffset,b.byteLength).getFloat32(0,true);p.i+=4;}else if(f===3&&w===1){const b=p.b.subarray(p.i,p.i+8);v=new DataView(b.buffer,b.byteOffset,b.byteLength).getFloat64(0,true);p.i+=8;}else if((f===4||f===5||f===6||f===7)&&w===0){const n=p.varint();v=f===7?!!n:String(f===6?(n>>1n)^(-(n&1n)):n);}else p.skip(w)});return v;}
 // Decode only geometry needed for interactive blue coverage.
 function geom(commands,type,extent){let x=0,y=0,i=0,paths=[],path=[];const cap=Math.min(commands.length,150000);while(i<cap){const cmd=commands[i++],kind=cmd&7,count=cmd>>>3;if(count>50000)break;if(kind===1||kind===2){for(let j=0;j<count&&i+1<cap;j++){const a=commands[i++],b=commands[i++];x+=(a>>>1)^-(a&1);y+=(b>>>1)^-(b&1);if(kind===1){if(path.length)paths.push(path);path=[];}path.push([x/extent,y/extent]);}}else if(kind===7){if(path.length>2)path.push(path[0]);}else break;}
  if(path.length)paths.push(path);return type===1?paths.flat():paths;
 }
 function feature(bytes,keys,values,extent){const r=new Reader(bytes);let id='',type=0,tags=[],geometry=[];r.each((f,w,p)=>{if(f===1&&w===0)id=p.varint().toString();else if(f===2&&w===2)tags=packed(p.bytes());else if(f===3&&w===0)type=p.num();else if(f===4&&w===2)geometry=packed(p.bytes());else p.skip(w)});const props={};for(let i=0;i+1<tags.length;i+=2){if(keys[tags[i]]!==undefined)props[keys[tags[i]]]=values[tags[i+1]]}return {id,props,type,paths:geom(geometry,type,extent)};}
 function layer(bytes){const r=new Reader(bytes);let name='',extent=4096,keys=[],values=[],raw=[];r.each((f,w,p)=>{if(f===1&&w===2)name=utf8.decode(p.bytes());else if(f===2&&w===2)raw.push(p.bytes());else if(f===3&&w===2)keys.push(utf8.decode(p.bytes()));else if(f===4&&w===2)values.push(value(p.bytes()));else if(f===5&&w===0)extent=p.num();else p.skip(w)});return {name,features:raw.slice(0,30000).map(b=>feature(b,keys,values,extent))};}
 function decode(bytes){const r=new Reader(bytes),out={};if(r.end>8*1024*1024)throw Error('Oversized vector tile');r.each((f,w,p)=>{if(f===3&&w===2){const data=layer(p.bytes());if(data.name==='sequence'||data.name==='image'||data.name==='overview')out[data.name]=data.features;}else p.skip(w)});return out;}
 return {decode};
});
