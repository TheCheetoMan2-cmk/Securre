/* Secure Search loads only validated palette values and image blobs from Secure Browser. */
(()=>{'use strict';
 const root=document.documentElement,KEYS=['accent','background','surface','text','muted','border','buttonText'];
 const DEFAULT_ICON='assets/secure-search-icon.webp';let activeImages=[],ticket=0;
 const get=k=>{try{return localStorage.getItem(k)||'';}catch{return '';}};
 function appearance(){const ss=get('sb-sstheme-v1'),home=get('sb-appearance-v1');return ss||home;}
 function theme(){try{const s=JSON.parse(get('sb-web-v2'));return s?.customThemes?.find(t=>t.id===appearance())||null;}catch{return null;}}
 function openDb(){return new Promise((res,rej)=>{const req=indexedDB.open('sb-web-files',1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('f'))req.result.createObjectStore('f');};req.onsuccess=()=>res(req.result);req.onerror=()=>rej(req.error);});}
 async function image(id,kind){try{const db=await openDb();return await new Promise(resolve=>{const tx=db.transaction('f','readonly'),req=tx.objectStore('f').get('sbt:'+id+':'+kind);req.onsuccess=()=>{const b=req.result;resolve(b instanceof Blob&&/^image\/(png|jpeg|webp|gif)$/.test(b.type)?b:null);};req.onerror=()=>resolve(null);tx.oncomplete=()=>db.close();});}catch{return null;}}
 function fallbackWall(){try{const p=getComputedStyle(parent.document.documentElement).getPropertyValue('--start-bg').trim();if(p&&/^url\(/i.test(p))return p;}catch{}return 'url("assets/image-4928151514d8.png")';}
 function clearImage(){for(const u of activeImages)URL.revokeObjectURL(u);activeImages=[];}
 async function update(){const curr=++ticket,t=theme();if(!t){root.removeAttribute('data-sbt-style');root.style.removeProperty('--ss-wallpaper');root.style.removeProperty('--sbt-bg');clearImage();document.querySelectorAll('.brand-icon,.home-brand-icon').forEach(img=>img.src=DEFAULT_ICON);return;}
  if(!t.colors||KEYS.some(k=>typeof t.colors[k]!=='string'||!/^#[0-9a-f]{6}$/i.test(t.colors[k]))||!['glass','solid','aero'].includes(t.style)||!Number.isInteger(t.opacity)||!Number.isInteger(t.radius)||!Number.isInteger(t.dim))return;
  root.dataset.appearance='custom';delete root.dataset.sstheme;root.dataset.sbtStyle=t.style;root.classList.remove('light');
  for(const [k,v] of Object.entries(t.colors))root.style.setProperty('--sbt-'+k,v);
  root.style.setProperty('--sbt-tabs',/^#[0-9a-f]{6}$/i.test(t.colors.tabs||'')?t.colors.tabs:t.colors.surface);
  root.style.setProperty('--sbt-bg',t.colors.background);root.style.setProperty('--sbt-alpha',Math.max(20,Math.min(100,t.opacity))+'%');root.style.setProperty('--sbt-radius',Math.max(8,Math.min(40,t.radius))+'px');root.style.setProperty('--sbt-dim',(Math.max(0,Math.min(80,t.dim))/100).toFixed(2));root.style.setProperty('--sbt-image-fit',t.wallpaperFit==='contain'?'contain':'cover');root.style.setProperty('--sbt-image-position',['center','top','bottom','left','right'].includes(t.wallpaperPosition)?t.wallpaperPosition:'center');
  const [search,start,logo]=await Promise.all([image(t.id,'search'),image(t.id,'start'),image(t.id,'logo')]);
  if(curr!==ticket)return;clearImage();const photo=search||start;if(photo){const url=URL.createObjectURL(photo);activeImages.push(url);root.style.setProperty('--ss-wallpaper',`url("${url}")`);}else root.style.setProperty('--ss-wallpaper',fallbackWall());
  const icon=logo?URL.createObjectURL(logo):DEFAULT_ICON;if(logo)activeImages.push(icon);document.querySelectorAll('.brand-icon,.home-brand-icon').forEach(img=>img.src=icon);
 }
 update();window.addEventListener('storage',e=>{if(['sb-appearance-v1','sb-sstheme-v1','sb-web-v2'].includes(e.key))update();});
 window.addEventListener('message',e=>{if(e.origin===location.origin&&e.data?.type==='secure-browser:appearance')update();});
})();
