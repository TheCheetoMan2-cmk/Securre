/* Geographic projection helpers for Secure Browser's satellite map.
 * Web Mercator (EPSG:3857), matching the Esri tiled imagery grid.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.SatelliteMath = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const TILE_SIZE = 256;
  const MAX_LATITUDE = 85.0511287798;
  const MIN_ZOOM = 2;
  const MAX_ZOOM = 23;
  // World Imagery publishes a tile grid to level 23, but fine detail varies by location.
  const NATIVE_MAX_ZOOM = 23;
  const LABEL_MAX_ZOOM = 19;
  const MIN_FALLBACK_ZOOM = 14;
  function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }
  function wrapLongitude(value) { return ((value + 180) % 360 + 360) % 360 - 180; }
  function validLocation(lat, lng) { return Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180; }
  function toPixel(lat, lng, zoom) {
    const latRad = clamp(lat, -MAX_LATITUDE, MAX_LATITUDE) * Math.PI / 180;
    const size = TILE_SIZE * 2 ** zoom;
    return {
      x: (wrapLongitude(lng) + 180) / 360 * size,
      y: (1 - Math.asinh(Math.tan(latRad)) / Math.PI) / 2 * size
    };
  }
  function fromPixel(x, y, zoom) {
    const size = TILE_SIZE * 2 ** zoom;
    const worldX = ((x % size) + size) % size;
    const worldY = clamp(y, 0, size);
    return {
      lat: (180 / Math.PI) * Math.atan(Math.sinh(Math.PI * (1 - 2 * worldY / size))),
      lng: worldX / size * 360 - 180
    };
  }
  function wrapTileX(x, zoom) { const n = 2 ** zoom; return ((x % n) + n) % n; }
  function sourceTile(viewX, viewY, viewZoom, tileZoom) {
    if (!Number.isInteger(viewZoom) || !Number.isInteger(tileZoom) || tileZoom > viewZoom || tileZoom < 0) throw new RangeError('Invalid source tile zoom');
    const factor = 2 ** (viewZoom - tileZoom);
    const sourceX = Math.floor(viewX / factor);
    const sourceY = Math.floor(viewY / factor);
    return {
      zoom: tileZoom,
      x: wrapTileX(sourceX, tileZoom),
      y: sourceY,
      // Place the correct crop of a less-detailed parent tile inside a 256px viewport.
      size: TILE_SIZE * factor,
      offsetX: 0 - ((viewX % factor + factor) % factor) * TILE_SIZE,
      offsetY: 0 - (viewY % factor) * TILE_SIZE
    };
  }
  return { TILE_SIZE, MAX_LATITUDE, MIN_ZOOM, MAX_ZOOM, NATIVE_MAX_ZOOM, LABEL_MAX_ZOOM, MIN_FALLBACK_ZOOM, clamp, wrapLongitude, validLocation, toPixel, fromPixel, wrapTileX, sourceTile };
});
