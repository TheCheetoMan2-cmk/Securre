/* Secure Browser local error showcase. No request is made to err.test. */
(function(root){
  'use strict';
  const URL_VALUE='https://err.test/';
  const CODES=Object.freeze([404,403,401,408,410,429,500,502,503,504,0]);
  function isDemoInput(value){
    const str=String(value||'').trim();
    return /^err\.test\/?$/i.test(str)||isDemoUrl(str);
  }
  function isDemoUrl(value){
    try{
      const u=new URL(String(value));
      return /^(?:https?:)$/.test(u.protocol)&&u.hostname.toLowerCase()==='err.test'&&
        (u.pathname==='/'||u.pathname==='')&&!u.search&&!u.hash&&!u.port&&
        !u.username&&!u.password;
    }catch{return false;}
  }
  function isDemoSearchUrl(value,searchPage){
    try{
      const u=new URL(String(value)),base=new URL(String(searchPage));
      return u.origin===base.origin&&u.pathname===base.pathname&&/^err\.test$/i.test((u.searchParams.get('q')||'').trim());
    }catch{return false;}
  }
  function index(value){
    const n=Number(value);
    return Number.isInteger(n)&&n>=0? n%CODES.length : 0;
  }
  root.SB_ERROR_DEMO={url:URL_VALUE,codes:CODES,isDemoInput,isDemoUrl,isDemoSearchUrl,index,next:i=>(index(i)+1)%CODES.length};
})(typeof window==='undefined'?globalThis:window);
