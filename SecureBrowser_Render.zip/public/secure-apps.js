/* Built-in Secure Browser apps. Add approved apps here in future releases. */
(function (root) {
  'use strict';
  const apps = Object.freeze([
    Object.freeze({ id: 'secure-maps', name: 'Secure Maps', subtitle: 'Satellite maps & places', icon: 'map', url: 'secure-maps.html' })
  ]);
  root.SecureBrowserApps = apps;
  if (typeof module !== 'undefined' && module.exports) module.exports = apps;
})(typeof window !== 'undefined' ? window : globalThis);
