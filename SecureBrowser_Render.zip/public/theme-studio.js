/* Secure Browser Theme Studio. .SBT = SBT1 header + validated versioned JSON with embedded image assets. */
(()=>{'use strict';
 const KINDS=['start','search','logo'],IMAGE_TYPES=['image/png','image/jpeg','image/webp','image/gif','image/avif','image/heic','image/heif'],MAX_FILE=8*1024*1024,MAX_ASSET=1_100_000;
 const COLOR_FIELDS=[['accent','Accent'],['background','Background'],['surface','Cards / search bars'],['text','Text'],['muted','Secondary text'],['border','Borders'],['buttonText','Button text']];
 const DEFAULT={name:'My Custom Theme',style:'glass',opacity:78,radius:24,dim:28,wallpaperFit:'cover',wallpaperPosition:'center',colors:{accent:'#65adff',background:'#101a2e',surface:'#203451',text:'#f4f8ff',muted:'#b5c8de',border:'#829eb5',buttonText:'#ffffff'}};
 let modal=null,draft=null,originalId=null,blobs={},objectURLs={},activeURLs={},applying=0,wasCustom=false,previewTab='start',focusBefore=null,wheelKey='accent',wheelHSV={h:210,s:60,v:100},previewUserChoice=false,previousBodyOverflow=null,editorSession=0,pendingUploads=0,previewDevice='desktop',previewResize=null;
 const $id=id=>document.getElementById(id);
 const themeById=id=>Array.isArray(S.customThemes)?S.customThemes.find(t=>t.id===id):null;
 const safeColor=v=>typeof v==='string'&&/^#[\da-f]{6}$/i.test(v);
 const cleanTheme=(data)=>{
  if(!data||typeof data!=='object'||Array.isArray(data))throw Error('Invalid theme settings');
  if(typeof data.name!=='string'||!data.name.trim()||data.name.length>60)throw Error('Theme name must be between 1 and 60 characters');
  const colors={};for(const [key] of COLOR_FIELDS){if(!safeColor(data.colors?.[key]))throw Error('Invalid color: '+key);colors[key]=data.colors[key].toLowerCase();}
  const style=data.style;if(!['glass','solid','aero'].includes(style))throw Error('Unsupported theme finish');
  const intRange=(key,min,max)=>{const value=data[key];if(!Number.isInteger(value)||value<min||value>max)throw Error('Invalid '+key);return value;};
  const wallpaperFit=['cover','contain'].includes(data.wallpaperFit)?data.wallpaperFit:'cover';
  const wallpaperPosition=['center','top','bottom','left','right'].includes(data.wallpaperPosition)?data.wallpaperPosition:'center';
  return {name:data.name.trim(),style,opacity:intRange('opacity',20,100),radius:intRange('radius',8,40),dim:intRange('dim',0,80),wallpaperFit,wallpaperPosition,colors};
 };
 function makeId(){return 'sbt-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);}
 function recordToTheme(base,id){return {...cleanTheme(base),id};}
 const setVar=(el,key,v)=>el.style.setProperty('--sbt-'+key,v);
 async function imageBlob(id,kind){try{return await dbGetK('sbt:'+id+':'+kind)||null;}catch{return null;}}
 function assetURL(blob){return blob?URL.createObjectURL(blob):null;}
 function revokeAll(map){for(const url of Object.values(map))if(url)URL.revokeObjectURL(url);}
 function uploadFile(file){return new Promise((resolve,reject)=>{
  if(!IMAGE_TYPES.includes(file.type)&&!(file.type===''&&/\.(png|jpe?g|webp|gif|avif|heic|heif)$/i.test(file.name)))return reject(Error('Choose an image from your Photos or Files (PNG, JPG, WebP, GIF, or supported phone photo)'));
  if(file.size>MAX_FILE)return reject(Error('Image is too large (8 MB maximum)'));
  if(file.type==='image/gif'||/\.gif$/i.test(file.name))return file.size<=MAX_ASSET?resolve(new Blob([file],{type:'image/gif'})):reject(Error('Animated GIFs must be under 1.1 MB'));
  const temp=URL.createObjectURL(file),img=new Image();
  img.onload=()=>{URL.revokeObjectURL(temp);const scale=Math.min(1,2400/Math.max(img.naturalWidth,img.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
   const ctx=canvas.getContext('2d');if(!ctx){reject(Error('Image processing is unavailable'));return;}ctx.drawImage(img,0,0,canvas.width,canvas.height);
   let quality=.79,downscales=0;
   const encode=()=>canvas.toBlob(blob=>{if(blob&&blob.size<=MAX_ASSET){resolve(blob);return;}
    if(quality>.39){quality-=.15;encode();return;}
    if(downscales<2){downscales++;canvas.width=Math.max(1,Math.round(canvas.width*.76));canvas.height=Math.max(1,Math.round(canvas.height*.76));ctx.drawImage(img,0,0,canvas.width,canvas.height);quality=.7;encode();return;}
    reject(Error('Could not fit image in a theme file; try a smaller image'));
   },'image/webp',quality);
   encode();};
  img.onerror=()=>{URL.revokeObjectURL(temp);reject(Error('Image could not be loaded'));};img.src=temp;
 });}
 function loadStyle(theme,r=document.documentElement){for(const [k,v] of Object.entries(theme.colors))setVar(r,k,v);setVar(r,'bg',theme.colors.background);setVar(r,'alpha',theme.opacity+'%');setVar(r,'radius',theme.radius+'px');setVar(r,'dim',theme.dim/100);setVar(r,'image-fit',theme.wallpaperFit||'cover');setVar(r,'image-position',theme.wallpaperPosition||'center');r.dataset.sbtStyle=theme.style;}
 async function applyCustom(){const request=++applying,theme=themeById(S.appearance),R=document.documentElement;
  if(!theme){R.removeAttribute('data-sbt-style');R.style.removeProperty('--sbt-start-image');if(wasCustom){wasCustom=false;const bg=$id('bgm');if(bg)loadBg();}return;}
  wasCustom=true;R.dataset.appearance='custom';R.classList.toggle('light',false);loadStyle(theme);R.style.setProperty('--accent',theme.colors.accent);
  const media=$id('bgm');if(media){media.pause();media.hidden=true;}
  const fresh={};const stored=await Promise.all(KINDS.map(k=>imageBlob(theme.id,k)));for(let i=0;i<KINDS.length;i++)fresh[KINDS[i]]=assetURL(stored[i]);
  if(request!==applying){revokeAll(fresh);return;}
  revokeAll(activeURLs);activeURLs=fresh;
  if(fresh.start)R.style.setProperty('--sbt-start-image',`url("${fresh.start}")`);else R.style.removeProperty('--sbt-start-image');
  try{document.querySelector('meta[name="theme-color"]').content=theme.colors.background;}catch{}
 }
 window.SBT_applyAppearance=applyCustom;
 async function setImages(id,files){for(const kind of KINDS){const key='sbt:'+id+':'+kind;try{if(files[kind])await dbPutK(key,files[kind]);else await dbDelK(key);}catch(err){throw Error('Could not save '+kind+' image to device storage');}}}
 function rebuildOptions(){if(!Array.isArray(S.customThemes))S.customThemes=[];
  for(let i=THEMES.length-1;i>=0;i--)if(THEMES[i][0].startsWith('sbt-'))THEMES.splice(i,1);
  for(const t of S.customThemes)THEMES.push([t.id,'★ '+t.name]);
  for(const name of ['appearsel','sstheme']){const sel=$id(name);sel.querySelectorAll('[data-sbt-custom]').forEach(o=>o.remove());
   for(const t of S.customThemes){const o=document.createElement('option');o.value=t.id;o.textContent='★ '+t.name;o.dataset.sbtCustom='1';sel.append(o);}
   const add=document.createElement('option');add.dataset.sbtCustom='1';add.value='__create__';add.textContent='＋ Create custom theme…';sel.append(add);
  }
  $id('appearsel').value=S.appearance;$id('sstheme').value=S.ssTheme||'';
 }
 function updateButtons(){const current=themeById(S.appearance)||themeById(S.ssTheme);
  $id('sbt-edit').disabled=!current;$id('sbt-export').disabled=!current;$id('sbt-share').disabled=!current;$id('sbt-edit').title=current?'Edit '+current.name:'Select a custom theme first';}
 function node(tag,cls,content){const el=document.createElement(tag);if(cls)el.className=cls;if(content!==undefined)el.textContent=content;return el;}
 function previewBackgroundKind(){return previewTab==='search'?'search':'start';}
 function jumpToPreview(kind){if(kind==='logo')kind='search';previewTab=kind;updatePreview();if(mobileStudio()&&!modal.querySelector('.sbt-preview-area').classList.contains('preview-collapsed'))modal.querySelector('.sbt-preview-area').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});}
 function uploadRow(kind,title,sub){
  const isWallpaper=kind!=='logo',row=node('div','sbt-image-row '+(isWallpaper?'sbt-wallpaper-card':'sbt-logo-card'));row.dataset.sbtKind=kind;
  const im=node('img','sbt-image-thumb');im.alt='';im.loading='eager';
  const info=node('div','sbt-image-label');info.append(node('strong',null,title),node('small',null,sub));
  const status=node('span','sbt-image-status');status.setAttribute('aria-live','polite');info.append(status);
  const actions=node('div','sbt-image-actions'),upload=node('button','sbt-image-choose','+ Add image');upload.type='button';
  const remove=node('button','sbt-remove','Remove');remove.type='button';remove.setAttribute('aria-label','Remove '+title);
  const input=node('input');input.type='file';input.accept='image/*,.heic,.heif';input.hidden=true;input.setAttribute('aria-label','Choose '+title);
  const update=(message)=>{const chosen=!!blobs[kind];im.src=objectURLs[kind]||(isWallpaper?'assets/image-4928151514d8.png':'assets/secure-search-icon.webp');
   row.classList.toggle('has-image',chosen);row.classList.remove('is-loading');upload.disabled=false;remove.disabled=!chosen;
   upload.textContent=chosen?'Change image':'+ Add image';status.textContent=message||(chosen?'✓ Added to theme':'Uses browser default');};
  const processSelected=async(file)=>{if(!file)return;const session=editorSession;const version=(Number(row.dataset.version)||0)+1;row.dataset.version=String(version);
   row.classList.add('is-loading');upload.disabled=true;status.textContent='Preparing image…';pendingUploads++;refreshSaveState();
   try{const processed=await uploadFile(file);if(session!==editorSession||row.dataset.version!==String(version))return;
    if(objectURLs[kind])URL.revokeObjectURL(objectURLs[kind]);blobs[kind]=processed;objectURLs[kind]=assetURL(processed);
    update('✓ Image ready · '+(processed.size/1024).toFixed(0)+' KB');jumpToPreview(kind);toast(title+' added to your theme');
   }catch(e){if(session===editorSession&&row.dataset.version===String(version)){update();toast(e.message||'Could not add image');}}
   finally{pendingUploads=Math.max(0,pendingUploads-1);refreshSaveState();}};
  upload.onclick=()=>input.click();remove.onclick=()=>{row.dataset.version=String((Number(row.dataset.version)||0)+1);if(objectURLs[kind])URL.revokeObjectURL(objectURLs[kind]);blobs[kind]=null;objectURLs[kind]=null;update();updatePreview();};
  input.onchange=()=>{const file=input.files?.[0];input.value='';processSelected(file);};
  row.addEventListener('dragover',e=>{if(!Array.from(e.dataTransfer?.types||[]).includes('Files'))return;e.preventDefault();row.classList.add('sbt-dragging');});
  row.addEventListener('dragleave',e=>{if(!row.contains(e.relatedTarget))row.classList.remove('sbt-dragging');});
  row.addEventListener('drop',e=>{e.preventDefault();row.classList.remove('sbt-dragging');processSelected(e.dataTransfer?.files?.[0]);});
  row.addEventListener('click',e=>{if(e.target===input||e.target.closest('button'))return;input.click();});
  actions.append(upload,remove);row.append(im,info,actions,input);update();return row;
 }
 function refreshSaveState(){if(!modal)return;for(const id of ['sbt-save','sbt-export-draft','sbt-share-draft']){const button=$id(id);if(button)button.disabled=pendingUploads>0;}}
 function toHSV(hex){const n=parseInt(hex.slice(1),16),r=((n>>16)&255)/255,g=((n>>8)&255)/255,b=(n&255)/255,max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min;let h=0;if(d){switch(max){case r:h=((g-b)/d)%6;break;case g:h=(b-r)/d+2;break;default:h=(r-g)/d+4;}h=(h*60+360)%360;}return {h,s:max?100*d/max:0,v:max*100};}
 function fromHSV(h,s,v){s/=100;v/=100;const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let r=0,g=0,b=0;if(h<60){r=c;g=x;}else if(h<120){r=x;g=c;}else if(h<180){g=c;b=x;}else if(h<240){g=x;b=c;}else if(h<300){r=x;b=c;}else{r=c;b=x;}return '#'+[r,g,b].map(n=>Math.max(0,Math.min(255,Math.round((n+m)*255))).toString(16).padStart(2,'0')).join('');}
 function setWheelKey(key){wheelKey=key;wheelHSV=toHSV(draft.colors[key]);renderWheel();}
 function renderWheel(){const root=$id('sbt-wheel-panel');if(!root)return;for(const [k,label] of COLOR_FIELDS){if(k===wheelKey)$id('sbt-wheel-title').textContent=label;}
  for(const item of modal.querySelectorAll('.sbt-color-item'))item.classList.toggle('active',item.dataset.sbtColor===wheelKey);
  const wheel=$id('sbt-wheel'),marker=$id('sbt-wheel-marker'),radius=wheel.clientWidth/2-10,rad=wheelHSV.h*Math.PI/180;
  marker.style.transform=`translate(-50%,-50%) translate(${Math.sin(rad)*radius}px,${-Math.cos(rad)*radius}px)`;
  wheel.style.setProperty('--wheel-color',draft.colors[wheelKey]);
  $id('sbt-wheel-sat').value=Math.round(wheelHSV.s);$id('sbt-wheel-val').value=Math.round(wheelHSV.v);$id('sbt-wheel-hex').value=draft.colors[wheelKey].toUpperCase();
 }
 function applyWheel(){draft.colors[wheelKey]=fromHSV(wheelHSV.h,wheelHSV.s,wheelHSV.v);const input=modal.querySelector('.sbt-color-item[data-sbt-color="'+wheelKey+'"] input[type=color]');if(input)input.value=draft.colors[wheelKey];updatePreview();renderWheel();}
 function makeWheel(){const wrap=node('div','sbt-wheel-panel');wrap.id='sbt-wheel-panel';wrap.innerHTML='<div class="sbt-wheel-title">Color wheel <span id="sbt-wheel-title">Accent</span></div><div class="sbt-wheel-flex"><div id="sbt-wheel" tabindex="0" role="slider" aria-label="Hue wheel" aria-valuemin="0" aria-valuemax="359"><div id="sbt-wheel-core"></div><div id="sbt-wheel-marker"></div></div><div class="sbt-wheel-right"><label for="sbt-wheel-sat">Saturation</label><input type="range" id="sbt-wheel-sat" min="0" max="100"><label for="sbt-wheel-val">Brightness</label><input type="range" id="sbt-wheel-val" min="0" max="100"><label for="sbt-wheel-hex">HEX color</label><input type="text" id="sbt-wheel-hex" maxlength="7" spellcheck="false"></div></div>';
  const wheel=wrap.querySelector('#sbt-wheel');let pointer=null;
  const point=e=>{const rect=wheel.getBoundingClientRect(),x=e.clientX-(rect.left+rect.width/2),y=e.clientY-(rect.top+rect.height/2);wheelHSV.h=(Math.atan2(y,x)*180/Math.PI+450)%360;wheel.setAttribute('aria-valuenow',String(Math.round(wheelHSV.h)));applyWheel();};
  wheel.addEventListener('pointerdown',e=>{pointer=e.pointerId;wheel.setPointerCapture(e.pointerId);point(e);});wheel.addEventListener('pointermove',e=>{if(pointer===e.pointerId)point(e);});wheel.addEventListener('pointerup',()=>pointer=null);wheel.addEventListener('pointercancel',()=>pointer=null);
  wheel.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowDown','ArrowRight','ArrowUp'].includes(e.key)){e.preventDefault();wheelHSV.h=(wheelHSV.h+((e.key==='ArrowRight'||e.key==='ArrowUp')?3:357))%360;applyWheel();}});
  wrap.querySelector('#sbt-wheel-sat').oninput=e=>{wheelHSV.s=Number(e.target.value);applyWheel();};wrap.querySelector('#sbt-wheel-val').oninput=e=>{wheelHSV.v=Number(e.target.value);applyWheel();};wrap.querySelector('#sbt-wheel-hex').onchange=e=>{if(safeColor(e.target.value)){draft.colors[wheelKey]=e.target.value.toLowerCase();wheelHSV=toHSV(draft.colors[wheelKey]);applyWheel();}else renderWheel();};
  return wrap;
 }
 function addSlider(parent,label,key,min,max,units){const wrap=node('div');const lab=node('label',null,label);const row=node('div','sbt-range');const input=node('input');input.type='range';input.min=min;input.max=max;input.value=draft[key];const output=node('output',null,String(draft[key])+units);input.oninput=()=>{draft[key]=Number(input.value);output.textContent=input.value+units;updatePreview();};row.append(input,output);wrap.append(lab,row);parent.append(wrap);}
 // The previews are actual browser DOM/CSS, not an independently styled illustration.
 // Start Page uses this page's real CSS and cloned controls inside a no-script frame;
 // Secure Search loads the actual secure-search.html document and theme-search.css.
 function buildShellPreviewDocument(pageKind='start'){
  const css=document.querySelector('head style')?.textContent||'';
  const tabs=$id('tabs').cloneNode(true),bar=$id('bar').cloneNode(true),start=$id('start').cloneNode(true);
  const list=tabs.querySelector('#tablist');if(list){list.replaceChildren();const tab=node('div','tab on');const label=node('span',null,pageKind==='search'?'Secure Search':'New Tab');tab.append(label);const nt=node('button',null,'＋');nt.id='nt';list.append(tab,nt);}
  const locationInput=bar.querySelector('#url');if(locationInput)locationInput.value='';
  for(const id of ['extbuttons'])bar.querySelector('#'+id)?.remove();
  start.querySelector('#bgm')?.remove();start.querySelector('#layer')?.remove();
  start.classList.add('on');start.style.removeProperty('display');
  const clock=start.querySelector('#clock');if(clock)clock.textContent=$id('clock').textContent||'10:24';
  const safeStyle=css.replace(/<\/style/gi,'<\\/style');
  return '<!doctype html><html lang="en"><head><base href="'+location.origin+'/">'+
    '<meta name="viewport" content="width=device-width,initial-scale=1">'+
    '<style>'+safeStyle+'</style><link rel="stylesheet" href="theme-studio.css?v=20261106-true-preview">'+
    '<style>html,body{width:100%;height:100%;overflow:hidden!important}body{pointer-events:none}#start{display:flex!important;animation:none!important}#sc,.tile{animation:none!important}#panel{display:none!important}#sbt-search-content{display:block!important;position:absolute;inset:0;width:100%;height:100%;border:0}*{transition:none!important}</style>'+ 
    '</head><body>'+tabs.outerHTML+bar.outerHTML+'<div id="content">'+(pageKind==='search'?'<iframe id="sbt-search-content" sandbox="allow-same-origin" title="Secure Search real page"></iframe>':start.outerHTML)+'</div></body></html>';
 }
 let searchPreviewMarkup=null;
 async function buildRealSearchMarkup(){
  if(searchPreviewMarkup)return searchPreviewMarkup;
  const res=await fetch('secure-search.html',{cache:'force-cache'});
  if(!res.ok)throw Error('Secure Search preview could not load');
  const parsed=new DOMParser().parseFromString(await res.text(),'text/html');
  const css=parsed.querySelector('head style')?.textContent||'';
  const home=parsed.querySelector('#home'),header=parsed.querySelector('#top');
  if(!home||!header||!css)throw Error('Secure Search markup missing');
  home.style.display='flex';header.style.display='none';
  const topics=home.querySelector('#topics');if(topics){for(const title of ['Why is the sky blue?','What is a black hole?','How do plants grow?','Who invented the telephone?','Roblox Studio'])topics.append(node('button',null,title));}
  searchPreviewMarkup='<!doctype html><html lang="en"><head><base href="'+location.origin+'/">'+
   '<meta name="viewport" content="width=device-width, initial-scale=1">'+
   '<style>'+css.replace(/<\/style/gi,'<\\/style')+'</style><link rel="stylesheet" href="theme-search.css?v=20261106-polished">'+
   '<style>body{pointer-events:none}.top{display:none!important}.home{display:flex!important}*{animation:none!important;transition:none!important}</style></head><body>'+header.outerHTML+home.outerHTML+'</body></html>';
  return searchPreviewMarkup;
 }
 async function loadSearchPreviewShell(frame){
  const inner=frame.contentDocument?.querySelector('#sbt-search-content');if(!inner||inner.dataset.initialized)return;
  inner.dataset.initialized='1';
  inner.addEventListener('load',()=>applyPreviewToFrame(frame,true));
  try{inner.srcdoc=await buildRealSearchMarkup();}catch(e){inner.removeAttribute('srcdoc');inner.title='Search preview unavailable';console.warn(e);}
 }
 function previewImageFor(kind){return objectURLs[kind]||(kind==='search'?objectURLs.start:null);}
 function applyPreviewToFrame(frame,isSearch){
  if(!draft||!frame?.contentDocument)return;
  const doc=frame.contentDocument,root=doc.documentElement;
  root.dataset.appearance='custom';delete root.dataset.sstheme;root.classList.remove('light');
  root.classList.toggle('phone-ui',previewDevice==='phone');
  loadStyle(draft,root);
  root.style.setProperty('--accent',draft.colors.accent);
  const inherited=document.documentElement.style.getPropertyValue('--start-bg').trim()||'url("assets/image-4928151514d8.png")';
  const chosen=previewImageFor(isSearch?'search':'start');
  if(isSearch){
   const inner=doc.querySelector('#sbt-search-content')?.contentDocument;
   if(inner){const searchRoot=inner.documentElement;
    searchRoot.dataset.appearance='custom';delete searchRoot.dataset.sstheme;searchRoot.classList.remove('light');
    loadStyle(draft,searchRoot);searchRoot.style.setProperty('--accent',draft.colors.accent);
    searchRoot.style.setProperty('--ss-wallpaper',chosen?'url("'+chosen+'")':inherited);
    const icon=objectURLs.logo||'assets/secure-search-icon.webp';
    inner.querySelectorAll('.brand-icon,.home-brand-icon').forEach(img=>{if(img.getAttribute('src')!==icon)img.src=icon;});
   }
  }else{
   root.style.setProperty('--start-bg',inherited);
   root.style.setProperty('--bg-pad',document.documentElement.style.getPropertyValue('--bg-pad').trim()||'0px');
   root.style.setProperty('--bg-filter',document.documentElement.style.getPropertyValue('--bg-filter').trim()||'none');
   if(chosen)root.style.setProperty('--sbt-start-image','url("'+chosen+'")');
   else root.style.removeProperty('--sbt-start-image');
   const clock=doc.querySelector('#clock');if(clock)clock.textContent=$id('clock').textContent||'10:24';
  }
 }
 function resizePreviewFrames(){
  const stage=$id('sbt-preview-stage');if(!stage||!modal||modal.hidden)return;
  const phone=previewDevice==='phone',width=phone?390:1180,height=phone?780:760;
  const scale=Math.max(.05,Math.min((stage.clientWidth-6)/width,(stage.clientHeight-6)/height));
  for(const frame of modal.querySelectorAll('.sbt-real-frame')){
   frame.style.width=width+'px';frame.style.height=height+'px';
   frame.style.transform='translate(-50%, -50%) scale('+scale+')';
  }
  modal.querySelectorAll('[data-sbt-device]').forEach(b=>{b.classList.toggle('active',b.dataset.sbtDevice===previewDevice);b.setAttribute('aria-pressed',String(b.dataset.sbtDevice===previewDevice));});
 }
 function updatePreview(){if(!draft||!modal)return;
  const isSearch=previewTab==='search';
  for(const frame of modal.querySelectorAll('.sbt-real-frame'))frame.hidden=frame.id!==(isSearch?'sbt-preview-search-frame':'sbt-preview-start-frame');
  applyPreviewToFrame($id('sbt-preview-start-frame'),false);applyPreviewToFrame($id('sbt-preview-search-frame'),true);
  const kind=previewBackgroundKind(),fileUrl=previewImageFor(kind),badge=$id('sbt-preview-image-status');
  if(badge){badge.textContent=fileUrl?(objectURLs[kind]?'✓ Custom '+(isSearch?'search':'start')+' wallpaper':'✓ Using Start Page wallpaper'):'Browser default wallpaper';badge.classList.toggle('custom',!!fileUrl);}
  const add=$id('sbt-preview-change');if(add){add.textContent=fileUrl?'Change wallpaper':'+ Add wallpaper';add.setAttribute('aria-label',(fileUrl?'Change':'Add')+' '+kind+' wallpaper');}
  for(const b of modal.querySelectorAll('[data-sbt-preview]')){b.classList.toggle('active',b.dataset.sbtPreview===previewTab);b.setAttribute('aria-pressed',String(b.dataset.sbtPreview===previewTab));}
  requestAnimationFrame(resizePreviewFrames);
 }
 function toggleExpandedPreview(){
  if(!modal)return;const expanded=modal.classList.toggle('sbt-expanded');
  const button=$id('sbt-expand-preview');button.textContent=expanded?'← Back to editor':'⛶ Full screen';
  button.setAttribute('aria-expanded',String(expanded));
  if(expanded)setPreviewCollapsed(false);
  requestAnimationFrame(resizePreviewFrames);
 }
 function clearDraft(){editorSession++;revokeAll(objectURLs);objectURLs={};blobs={};draft=null;originalId=null;}
 function mobileStudio(){return document.documentElement.classList.contains('phone-ui')||window.matchMedia('(max-width:700px)').matches;}
 function setPreviewCollapsed(collapsed){if(!modal)return;const area=modal.querySelector('.sbt-preview-area'),toggle=$id('sbt-toggle-preview');area.classList.toggle('preview-collapsed',collapsed);toggle.setAttribute('aria-expanded',String(!collapsed));toggle.textContent=collapsed?'Show preview':'Hide preview';}
 function syncStudioLayout(){if(!modal)return;const mobile=mobileStudio();modal.classList.toggle('sbt-mobile',mobile);if(!mobile)setPreviewCollapsed(false);else if(!previewUserChoice)setPreviewCollapsed(window.innerHeight<530);}
 function closeEditor(){if(!modal)return;modal.classList.remove('sbt-expanded');const expand=$id('sbt-expand-preview');if(expand){expand.textContent='⛶ Full screen';expand.setAttribute('aria-expanded','false');}modal.hidden=true;if(previousBodyOverflow!==null){document.body.style.overflow=previousBodyOverflow;previousBodyOverflow=null;}clearDraft();try{focusBefore?.focus({preventScroll:true});}catch{}}
 async function openEditor(id=null){focusBefore=document.activeElement;clearDraft();const src=id?themeById(id):null;originalId=src?.id||null;draft=src?structuredClone(cleanTheme(src)):structuredClone(DEFAULT);
  for(const kind of KINDS){blobs[kind]=src?await imageBlob(src.id,kind):null;objectURLs[kind]=assetURL(blobs[kind]);}
  if(!modal)buildModal();previewUserChoice=false;previewTab='start';previewDevice=mobileStudio()?'phone':'desktop';syncStudioLayout();if(previousBodyOverflow===null)previousBodyOverflow=document.body.style.overflow;document.body.style.overflow='hidden';modal.hidden=false;renderControls();updatePreview();refreshSaveState();
  if(mobileStudio()){modal.querySelector('.sbt-content').scrollTop=0;}else $id('sbt-name').focus({preventScroll:true});
 }
 async function saveDraft(){if(pendingUploads)return toast('Image is still preparing. Please finish the upload first.');try{const validated=cleanTheme(draft),id=originalId||makeId();await setImages(id,blobs);const idx=S.customThemes.findIndex(t=>t.id===id),theme={...validated,id};if(idx<0)S.customThemes.push(theme);else S.customThemes[idx]=theme;
  S.appearance=id;S.ssTheme='';save();
  if(!JSON.parse(localStorage.getItem('sb-web-v2')||'{}').customThemes?.some(t=>t.id===id))throw Error('Browser storage is full — the theme was not saved');
  rebuildOptions();applyTheme();applySS();updateButtons();closeEditor();toast('Theme saved and applied');return id;
 }catch(err){toast(err.message||'Could not save theme');return null;}}
 function blobToDataURL(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('Could not read theme image'));reader.readAsDataURL(blob);});}
 async function makeSBT(theme,images){const clean=cleanTheme(theme),assets={};for(const k of KINDS)assets[k]=images[k]?await blobToDataURL(images[k]):null;
  const doc={format:'SecureBrowserTheme',version:1,theme:clean,assets};return new Blob(['SBT1\n',JSON.stringify(doc)],{type:'application/x-secure-browser-theme'});
 }
 function themeFilename(name){return (name.replace(/[^a-z\d _-]/gi,'').trim().replace(/\s+/g,'_').slice(0,48)||'Custom_Theme')+'.SBT';}
 function triggerDownload(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=themeFilename(name);document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);}
 async function exportTheme(theme,images){try{const b=await makeSBT(theme,images);triggerDownload(b,theme.name);toast('Theme exported as .SBT — ready to share');}catch(e){toast(e.message||'Could not export theme');}}
 async function exportSelected(){const t=themeById(S.appearance)||themeById(S.ssTheme);if(!t)return toast('Select a custom theme first');const files={};for(const k of KINDS)files[k]=await imageBlob(t.id,k);await exportTheme(t,files);}
 async function shareTheme(theme,images){try{const blob=await makeSBT(theme,images),file=new File([blob],themeFilename(theme.name),{type:'application/x-secure-browser-theme'});
  if(navigator.canShare?.({files:[file]})&&navigator.share){try{await navigator.share({title:theme.name+' — Secure Browser theme',files:[file]});return;}catch(e){if(e.name==='AbortError')return;}}
  triggerDownload(blob,theme.name);toast('Saved .SBT file — send it to a friend to share your theme');
 }catch(e){toast(e.message||'Could not share the theme');}}
 async function shareSelected(){const t=themeById(S.appearance)||themeById(S.ssTheme);if(!t)return toast('Select a custom theme first');const files={};for(const k of KINDS)files[k]=await imageBlob(t.id,k);await shareTheme(t,files);}
 function dataURLtoBlob(s){if(s===null||s===undefined)return null;
  if(typeof s!=='string'||s.length>2_000_000)throw Error('Image data is not valid');const m=s.match(/^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z\d+/]+={0,2})$/);if(!m)throw Error('Theme contains an unsupported image');
  const binary=atob(m[2]);if(binary.length>MAX_ASSET)throw Error('Theme image is too large');const out=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)out[i]=binary.charCodeAt(i);return new Blob([out],{type:m[1]});
 }
 async function importSBT(file){if(!file)return;try{
  if(file.size>MAX_FILE)throw Error('Theme file must be under 8 MB');if(!/\.sbt$/i.test(file.name))throw Error('Choose a .SBT theme file');
  const raw=await file.text();if(!raw.startsWith('SBT1\n'))throw Error('Not a Secure Browser .SBT theme');
  const doc=JSON.parse(raw.slice(5));if(doc?.format!=='SecureBrowserTheme'||doc.version!==1)throw Error('Unsupported .SBT version');
  const settings=cleanTheme(doc.theme);if(!doc.assets||typeof doc.assets!=='object')throw Error('Missing theme assets');
  const images={};for(const k of KINDS)images[k]=dataURLtoBlob(doc.assets[k]);
  const id=makeId();await setImages(id,images);S.customThemes.push({...settings,id});S.appearance=id;S.ssTheme='';save();
  if(!JSON.parse(localStorage.getItem('sb-web-v2')||'{}').customThemes?.some(t=>t.id===id))throw Error('Browser storage is full — the theme was not saved');
  rebuildOptions();applyTheme();applySS();updateButtons();closeEditor();toast('Imported and applied: '+settings.name);
 }catch(e){toast('Import failed: '+(e.message||'Invalid theme file'));}}
 async function removeTheme(){if(!originalId)return;const t=themeById(originalId);if(!t||!confirm('Delete the custom theme "'+t.name+'" from this device?'))return;
  for(const k of KINDS)try{await dbDelK('sbt:'+originalId+':'+k);}catch{}S.customThemes=S.customThemes.filter(x=>x.id!==originalId);
  if(S.appearance===originalId)S.appearance='glass';if(S.ssTheme===originalId)S.ssTheme='';save();rebuildOptions();applyTheme();applySS();updateButtons();closeEditor();toast('Theme deleted');
 }
 function renderControls(){const body=$id('sbt-controls');body.replaceChildren();const section=(number,title,sub)=>{const head=node('div','sbt-section-title');const left=node('div');left.append(node('span','sbt-section-number',number),node('strong',null,title));head.append(left);if(sub)head.append(node('small',null,sub));body.append(head);};section('01','Your theme','Make it yours');const nameLab=node('label',null,'Theme name');const name=node('input');name.id='sbt-name';name.type='text';name.maxLength=60;name.value=draft.name;name.placeholder='Name your theme';name.oninput=()=>{draft.name=name.value;};body.append(nameLab,name);
  const finishLab=node('label',null,'Visual finish');const finish=node('select');for(const [k,v] of [['glass','Liquid Glass'],['solid','Solid'],['aero','Frutiger Aero']]){const o=node('option',null,v);o.value=k;finish.append(o);}finish.value=draft.style;finish.onchange=()=>{draft.style=finish.value;updatePreview();};body.append(finishLab,finish);
  section('02','Wallpapers','Live preview');
  const artwork=node('div','sbt-artwork');artwork.append(node('p','sbt-hint','Choose an image or drag one onto a card. The preview changes automatically. Artwork is included when you export a .SBT theme.'));artwork.append(uploadRow('start','Start page background','Shown behind your Start Page'),uploadRow('search','Secure Search background','Leave empty to use the Start Page image'),uploadRow('logo','Search logo','Optional custom icon'));body.append(artwork);
  const layout=node('div','sbt-wallpaper-layout');for(const [id,label,choices] of [['wallpaperFit','Image sizing',[['cover','Fill screen'],['contain','Fit entire image']]],['wallpaperPosition','Image position',[['center','Center'],['top','Top'],['bottom','Bottom'],['left','Left'],['right','Right']]]]){const wrap=node('div'),l=node('label',null,label),select=node('select');select.id='sbt-'+id;for(const [key,text] of choices){const opt=node('option',null,text);opt.value=key;select.append(opt);}select.value=draft[id]||choices[0][0];select.onchange=()=>{draft[id]=select.value;updatePreview();};wrap.append(l,select);layout.append(wrap);}body.append(layout);
  section('03','Colors & surfaces','Fine tune');
  const colors=node('fieldset'),legend=node('legend',null,'Colors'),grid=node('div','sbt-colors');for(const [k,label] of COLOR_FIELDS){const item=node('div','sbt-color-item'),inp=node('input');item.dataset.sbtColor=k;inp.type='color';inp.value=draft.colors[k];inp.setAttribute('aria-label',label+' color');inp.oninput=()=>{draft.colors[k]=inp.value;wheelKey=k;wheelHSV=toHSV(draft.colors[k]);updatePreview();renderWheel();};const select=node('button','sbt-pick-wheel','◉');select.type='button';select.title='Edit '+label+' on color wheel';select.setAttribute('aria-label',select.title);select.onclick=()=>setWheelKey(k);item.append(inp,node('span',null,label),select);grid.append(item);}colors.append(legend,grid,makeWheel());body.append(colors);setWheelKey('accent');
  addSlider(body,'Surface opacity','opacity',20,100,'%');addSlider(body,'Corner roundness','radius',8,40,'px');addSlider(body,'Background dimming','dim',0,80,'%');
  $id('sbt-delete').hidden=!originalId;
 }
 function buildModal(){modal=node('div');modal.id='sbt-modal';modal.hidden=true;modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-label','Create custom browser theme');
  modal.innerHTML=`<div class="sbt-studio"><div class="sbt-heading"><div class="sbt-heading-icon">✦</div><div class="sbt-heading-info"><span class="sbt-eyebrow">SECURE BROWSER · PERSONALIZATION</span><strong>Theme Studio</strong><small>See how your real browser will look</small></div><span class="sbt-live-badge"><i></i> Real browser preview</span><button id="sbt-close" type="button" aria-label="Close Theme Studio">✕ <span>Close</span></button></div><div class="sbt-content"><div class="sbt-controls" id="sbt-controls"></div><div class="sbt-preview-area"><div class="sbt-preview-top"><strong>Actual page preview</strong><button id="sbt-toggle-preview" type="button" aria-expanded="true" aria-controls="sbt-preview-body">Hide preview</button><div class="sbt-preview-tabs" role="group" aria-label="Preview page"><button type="button" class="active" data-sbt-preview="start">Start page</button><button type="button" data-sbt-preview="search">Secure Search</button></div></div><div class="sbt-preview-tools"><div class="sbt-device-switch" role="group" aria-label="Preview device"><button type="button" data-sbt-device="desktop" aria-pressed="true">▣ Desktop</button><button type="button" data-sbt-device="phone" aria-pressed="false">▯ Phone</button></div><button type="button" id="sbt-expand-preview" aria-expanded="false">⛶ Full screen</button></div><div class="sbt-preview-body" id="sbt-preview-body"><div id="sbt-preview-stage"><iframe id="sbt-preview-start-frame" class="sbt-real-frame" title="Real Start Page preview" sandbox="allow-same-origin"></iframe><iframe id="sbt-preview-search-frame" class="sbt-real-frame" title="Real Secure Search preview" sandbox="allow-same-origin"></iframe><div class="sbt-preview-image-footer"><span id="sbt-preview-image-status">Browser default wallpaper</span><button type="button" id="sbt-preview-change">+ Add wallpaper</button></div></div><div class="sbt-p-note">Not a mockup: this preview renders the actual Start Page and Secure Search styling. Save &amp; Apply uses this appearance on both pages.</div></div></div></div><div class="sbt-actions"><button id="sbt-delete" class="sbt-danger" type="button">Delete theme</button><span class="sbt-spacer"></span><button id="sbt-share-draft" type="button">Share .SBT</button><button id="sbt-export-draft" type="button">Export .SBT</button><button id="sbt-save" class="sbt-primary" type="button">Save &amp; Apply</button></div></div>`;
  document.body.append(modal);$id('sbt-close').onclick=closeEditor;$id('sbt-toggle-preview').onclick=()=>{previewUserChoice=true;setPreviewCollapsed(!modal.querySelector('.sbt-preview-area').classList.contains('preview-collapsed'));};$id('sbt-save').onclick=saveDraft;$id('sbt-export-draft').onclick=()=>exportTheme(draft,blobs);$id('sbt-share-draft').onclick=()=>shareTheme(draft,blobs);$id('sbt-delete').onclick=removeTheme;$id('sbt-expand-preview').onclick=toggleExpandedPreview;$id('sbt-preview-change').onclick=()=>modal.querySelector('.sbt-image-row[data-sbt-kind="'+previewBackgroundKind()+'"] input[type=file]')?.click();
  modal.addEventListener('paste',e=>{const file=Array.from(e.clipboardData?.files||[]).find(f=>f.type.startsWith('image/'));if(!file||e.target?.matches?.('input,textarea'))return;e.preventDefault();const row=modal.querySelector('.sbt-image-row[data-sbt-kind="'+previewBackgroundKind()+'"]');const inp=row?.querySelector('input[type=file]');if(inp){const dt=new DataTransfer();dt.items.add(file);inp.files=dt.files;inp.dispatchEvent(new Event('change',{bubbles:true}));}});
  modal.addEventListener('pointerdown',e=>{if(e.target===modal)closeEditor();});modal.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();if(modal.classList.contains('sbt-expanded'))toggleExpandedPreview();else closeEditor();}});
  for(const button of modal.querySelectorAll('[data-sbt-preview]'))button.onclick=()=>{previewTab=button.dataset.sbtPreview;updatePreview();};
  for(const button of modal.querySelectorAll('[data-sbt-device]'))button.onclick=()=>{previewDevice=button.dataset.sbtDevice;updatePreview();};
  const startFrame=$id('sbt-preview-start-frame'),searchFrame=$id('sbt-preview-search-frame');
  startFrame.addEventListener('load',()=>{applyPreviewToFrame(startFrame,false);resizePreviewFrames();});
  searchFrame.addEventListener('load',()=>{loadSearchPreviewShell(searchFrame);applyPreviewToFrame(searchFrame,true);resizePreviewFrames();});
  startFrame.srcdoc=buildShellPreviewDocument('start');searchFrame.srcdoc=buildShellPreviewDocument('search');
  if(typeof ResizeObserver!=='undefined'){previewResize=new ResizeObserver(resizePreviewFrames);previewResize.observe($id('sbt-preview-stage'));}

 }
 function initialize(){if(!Array.isArray(S.customThemes))S.customThemes=[];
  S.customThemes=S.customThemes.filter(t=>{try{cleanTheme(t);return typeof t.id==='string'&&/^sbt-[\w-]{4,60}$/.test(t.id);}catch{return false;}});
  if(!themeById(S.appearance)&&!['glass','solid','aero','oled','aurora','paper','terminal'].includes(S.appearance)){S.appearance='glass';save();}
  rebuildOptions();const buttons=node('div');buttons.id='sbt-shortcuts';
  const create=node('button',null,'✦ Create theme'),edit=node('button',null,'Edit theme'),imp=node('button',null,'Import .SBT'),exp=node('button',null,'Export .SBT'),share=node('button',null,'Share .SBT');
  edit.id='sbt-edit';exp.id='sbt-export';share.id='sbt-share';create.onclick=()=>openEditor();edit.onclick=()=>openEditor(themeById(S.appearance)?.id||themeById(S.ssTheme)?.id);exp.onclick=exportSelected;share.onclick=shareSelected;
  const inp=node('input');inp.type='file';inp.accept='.sbt,application/x-secure-browser-theme';inp.id='sbt-file-input';imp.onclick=()=>inp.click();inp.onchange=async()=>{const f=inp.files?.[0];inp.value='';await importSBT(f);};
  buttons.append(create,edit,imp,exp,share,inp);const panel=$id('panel');panel.insertBefore(buttons,panel.querySelector('label[for="sstheme"]').nextElementSibling.nextElementSibling);
  window.SBT_openEditor=openEditor;window.SBT_chooseCreate=()=>openEditor();window.SBT_refresh=()=>{rebuildOptions();updateButtons();};
  $id('appearsel').addEventListener('change',()=>{updateButtons();});$id('sstheme').addEventListener('change',updateButtons);
  updateButtons();window.addEventListener('resize',()=>{if(modal&&!modal.hidden)syncStudioLayout();},{passive:true});if(themeById(S.appearance))applyTheme();
 }
 initialize();
})();
