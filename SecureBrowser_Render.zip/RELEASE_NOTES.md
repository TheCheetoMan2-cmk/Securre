# Secure Browser — Error Center & Theme Studio Upgrade

## Added

1. Custom website error center: recognizable error codes and explanations, themed icon illustration, retry/home/open-original/copy actions, and help details.
2. Smarter source-backed Input Summary: quick/detailed display, copy answer with source URLs, show/hide sources, and suggested follow-up searches.
3. Advanced theme studio: dedicated toolbar colors, font styles, toolbar button icon sets, custom tab radius, toolbar opacity, motion settings, and start-page search positioning. Exportable in `.SBT`.

## Compatibility

- No changes to npm dependencies, Render Dockerfile, proxy security controls, theme signature, or saved theme identifiers.
- Legacy `.SBT` themes have defaults for newly introduced settings, and existing image assets remain embedded on export.
- Mobile Theme Studio controls remain scrollable with the save/export/share bar.
- Custom error messages only replace failures that Secure Browser can detect; the browser cannot reliably detect all failures inside restricted cross-origin direct iframes.

## Verification

- Run `node tests/theme-error-upgrade.test.cjs` for backward-compatibility and sanitized error message checks.
- Run `node tests/question-summary.test.cjs`, `node tests/why-answer.test.cjs`, `node tests/media-search.test.cjs`, and `node tests/inappropriate-summary.test.cjs` for existing summary behavior.
- Full proxy integration tests need Node dependencies installed. Browser automation could not navigate to local pages in the build environment because Chromium enforces an administrator URL blocklist; final interactive testing should be performed on Render.

### `ERR.test` error-page showcase
- Search for or navigate to `ERR.test` to launch the error center demonstration without network traffic.
- Refresh cycles 404 → 403 → 401 → 408 → 410 → 429 → 500 → 502 → 503 → 504 → connection error, then repeats.
- Works with the toolbar, keyboard reload, tab-menu reload, error page button, and full application refresh.
- Does not change ordinary browsing or custom `.SBT` themes.

### Satellite Maps tab

- Replaced the embedded street map with an interactive satellite map while keeping the existing Maps search and location list.
- Adds high-resolution satellite tile imagery, optional map labels, scroll/touch zoom, drag-to-pan, recenter, mobile touch controls, markers and provider attribution.
- Uses Esri's public imagery services; subject to availability, coverage, attribution, and licensing/usage terms.


## Satellite map: Closer zoom & cleaner interface

- Increased the maximum map zoom from 19 to 23. The map tries native Esri satellite tiles at each level; high-detail tiles are only available in some regions.
- When a close-up tile is unavailable, the map draws a correctly cropped parent tile into a fixed-size canvas, so you can keep zooming without a blank square. Enlarged imagery may become blurry where the provider lacks higher-resolution images.
- Removed the duplicate “Satellite imagery © …” panel below the map and the top-left Satellite label.
- Credits are now a small integrated overlay inside the map, preserving required Esri/source and OpenStreetMap attribution.
- Hidden exaggerated place labels at zoom levels 20+; the labels toggle becomes available again at lower zoom levels.
- Preserved map search, drag, touch pinch zoom, selected markers, recenter, browser themes, ERR.test, the Input Summarizer, and .SBT import/export.
- Run `node tests/satellite-map.test.cjs` and `node tests/satellite-map-interaction.test.cjs` to verify tile math and fallback behavior.

### Clean Maps attribution display
- Removed the always-visible lower-right credits banner. The map now shows only a small ⓘ information button in that corner. Tap/click to view Esri and OpenStreetMap source attribution.
- The information panel is touch-friendly, keyboard-accessible and does not activate map dragging. No changes to satellite tiles, search, zoom or saved themes.


### Personal map UI cleanup
- Removed the on-map ⓘ button and its source popup, plus the Maps results footer, for an uninterrupted satellite view.
- Kept satellite imagery, maximum zoom level 23, search results, touch controls, markers, label toggling, and recenter features.
- Imagery source references remain in `MAP_SOURCES.md`. This visual customization does not waive third-party provider attribution or licensing terms.

## Satellite maps — missing-data tiles at extreme zoom

- Fixed "Map Data Not Yet Available" showing up **inside the image tiles** at high zoom. ArcGIS was returning the placeholder as a successful HTTP 200 image, preventing fallback.
- Requests now use ArcGIS's `blankTile=false` parameter so missing tiles trigger the existing parent-tile fallback.
- All existing map search, zoom 23, controls, theme, and other browser features remain unchanged.
- Where imagery coverage is limited, zooming magnifies available tiles instead of inventing finer detail.

## Secure Browser Apps + Secure Maps (2026-11-06)

**New:** Start Page Apps launcher with a curated app catalog (`public/secure-apps.js`).

**New:** Secure Maps (`/secure-maps.html`): complete browser-tab application with an Esri satellite map, location search on the left, responsive layout, mobile gestures, Panoramax coverage overlay, street-photo viewer, recent-location saving, and sharing links.

**New:** Bounded `/api/panoramax/nearby` endpoint using the public Panoramax STAC feature search, cached and validated. Blue photo markers show actual geo-tagged photos; connected segments are drawn only between nearby photos from the same sequence.

**Integration:** Secure Search Maps gains an “Open in Secure Maps” shortcut. Existing search and browser maps stay in place. The `.SBT` theme store is unchanged, and Secure Maps uses the active theme palette.

**Testing:** Unit and existing feature tests pass. Live satellite/photo loading must be checked on Render (third-party services unavailable in the build environment). Panoramax photos can be sparse outside covered areas; high zoom cannot create new photographic detail.


## Mapillary Blue Street Coverage + Panoramax
- Added free Mapillary support to Secure Maps using official coverage vector tiles and MapillaryJS. Users can configure a Mapillary **client** access token in the app or via `MAPILLARY_CLIENT_TOKEN` on Render.
- Added one **Street View Coverage** button. When enabled, Mapillary photo sequences and individual images glow blue over existing Esri satellite imagery. Panoramax's photos and segments also show in blue.
- Click blue roads/dots to open interactive imagery next to the map. Search, zoom, pan, satellite detail, the Apps launcher and `.SBT` themes remain intact.
- No API token is hard-coded or fabricated; Panoramax continues to work without Mapillary configuration.
- Added robust vector tile decoding, bounded caching/batched fetching, token settings, and mobile-responsive controls.
- Code-level Mapillary fixture tests and preexisting map, theme, search and error tests pass. External Mapillary tile/viewer loading and live Render deployment have **not** been verified in this environment.

## Latest update
- Secure Maps now uses the user-provided map icon across the app, favicon, and Apps launcher.
- Secure Maps UI simplified with a cleaner Google Maps-inspired layout and glass panels.
- Search/results and action controls restyled for a lighter, less cluttered experience.


### Mapillary blue coverage repair

- Made the supplied client token the default, while retaining custom token and Render env overrides.
- Mapillary blue street coverage starts enabled and is still toggleable.
- Fixed missing blue roads caused by incorrectly requiring a photo ID on sequence geometry.
- Blue street clicks resolve actual nearby photo IDs (with image-tile lookup or Mapillary Graph API), with a zoom-to-photo fallback.
- Improved coverage feedback and support for denser vector tiles.

### Secure Maps minimal glass map UI

- Replaced the giant search sidebar and top information bar with a **single floating search field** over a full-screen map.
- Searching opens a **scrollable location-results dropdown** under that field. Selecting a result centers the map and closes the dropdown; tapping the map, pressing Escape, or tapping × dismisses it.
- Removed the Mapillary settings gear, token editor/dialog, and manual key changes. Existing default client token remains configured; the Render environment variable may still override it at deployment.
- Replaced the old large Street View Coverage control with a compact **black translucent-glass Street View button**, with a blue active indicator. Zoom, recenter, and place-label buttons now match its glass styling.
- Kept Esri satellite imagery, Mapillary and Panoramax coverage, Street View panorama viewer, mobile support, App Launcher, and `.SBT` themes unchanged.

## Satellite map zoom and street coverage performance update
- Reuses loaded Esri satellite and label tiles across zooms/pans with a bounded in-memory source-image cache.
- Shows cached parent crops immediately when zooming in, and cached child mosaics when zooming out, to reduce blank-map flashes.
- Coalesces duplicate tile downloads for multiple high-zoom display cells sharing the same lower-resolution source.
- Temporarily remembers missing high-zoom sources so repeated navigation doesn't retry the same unavailable tile chain immediately.
- Prioritizes visible center tiles and defers new requests 115 ms during continuous zoom gestures, avoiding downloads for skipped intermediate levels.
- Keeps blue Mapillary/Panoramax coverage aligned using a lightweight transform during map movement, rebuilding the overlay after motion settles.
- Cancels outdated Mapillary vector-tile requests after significant moves, and schedules new coverage retrieval sooner after zoom/pan stops.
- Preserves the full-screen minimal black-glass controls, search dropdown, default Mapillary client token, Panoramax, Esri, other browser systems, and `.SBT` themes.

Code-level tests verify immediate cached preview, no new download when returning to a visited zoom, and shared fallback requests. Live satellite and Mapillary loading on Render still requires deployment testing; source latency and imagery resolution depend on the provider.


### November 2026: Mapillary blue-road reliability fix
- Street View Coverage now starts enabled on each Secure Maps load (old saved off state no longer silently disables it).
- Coverage tiles are loaded through a bounded, same-origin `/api/mapillary/tile/:z/:x/:y` endpoint, with a direct Mapillary fallback. This reduces cross-origin and browser-blocking failures.
- Parent and satellite-map iframe resynchronize the Mapillary token and coverage state on load to avoid missing the startup message.
- Genuine Mapillary road sequences show as blue lines, image points at close zoom, and overview dots at wide zoom.
- If the Mapillary client token is rejected or the imagery service is unreachable, Secure Maps displays an error instead of silently pretending there is no coverage. Temporary network errors retry automatically.
- The existing black glass map controls, Esri satellite caching, Panoramax, `.SBT` themes, and other browser systems are unchanged.
- Live Mapillary response availability must be tested on your deployed Render instance; a token with invalid permissions cannot be fixed by rendering code alone.

## Secure Maps — street coverage + map dragging reliability (November 2026)
- Fixed an iframe READY / HELLO feedback loop that repeatedly recentered the map while panning.
- Fixed missing `mapillaryError` and `lastCoverageAlert` declarations in the Mapillary status handler.
- Blue Mapillary street coverage now requests smaller sequence-only-friendly z13 tiles first; large z14 image-point tiles are optional and do not prevent roads appearing.
- Panning across coverage tiles no longer cancels all in-flight requests; zoomed map views continue to reuse successful vector tiles.
- Dragging from a blue feature pans normally; only a short tap opens street imagery.
- Blue street taps use a same-origin Render endpoint to resolve a nearby Mapillary photo, avoiding Graph API browser CORS issues.
- Refreshed asset versions to avoid stale JavaScript after deployment.
- Added regression tests for message recursion, drag handling contracts, map center stability, Mapillary failure status, and Whistler projection.

Note: Live Mapillary availability/token acceptance could not be checked from this build environment.

## Blue street coverage: independent photo-search fallback

- Added a bounded server-side `/api/mapillary/photos?bbox=...` endpoint backed by Mapillary’s own Graph API. It reports only real geotagged Mapillary photos; it never invents blue roads from ordinary road data.
- Secure Maps now displays blue photo dots and line segments between nearby, consecutive photos in the same Mapillary sequence if the public vector tile layer is empty or fails.
- Coverage errors and empty results are now visible in a small black glass status message, rather than leaving the Esri map blank without an explanation.
- Status counts reflect actually rendered lines and markers, not vector features outside the screen.
- Preserved the full-screen satellite view, map interactions, earlier drag/recenter fixes, Panoramax and the built-in Mapillary client token.
- Added independent mocked Graph API fallback tests. External Mapillary authorization and actual site data could not be verified offline.
