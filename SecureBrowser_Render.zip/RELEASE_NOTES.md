# Secure Browser — Error Center & Theme Studio Upgrade

## Added

1. Custom website error center: recognizable error codes and explanations, themed icon illustration, retry/home/open-original/copy actions, and help details.
2. Smarter source-backed Input Summary: quick/detailed display, copy answer with source URLs, show/hide sources, and suggested follow-up searches.
3. Advanced theme studio: dedicated toolbar colors, font styles, toolbar button icon sets, custom tab radius, toolbar opacity, motion settings, and start-page search positioning. Exportable in `.SBT`.

## Compatibility

- No changes to npm dependencies, Render Dockerfile, proxy security controls, theme signature, or saved theme identifiers.
- Legacy `.SBT` themes have defaults for newly introduced settings, and existing image assets remain embedded on export.
- Mobile Theme Studio controls remain scrollable with the save/export/share bar.
- Custom error messages only replace failures that Secure Browser can detect; the browser cannot reliably detect all failures inside restricted cross-origin direct iframes.

## Verification

- Run `node tests/theme-error-upgrade.test.cjs` for backward-compatibility and sanitized error message checks.
- Run `node tests/question-summary.test.cjs`, `node tests/why-answer.test.cjs`, `node tests/media-search.test.cjs`, and `node tests/inappropriate-summary.test.cjs` for existing summary behavior.
- Full proxy integration tests need Node dependencies installed. Browser automation could not navigate to local pages in the build environment because Chromium enforces an administrator URL blocklist; final interactive testing should be performed on Render.
