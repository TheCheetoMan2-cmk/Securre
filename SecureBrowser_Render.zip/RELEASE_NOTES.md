# Secure Browser — Satellite-Only Maps Edition

## Secure Maps

- Removed the Street View button, blue streets/photo overlays, Mapillary and Panoramax integrations, panoramic viewers, client-token setup and their Render API endpoints.
- Kept the full-screen Esri satellite map, compact glass search field, scrollable location results, black-glass zoom/recenter/labels controls, drag and touch gestures and fast tile caching up to zoom 23.
- Preserved the Secure Maps app icon, the Start Page Apps launcher and links from the Secure Search Maps tab.
- Preserved the browser's `.SBT` themes, error pages, Input Summarizer and other browsing features.

## Checks

New `tests/secure-maps-satellite-only.test.cjs` verifies absence of Street View UI/endpoints, continued Esri rendering and live search-to-map interaction using mocked search data. Existing satellite, performance, search and theme tests also pass. The proxy integration test needs `axios` installed with `npm ci`, which is not present in this build environment. A deployed Render instance has not been tested.
