# Secure Browser — Error Center & Theme Studio Upgrade

## Added

1. Custom website error center: recognizable error codes and explanations, themed icon illustration, retry/home/open-original/copy actions, and help details.
2. Smarter source-backed Input Summary: quick/detailed display, copy answer with source URLs, show/hide sources, and suggested follow-up searches.
3. Advanced theme studio: dedicated toolbar colors, font styles, toolbar button icon sets, custom tab radius, toolbar opacity, motion settings, and start-page search positioning. Exportable in `.SBT`.

## Compatibility

- No changes to npm dependencies, Render Dockerfile, proxy security controls, theme signature, or saved theme identifiers.
- Legacy `.SBT` themes have defaults for newly introduced settings, and existing image assets remain embedded on export.
- Mobile Theme Studio controls remain scrollable with the save/export/share bar.
- Custom error messages only replace failures that Secure Browser can detect; the browser cannot reliably detect all failures inside restricted cross-origin direct iframes.

## Verification

- Run `node tests/theme-error-upgrade.test.cjs` for backward-compatibility and sanitized error message checks.
- Run `node tests/question-summary.test.cjs`, `node tests/why-answer.test.cjs`, `node tests/media-search.test.cjs`, and `node tests/inappropriate-summary.test.cjs` for existing summary behavior.
- Full proxy integration tests need Node dependencies installed. Browser automation could not navigate to local pages in the build environment because Chromium enforces an administrator URL blocklist; final interactive testing should be performed on Render.

### `ERR.test` error-page showcase
- Search for or navigate to `ERR.test` to launch the error center demonstration without network traffic.
- Refresh cycles 404 → 403 → 401 → 408 → 410 → 429 → 500 → 502 → 503 → 504 → connection error, then repeats.
- Works with the toolbar, keyboard reload, tab-menu reload, error page button, and full application refresh.
- Does not change ordinary browsing or custom `.SBT` themes.

### Satellite Maps tab

- Replaced the embedded street map with an interactive satellite map while keeping the existing Maps search and location list.
- Adds high-resolution satellite tile imagery, optional map labels, scroll/touch zoom, drag-to-pan, recenter, mobile touch controls, markers and provider attribution.
- Uses Esri's public imagery services; subject to availability, coverage, attribution, and licensing/usage terms.


## Satellite map: Closer zoom & cleaner interface

- Increased the maximum map zoom from 19 to 23. The map tries native Esri satellite tiles at each level; high-detail tiles are only available in some regions.
- When a close-up tile is unavailable, the map draws a correctly cropped parent tile into a fixed-size canvas, so you can keep zooming without a blank square. Enlarged imagery may become blurry where the provider lacks higher-resolution images.
- Removed the duplicate “Satellite imagery © …” panel below the map and the top-left Satellite label.
- Credits are now a small integrated overlay inside the map, preserving required Esri/source and OpenStreetMap attribution.
- Hidden exaggerated place labels at zoom levels 20+; the labels toggle becomes available again at lower zoom levels.
- Preserved map search, drag, touch pinch zoom, selected markers, recenter, browser themes, ERR.test, the Input Summarizer, and .SBT import/export.
- Run `node tests/satellite-map.test.cjs` and `node tests/satellite-map-interaction.test.cjs` to verify tile math and fallback behavior.

### Clean Maps attribution display
- Removed the always-visible lower-right credits banner. The map now shows only a small ⓘ information button in that corner. Tap/click to view Esri and OpenStreetMap source attribution.
- The information panel is touch-friendly, keyboard-accessible and does not activate map dragging. No changes to satellite tiles, search, zoom or saved themes.


### Personal map UI cleanup
- Removed the on-map ⓘ button and its source popup, plus the Maps results footer, for an uninterrupted satellite view.
- Kept satellite imagery, maximum zoom level 23, search results, touch controls, markers, label toggling, and recenter features.
- Imagery source references remain in `MAP_SOURCES.md`. This visual customization does not waive third-party provider attribution or licensing terms.

## Satellite maps — missing-data tiles at extreme zoom

- Fixed "Map Data Not Yet Available" showing up **inside the image tiles** at high zoom. ArcGIS was returning the placeholder as a successful HTTP 200 image, preventing fallback.
- Requests now use ArcGIS's `blankTile=false` parameter so missing tiles trigger the existing parent-tile fallback.
- All existing map search, zoom 23, controls, theme, and other browser features remain unchanged.
- Where imagery coverage is limited, zooming magnifies available tiles instead of inventing finer detail.

## Secure Browser Apps + Secure Maps (2026-11-06)

**New:** Start Page Apps launcher with a curated app catalog (`public/secure-apps.js`).

**New:** Secure Maps (`/secure-maps.html`): complete browser-tab application with an Esri satellite map, location search on the left, responsive layout, mobile gestures, Panoramax coverage overlay, street-photo viewer, recent-location saving, and sharing links.

**New:** Bounded `/api/panoramax/nearby` endpoint using the public Panoramax STAC feature search, cached and validated. Blue photo markers show actual geo-tagged photos; connected segments are drawn only between nearby photos from the same sequence.

**Integration:** Secure Search Maps gains an “Open in Secure Maps” shortcut. Existing search and browser maps stay in place. The `.SBT` theme store is unchanged, and Secure Maps uses the active theme palette.

**Testing:** Unit and existing feature tests pass. Live satellite/photo loading must be checked on Render (third-party services unavailable in the build environment). Panoramax photos can be sparse outside covered areas; high zoom cannot create new photographic detail.
