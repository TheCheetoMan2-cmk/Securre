'use strict';
// Panoramax is a STAC/OGC feature service. Keep its public network requests
// on the server so Secure Maps works even when the browser disallows CORS.
const API = 'https://api.panoramax.xyz/api/search';
const MAX_RESULT = 180;
const cache = new Map();
const MAX_CACHE = 90;
function validBBox(raw) {
  const values = String(raw || '').split(',').map(Number);
  if (values.length !== 4 || values.some(n => !Number.isFinite(n))) return null;
  const [west, south, east, north] = values;
  if (west < -180 || east > 180 || south < -85 || north > 85 || west >= east || south >= north) return null;
  // Prevent broad anonymous API scraping from our public Render service.
  if (east - west > 0.25 || north - south > 0.25) return null;
  return values.map(n => +n.toFixed(6)).join(',');
}
function normalize(data) {
  return (Array.isArray(data?.features) ? data.features : [])
    .filter(f => f?.geometry?.type === 'Point' && Array.isArray(f.geometry.coordinates))
    .map(f => {
      const [lng, lat] = f.geometry.coordinates.map(Number);
      const id = String(f.id || '').trim();
      const sequence = String(f.collection || f.properties?.collection || f.properties?.sequence || '').trim();
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 85 || Math.abs(lng) > 180 ||
          !/^[\w:-]{6,128}$/.test(id) || !/^[\w:-]{6,128}$/.test(sequence)) return null;
      return { id, sequence, lat, lng, date: String(f.properties?.datetime || f.properties?.captured_at || '').slice(0, 30) };
    }).filter(Boolean).slice(0, MAX_RESULT);
}
async function nearby(bbox, opts = {}) {
  const valid = validBBox(bbox);
  if (!valid) { const e = new Error('Invalid map area'); e.status = 400; throw e; }
  const now = Date.now();
  const old = cache.get(valid);
  if (old && now < old.expire) return old.value;
  if (old?.pending) return old.pending;
  const pending = (async () => {
    const url = new URL(API);
    url.searchParams.set('bbox', valid);
    url.searchParams.set('limit', String(MAX_RESULT));
    const response = await (opts.fetch || fetch)(url, {
      headers: { Accept: 'application/geo+json, application/json', 'User-Agent': 'SecureBrowser-SecureMaps/1.0' },
      signal: AbortSignal.timeout(9000)
    });
    if (!response.ok) throw new Error('Panoramax coverage temporarily unavailable');
    const raw = await response.json();
    const value = { features: normalize(raw), totalReturned: (raw.features || []).length };
    cache.set(valid, { value, expire: Date.now() + 120000 });
    if (cache.size > MAX_CACHE) cache.delete(cache.keys().next().value);
    return value;
  })();
  cache.set(valid, { pending });
  try { return await pending; }
  catch (e) { cache.delete(valid); throw e; }
}
module.exports = { validBBox, normalize, nearby };
