'use strict';
// Panoramax's federated STAC search API. Results are cached server-side so
// panning the Esri map does not generate duplicate catalogue requests.
const API = 'https://api.panoramax.xyz/api/search';
const SEARCH_LIMIT = 1000;
const MAX_RESULT = 2800;
const cache = new Map();
const MAX_CACHE = 90;
function validBBox(raw) {
  const values = String(raw || '').split(',').map(Number);
  if (values.length !== 4 || values.some(n => !Number.isFinite(n))) return null;
  const [west, south, east, north] = values;
  if (west < -180 || east > 180 || south < -85 || north > 85 || west >= east || south >= north) return null;
  if (east - west > 0.25 || north - south > 0.25) return null;
  return values.map(n => +n.toFixed(6)).join(',');
}
function normalize(data) {
  return (Array.isArray(data?.features) ? data.features : [])
    .filter(f => f?.geometry?.type === 'Point' && Array.isArray(f.geometry.coordinates))
    .map(f => {
      const [lng, lat] = f.geometry.coordinates.map(Number);
      const id = String(f.id || '').trim();
      const sequence = String(f.collection || f.properties?.collection || f.properties?.sequence || '').trim();
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 85 || Math.abs(lng) > 180 ||
          !/^[\w:-]{6,128}$/.test(id) || !/^[\w:-]{6,128}$/.test(sequence)) return null;
      const rawIndex = f.properties?.sequence_index ?? f.properties?.['geovisio:sequence_index'];
      const index = rawIndex == null ? null : Number(rawIndex);
      const output = { id, sequence, lat, lng, date: String(f.properties?.datetime || f.properties?.captured_at || '').slice(0, 30) };
      if (index != null && Number.isFinite(index)) output.index = index;
      return output;
    }).filter(Boolean);
}
function splitBBox(bbox) {
  const [west, south, east, north] = bbox.split(',').map(Number);
  const midLng = +(west + (east - west)/2).toFixed(6);
  const midLat = +(south + (north - south)/2).toFixed(6);
  return [[west,south,midLng,midLat],[midLng,south,east,midLat],[west,midLat,midLng,north],[midLng,midLat,east,north]]
    .map(nums=>nums.join(','));
}
async function nearby(bbox, opts = {}) {
  const valid = validBBox(bbox);
  if (!valid) { const e = new Error('Invalid map area'); e.status = 400; throw e; }
  const now = Date.now();
  const old = cache.get(valid);
  if (old && now < old.expire) return old.value;
  if (old?.pending) return old.pending;
  const pending = (async () => {
    const fetcher = opts.fetch || fetch;
    async function query(box) {
      const url = new URL(API);
      url.searchParams.set('bbox', box);
      url.searchParams.set('limit', String(SEARCH_LIMIT));
      const response = await fetcher(url, {
        headers: { Accept: 'application/geo+json, application/json', 'User-Agent': 'SecureBrowser-SecureMaps/1.1' },
        signal: AbortSignal.timeout(12000)
      });
      if (!response.ok) throw new Error('Panoramax coverage temporarily unavailable');
      const raw = await response.json();
      return {items:normalize(raw), count:Array.isArray(raw.features)?raw.features.length:0};
    }
    const first = await query(valid);
    let images = first.items;
    let saturated = first.count >= SEARCH_LIMIT;
    // Busy streets can contain thousands of images. Instead of showing only
    // the first 180 from one catalogue page, divide saturated areas into 4
    // smaller queries. An instance's catalogue may return a capped list.
    if (saturated) {
      const groups = await Promise.allSettled(splitBBox(valid).map(box=>query(box)));
      const successful = groups.filter(g=>g.status==='fulfilled').map(g=>g.value);
      if (successful.length) images = successful.flatMap(g=>g.items);
      saturated = successful.some(g=>g.count>=SEARCH_LIMIT);
    }
    const ids=new Set();
    const features=[];
    for(const photo of images) {
      if(ids.has(photo.id))continue;
      ids.add(photo.id);features.push(photo);
      if(features.length>=MAX_RESULT)break;
    }
    const value={features,totalReturned:features.length,partial:saturated||features.length>=MAX_RESULT};
    cache.set(valid,{value,expire:Date.now()+120000});
    if(cache.size>MAX_CACHE)cache.delete(cache.keys().next().value);
    return value;
  })();
  cache.set(valid, { pending });
  try { return await pending; }
  catch (e) { cache.delete(valid); throw e; }
}
function distanceMeters(a,b){
  const r=Math.PI/180,dlat=(a.lat-b.lat)*r,dlng=(a.lng-b.lng)*r;
  const h=Math.sin(dlat/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(dlng/2)**2;
  return 12742000*Math.asin(Math.min(1,Math.sqrt(h)));
}
async function closest(lat,lng,opts={}) {
  lat=Number(lat);lng=Number(lng);
  if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>84||Math.abs(lng)>179.8){const e=new Error('Invalid location');e.status=400;throw e;}
  let photo=null,distance=Infinity;
  // Search successively wider areas, without sending huge unbounded requests.
  // Photo may be far from the clicked location; the UI makes that explicit.
  for(const km of [1,4,9]){
    const dLat=km/111.2,dLng=Math.min(.12,km/(111.2*Math.cos(lat*Math.PI/180)));
    const bbox=[lng-dLng,lat-dLat,lng+dLng,lat+dLat].map(n=>+n.toFixed(6)).join(',');
    const matches=await nearby(bbox,opts);
    for(const item of matches.features){
      const dist=distanceMeters({lat,lng},item);
      if(dist<distance){photo=item;distance=dist;}
    }
    if(photo && distance <= km*1000)break;
  }
  return {photo,distanceMeters:photo?Math.round(distance):null};
}
module.exports = {validBBox,normalize,splitBBox,nearby,closest,distanceMeters};
