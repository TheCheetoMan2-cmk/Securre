'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'..');
const get=x=>fs.readFileSync(path.join(root,x),'utf8');
const {decode}=require('../public/mapillary-vector');
function vi(n){let x=BigInt(n),out=[];do{let b=Number(x&127n);x>>=7n;if(x)b|=128;out.push(b)}while(x);return out}
function field(tag,wire,contents){return [...vi((tag<<3)|wire),...(wire===2?[...vi(contents.length),...contents]:wire===0?vi(contents):contents)]}
function str(tag,s){return field(tag,2,Array.from(Buffer.from(s)))}
function packed(tag,nums){return field(tag,2,nums.flatMap(vi))}
function makeTile(){
 // Mapillary image point and sequence path with ids larger than JS integer precision.
 const imageId='12345678901234567';
 const props=[str(3,'image_id'),str(3,'id')];
 const valueSeq=field(4,2,str(1,imageId));
 const seq=field(2,2,[...field(1,0,41),...packed(2,[0,0]),...field(3,0,2),...packed(4,[9,200,200,18,80,40])]);
 const img=field(2,2,[...field(1,0,42),...packed(2,[0,0]),...field(3,0,1),...packed(4,[9,200,200])]);
 const makeLayer=(name,feature,keys)=>field(3,2,[...str(1,name),...feature,...keys.flat(),...field(4,2,str(1,imageId)),...field(5,0,4096),...field(15,0,2)]);
 return Uint8Array.from([...makeLayer('sequence',seq,[str(3,'image_id')]),...makeLayer('image',img,[str(3,'id')])]);
}
test('Mapillary vector decoder extracts sequence roads, image dots and exact large identifiers',()=>{
 const data=decode(makeTile());
 assert.equal(data.sequence[0].type,2);
 assert.equal(data.sequence[0].props.image_id,'12345678901234567');
 assert.deepEqual(data.sequence[0].paths[0].map(x=>x.map(n=>Math.round(n*4096))),[[100,100],[140,120]]);
 assert.equal(data.image[0].type,1);
 assert.deepEqual(data.image[0].paths[0].map(x=>Math.round(x*4096)),[100,100]);
 assert.equal(data.image[0].props.id,'12345678901234567');
});
test('Mapillary parser rejects malformed or oversized binary input',()=>{
 assert.throws(()=>decode(Uint8Array.of(26,10,1)),/Invalid vector tile length|Truncated/);
 assert.throws(()=>decode(new Uint8Array(3*1024*1024+1)),/Oversized vector tile/);
});
test('Secure Maps has single blue-coverage toggle, two providers and independent Esri base layer',()=>{
 const page=get('public/secure-maps.html'),map=get('public/satellite-map.js'),app=get('public/secure-maps.js');
 assert.match(page,/Street View Coverage/);
 assert.match(page,/Mapillary \+ Panoramax/);
 assert.match(app,/secure-maps:mapillary-open|secure-mapillary\.html/);
 assert.match(map,/secure-maps:mapillary-select/);
 assert.match(map,/tiles\.mapillary\.com\/maps\/vtp\/mly1_public\/2/);
 assert.match(map,/secure-maps:coverage-toggle/);
 assert.match(app,/setCoverage\(!coverageEnabled\)/);
 assert.match(app,/showMapillary\(data\)/);
 assert.match(get('public/satellite-map.html'),/mapillary-vector\.js/);
 assert.match(get('server.js'),/MAPILLARY_CLIENT_TOKEN/);
 assert.match(get('public/secure-mapillary.html'),/new mapillary\.Viewer/);
 assert.match(map,/server\.arcgisonline\.com\/ArcGIS\/rest\/services\/World_Imagery/);
 assert.match(get('public/secure-maps.css'),/max-width:690px/);
});
