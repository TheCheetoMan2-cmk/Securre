'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const P = require('../public/satellite-math.js');

assert.equal(P.TILE_SIZE, 256);
assert.equal(P.wrapTileX(-1, 3), 7);
assert.equal(P.wrapTileX(8, 3), 0);
assert.equal(P.wrapLongitude(181), -179);
assert(!P.validLocation(95, 0));
assert(!P.validLocation(0, -185));
assert.equal(P.MAX_ZOOM, 23, 'Map should zoom four levels further than the previous 19');
assert.equal(P.LABEL_MAX_ZOOM, 19);
assert.deepEqual(P.sourceTile(1000, 1500, 23, 21), {
  zoom: 21, x: 250, y: 375, size: 1024, offsetX: 0, offsetY: 0
});
assert.deepEqual(P.sourceTile(1003, 1503, 23, 21), {
  zoom: 21, x: 250, y: 375, size: 1024, offsetX: -768, offsetY: -768
});
assert.deepEqual(P.sourceTile(-1, 1, 23, 22), {
  zoom: 22, x: 4194303, y: 0, size: 512, offsetX: -256, offsetY: -256
});
assert.throws(() => P.sourceTile(0, 0, 19, 20), RangeError);
assert(P.validLocation(0, 0));

for (const [lat, lng] of [[0, 0], [37.7749, -122.4194], [50.1163, -122.9574], [-34.61, -58.38], [80, 179.8], [-80, -179.8]]) {
  for (const zoom of [2, 8, 14, 19, 21, 23]) {
    const pt = P.toPixel(lat, lng, zoom);
    const result = P.fromPixel(pt.x, pt.y, zoom);
    assert(Math.abs(result.lat - lat) < 0.000001, 'Latitude should survive Mercator map projection');
    assert(Math.abs(result.lng - lng) < 0.000001, 'Longitude should survive Mercator map projection');
  }
}
const mapPage = fs.readFileSync(path.join(root, 'public/satellite-map.html'), 'utf8');
const mapScript = fs.readFileSync(path.join(root, 'public/satellite-map.js'), 'utf8');
const searchPage = fs.readFileSync(path.join(root, 'public/secure-search.html'), 'utf8');
new vm.Script(mapScript, { filename: 'satellite-map.js' });

for (const feature of [
  'World_Imagery/MapServer/tile/', 'World_Boundaries_and_Places/MapServer/tile/',
  'pointerdown', 'pointermove', "'wheel'", "'dblclick'", 'zoomTo(',
  'secure-browser:satellite-center', "event.origin !== location.origin",
  "new ResizeObserver", 'Esri'
]) assert(mapScript.includes(feature) || mapPage.includes(feature), feature);
for (const feature of [
  'satellite-map.html', 'secure-browser:satellite-center', "frame.addEventListener('load'",
  'View on OpenStreetMap', "className='map-list'"
]) assert(searchPage.includes(feature), feature);
assert(!searchPage.includes('www.openstreetmap.org/export/embed.html?bbox='), 'Do not accidentally show the old street-map embed');
assert(!searchPage.includes("credit.append('Satellite imagery"), 'No redundant Satellite imagery footer beneath the map');
assert(!searchPage.includes('map.append(frame,credit)'), 'No redundant bottom panel under satellite view');
assert(!mapPage.includes('Powered by Esri') && !mapPage.includes('OpenStreetMap contributors'), 'Map has no visible attribution text');
assert(!mapPage.includes('map-credit-menu'), 'No on-map credit icon or popup');
assert(!mapPage.includes('Map information and imagery sources'), 'No credit info button');
assert(!mapPage.includes('class="map-attribution"'), 'No visible attribution banner or bottom text');
assert(mapScript.includes("closest('button,a')"), 'Map control taps must not start dragging');
assert(mapPage.includes('map-tile'), 'Parent-tile fallback has correctly cropped 256px viewports');
assert(mapScript.includes('requestTile(sourceZoom - 1)'), 'Missing high resolution imagery falls back to a coarser tile');
for (const feature of ['zoom-in', 'zoom-out', 'recenter', 'labels-toggle', 'marker-label']) assert(mapPage.includes(feature), feature);
console.log('PASS: Satellite map tile math, tile source, mobile controls, selected-place recenter, geographic validation, and retained OpenStreetMap discovery.');
