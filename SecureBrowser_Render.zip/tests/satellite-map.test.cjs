'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const P = require('../public/satellite-math.js');

assert.equal(P.TILE_SIZE, 256);
assert.equal(P.wrapTileX(-1, 3), 7);
assert.equal(P.wrapTileX(8, 3), 0);
assert.equal(P.wrapLongitude(181), -179);
assert(!P.validLocation(95, 0));
assert(!P.validLocation(0, -185));
assert(P.validLocation(0, 0));

for (const [lat, lng] of [[0, 0], [37.7749, -122.4194], [50.1163, -122.9574], [-34.61, -58.38], [80, 179.8], [-80, -179.8]]) {
  for (const zoom of [2, 8, 14, 19]) {
    const pt = P.toPixel(lat, lng, zoom);
    const result = P.fromPixel(pt.x, pt.y, zoom);
    assert(Math.abs(result.lat - lat) < 0.000001, 'Latitude should survive Mercator map projection');
    assert(Math.abs(result.lng - lng) < 0.000001, 'Longitude should survive Mercator map projection');
  }
}
const mapPage = fs.readFileSync(path.join(root, 'public/satellite-map.html'), 'utf8');
const mapScript = fs.readFileSync(path.join(root, 'public/satellite-map.js'), 'utf8');
const searchPage = fs.readFileSync(path.join(root, 'public/secure-search.html'), 'utf8');
new vm.Script(mapScript, { filename: 'satellite-map.js' });

for (const feature of [
  'World_Imagery/MapServer/tile/', 'World_Boundaries_and_Places/MapServer/tile/',
  'pointerdown', 'pointermove', "'wheel'", "'dblclick'", 'zoomTo(',
  'secure-browser:satellite-center', "event.origin !== location.origin",
  "new ResizeObserver", 'Esri'
]) assert(mapScript.includes(feature) || mapPage.includes(feature), feature);
for (const feature of [
  'satellite-map.html', 'secure-browser:satellite-center', "frame.addEventListener('load'",
  'OpenStreetMap contributors', 'View on OpenStreetMap', "className='map-list'"
]) assert(searchPage.includes(feature), feature);
assert(!searchPage.includes('www.openstreetmap.org/export/embed.html?bbox='), 'Do not accidentally show the old street-map embed');
for (const feature of ['zoom-in', 'zoom-out', 'recenter', 'labels-toggle', 'map-attribution', 'marker-label']) assert(mapPage.includes(feature), feature);
console.log('PASS: Satellite map tile math, tile source, mobile controls, selected-place recenter, geographic validation, and retained OpenStreetMap discovery.');
