'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {parseBbox,parsePhotos,createFetcher}=require('../mapillary-graph-coverage');
const read=file=>fs.readFileSync(path.join(__dirname,'..',file),'utf8');
test('Mapillary Graph backup rejects unsafe or unbounded geographic searches',()=>{
 assert.deepEqual(parseBbox('-122.98,50.10,-122.94,50.13'),[-122.98,50.1,-122.94,50.13]);
 for(const bad of ['-180,-85,180,85','-122.95,50.1,-122.96,50.2','http://localhost','-122.94,50.1,999,50.2','-122.9,50.1,-122.7,50.2']) assert.equal(parseBbox(bad),null);
});
test('Graph API image results preserve precise image ids, geometry and sequence identities',()=>{
 const sample={data:[
  {id:'1930283491302381243',geometry:{type:'Point',coordinates:[-122.9574,50.1163]},sequence:'trip-1',captured_at:1697740000000},
  {id:'1930283491302381244',geometry:{type:'Point',coordinates:[-122.9573,50.1164]},sequence:{id:'trip-1'},captured_at:1697740000100},
  {id:'1930283491302381243',geometry:{coordinates:[-122.9574,50.1163]}},
  {id:'1',geometry:{coordinates:[1,2]}}
 ]};
 assert.deepEqual(parsePhotos(sample),[
  {id:'1930283491302381243',lat:50.1163,lng:-122.9574,sequence:'trip-1',capturedAt:1697740000000},
  {id:'1930283491302381244',lat:50.1164,lng:-122.9573,sequence:'trip-1',capturedAt:1697740000100}
 ]);
});
test('Graph backup uses official endpoint and returns actual photos, no invented roads',async()=>{
 let requested;
 const mock=async url=>{requested=new URL(url);return {ok:true,json:async()=>({data:[{id:'2384235235235',geometry:{coordinates:[-122.95,50.11]}}]})}};
 const fetchPhotos=createFetcher(mock);
 const result=await fetchPhotos('-122.96,50.10,-122.94,50.12','MLY|123456789012345|abcdefghijk');
 assert.equal(requested.origin,'https://graph.mapillary.com');
 assert.equal(requested.pathname,'/images');
 assert.match(requested.searchParams.get('fields'),/sequence/);
 assert.equal(result.photos[0].id,'2384235235235');
 assert.equal(result.photos.length,1);
});
test('Both coverage paths are integrated and user can see real failure state',()=>{
 const server=read('server.js'),map=read('public/satellite-map.js'),app=read('public/secure-maps.js');
 assert.match(server,/app\.get\('\/api\/mapillary\/photos'/);
 assert.match(map,/loadGraphCoverage\(bbox\)/);
 assert.match(map,/drawGraphCoverage\(width,height/);
 assert.match(map,/secure-maps:visible-coverage/);
 assert.match(app,/visibleCoverageCount/);
 assert.match(app,/Mapillary unavailable/);
});
