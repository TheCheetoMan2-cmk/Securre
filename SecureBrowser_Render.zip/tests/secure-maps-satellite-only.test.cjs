'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname,'..');
const read = rel => fs.readFileSync(path.join(root,rel),'utf8');

test('Secure Maps UI contains satellite, floating search and glass controls but no Street View',()=>{
 const html=read('public/secure-maps.html');
 const style=read('public/secure-maps.css');
 const satellite=read('public/satellite-map.html');
 const renderer=read('public/satellite-map.js');
 const js=read('public/secure-maps.js');
 for(const id of ['satelliteFrame','placeForm','placeInput','searchDropdown','placeResults','closeSearch'])assert.match(html,new RegExp(`id="${id}"`));
 assert.match(html,/id="searchDropdown"[^>]*hidden/);
 assert.match(html,/satellite-map\.html\?lat=/);
 assert.match(style,/\.sm-search-area\{position:absolute/);
 assert.match(style,/backdrop-filter/);
 assert.match(satellite,/background:rgba\(9,16,28,\.67\)/);
 for(const content of [html,style,satellite,renderer,js])assert.doesNotMatch(content,/mapillary|panoramax|street[ -]?view|coverage-layer|coverageToggle/i);
 assert.match(renderer,/sourceCache/);
 assert.match(renderer,/deferTileRequests/);
});
test('Removed providers cannot make requests through Render routes or be loaded as pages',()=>{
 const server=read('server.js'),config=read('.env.example'),app=read('public/secure-apps.js');
 assert.doesNotMatch(server,/api\/(?:mapillary|panoramax)/);
 assert.doesNotMatch(config,/MAPILLARY_CLIENT_TOKEN/);
 assert.doesNotMatch(app,/panoramax|mapillary|street-level/i);
 for(const name of ['public/secure-mapillary.html','public/secure-panoramax.html','public/mapillary-vector.js'])assert.equal(fs.existsSync(path.join(root,name)),false);
 assert.match(app,/secure-maps\.html/);
 assert.match(read('public/secure-search.html'),/Open in Secure Maps/);
});

test('Search results appear under the search bar and selecting one recenters the existing map',async()=>{
 class FakeElement{
  constructor(id=''){this.id=id;this.children=[];this.events=new Map();this.attributes={};this.dataset={};this.className='';this.textContent='';this.value='';this.hidden=true;this.style={};this.classList={toggle(){},add(){},remove(){}};}
  addEventListener(name,handler){this.events.set(name,handler)}
  fire(name,payload={}){const handler=this.events.get(name);assert.ok(handler,`Missing ${name} event on ${this.id}`);return handler(payload)}
  setAttribute(k,v){this.attributes[k]=v}
  replaceChildren(...items){this.children=items}
  append(...items){this.children.push(...items)}
  contains(target){return this===target}
 }
 const nodes=new Map();
 for(const name of ['satelliteFrame','placeForm','placeInput','searchDropdown','searchArea','placeResults','placesHeading','placeStatus','closeSearch'])nodes.set(name,new FakeElement(name));
 const sent=[];
 nodes.get('satelliteFrame').contentWindow={postMessage:(data,origin)=>sent.push({data,origin})};
 const document={
  documentElement:{style:{setProperty(){},removeProperty(){}},},
  getElementById:(name)=>{assert.ok(nodes.has(name),name);return nodes.get(name)},
  createElement:(tag)=>new FakeElement(tag),
  addEventListener(){}
 };
 const events=new Map(),store=new Map(),requests=[];
 const origin='http://local.test';
 const location={search:'',href:origin+'/secure-maps.html',origin};
 const sandbox={
  document,location,URL,URLSearchParams,Number,String,Math,encodeURIComponent,
  localStorage:{getItem:key=>store.get(key)||null,setItem:(key,val)=>store.set(key,val)},
  window:{addEventListener:(name,fn)=>events.set(name,fn)},
  fetch: async url=>{
   requests.push(url);
   return {ok:true,json:async()=>({items:[{lat:50.1163,lng:-122.9574,name:'Whistler, BC',kind:'City'}]})};
  }
 };
 vm.runInNewContext(read('public/secure-maps.js'),sandbox);
 assert.ok(nodes.get('satelliteFrame').src.includes('satellite-map.html'));
 assert.ok(!nodes.get('satelliteFrame').src.includes('panoramax'));
 events.get('message')({origin,source:nodes.get('satelliteFrame').contentWindow,data:{type:'secure-browser:satellite-ready'}});
 assert.equal(sent.length,1);
 nodes.get('placeInput').value='Whistler';
 nodes.get('placeForm').fire('submit',{preventDefault(){}});
 await new Promise(setImmediate);
 assert.equal(requests.length,1);
 assert.equal(nodes.get('searchDropdown').hidden,false);
 assert.equal(nodes.get('placeResults').children.length,1);
 nodes.get('placeResults').children[0].fire('click');
 assert.equal(nodes.get('searchDropdown').hidden,true);
 assert.equal(sent.length,2);
 assert.equal(sent[1].data.lat,50.1163);
 assert.equal(sent[1].data.lng,-122.9574);
 // The iframe may announce ready later, but must not reset map position.
 events.get('message')({origin,source:nodes.get('satelliteFrame').contentWindow,data:{type:'secure-browser:satellite-ready'}});
 assert.equal(sent.length,2);
});
