'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
const themeJs=fs.readFileSync(path.join(root,'public/theme-studio.js'),'utf8');
const colorDef=themeJs.slice(themeJs.indexOf(' const COLOR_FIELDS='),themeJs.indexOf(' let modal='));
const validators=themeJs.slice(themeJs.indexOf(' const safeColor='),themeJs.indexOf(' function makeId()'));
assert(colorDef.startsWith(' const COLOR_FIELDS='));
const evaluate=new Function(`${colorDef}\n${validators}\nreturn {cleanTheme,DEFAULT};`);
const {cleanTheme,DEFAULT}=evaluate();
const old={name:'Legacy theme',style:'glass',opacity:78,radius:23,dim:20,wallpaperFit:'cover',wallpaperPosition:'center',colors:{accent:'#3399ff',background:'#101a2e',surface:'#203451',text:'#f4f8ff',muted:'#b5c8de',border:'#829eb5',tabs:'#344d75',buttonText:'#ffffff'}};
const legacy=cleanTheme(old);
assert.equal(legacy.colors.toolbar,old.colors.surface,'older SBT themes must fall back to surface color');
assert.equal(legacy.colors.toolbarText,old.colors.text,'older SBT themes must fall back to text color');
assert.equal(legacy.tabRadius,12);
assert.equal(legacy.motion,'normal');assert.equal(legacy.iconSet,'classic');
const upgraded=cleanTheme({...DEFAULT,colors:{...DEFAULT.colors,toolbar:'#123456'},font:'mono',motion:'off',searchPosition:'upper',tabRadius:22});
assert.equal(upgraded.colors.toolbar,'#123456');assert.equal(upgraded.font,'mono');assert.equal(upgraded.motion,'off');assert.equal(upgraded.tabRadius,22);
assert.throws(()=>cleanTheme({...DEFAULT,colors:{...DEFAULT.colors,toolbar:'url(javascript:alert(1))'}}),/Invalid color/);
assert.throws(()=>cleanTheme({...DEFAULT,tabRadius:100}),/Invalid tab/);

const server=fs.readFileSync(path.join(root,'server.js'),'utf8');
const fn=server.slice(server.indexOf('function sendError(res, err) {'),server.indexOf('\nmodule.exports = app;'));
assert(fn.startsWith('function sendError'));
const sendError=vm.runInNewContext(`${fn}\nsendError;`);
function fakeResponse(){return {headersSent:false,headers:{},removeHeader(){},set(){return this;},status(n){this.statusCode=n;return this;},type(s){this.mime=s;return this;},send(s){this.body=s;return this;}};}
for(const status of [403,404,502,504]){
 const res=fakeResponse();sendError(res,{status,message:'Error </script><script>alert(1)</script>'});
 assert.equal(res.statusCode,status);assert(res.body.includes(`status:${status}`));
 assert(!res.body.includes('<script>alert(1)</script>'));
 const match=res.body.match(/<script>([\s\S]*?)<\/script>/);assert(match);
 new vm.Script(match[1]);
}
const errPage=fs.readFileSync(path.join(root,'public/error.html'),'utf8');
for(const status of [403,404,500,502,504])assert(errPage.includes(`${status}:[`));
assert(errPage.includes('secure-browser:error-action'));
const search=fs.readFileSync(path.join(root,'public/secure-search.html'),'utf8');
for(const part of ['summary-enhancements','data-summary-view="detailed"','summary-followup-list','summary-copy'])assert(search.includes(part));
console.log('PASS: legacy and upgraded .SBT, valid appearance settings, safe server error stubs, and Input Summary UI.');
