'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('Secure Maps has a floating search, dropdown results, no sidebar/header or key editor',()=>{
 const html=read('public/secure-maps.html'),css=read('public/secure-maps.css'),js=read('public/secure-maps.js');
 for(const id of ['placeForm','placeInput','searchDropdown','placeResults','coverageToggle','satelliteFrame','photoPanel','photoFrame'])assert.match(html,new RegExp(`id="${id}"`));
 assert.match(html,/id="searchDropdown"[^>]*hidden/);
 assert.doesNotMatch(html,/class="sm-sidebar"|class="sm-topbar"|id="mapillaryDialog"|id="mapillarySettings"|id="shareMap"/);
 assert.match(css,/\.sm-search-area\{position:absolute/);
 assert.match(css,/\.sm-results\{overflow-y:auto/);
 assert.match(css,/\.sm-coverage-button\{position:absolute/);
 assert.match(css,/backdrop-filter:blur\(20px\)/);
 assert.match(js,/function openSearchResults\(\)/);
 assert.match(js,/function closeSearchResults\(\)/);
 assert.match(js,/\$\('placeResults'\)\.replaceChildren\(\)/);
 assert.doesNotMatch(js,/showModal\(|mapillaryDialog|localStorage\.getItem\('secure-maps:mapillary-token'\)/);
});
test('Mapillary remains configured, Esri control buttons are black glass',()=>{
 const js=read('public/secure-maps.js'),map=read('public/satellite-map.html');
 assert.match(js,/const DEFAULT_MAPILLARY_TOKEN=/);
 assert.match(js,/sendMapillaryToken\(\)/);
 assert.match(js,/setCoverage\(!coverageEnabled\)/);
 assert.match(map,/background:rgba\(9,16,28,\.67\)/);
 assert.match(map,/backdrop-filter:blur\(20px\)/);
});
