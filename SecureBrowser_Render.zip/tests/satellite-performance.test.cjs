'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const M=require('../public/satellite-math.js');
const script=fs.readFileSync(path.join(__dirname,'../public/satellite-map.js'),'utf8');

function harness(initialZoom=14){
 const pendingTimers=new Map();let nextTimer=0;const images=[];const elements=new Map();
 class El{
  constructor(tag){this.tagName=tag;this.style={};this.children=[];this.parentNode=null;this.events=new Map();this.clientWidth=640;this.clientHeight=440;this.hidden=false;this.classList={add(){},remove(){}};}
  appendChild(el){this.children.push(el);el.parentNode=this;return el}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(x=>x!==this);this.parentNode=null;}
  get isConnected(){return !!this.attached||!!(this.parentNode&&this.parentNode.isConnected)}
  addEventListener(type,fn){this.events.set(type,fn)}
  fire(type,payload={}){assert(this.events.has(type),type);this.events.get(type)(payload)}
  setAttribute(name,value){this[name]=value}
  getBoundingClientRect(){return{left:0,top:0}}
  getContext(){const ctx={draws:[],clearRect(){},drawImage(...args){this.draws.push(args)}};this.ctx=ctx;return ctx;}
  closest(){return null}
 }
 const names=['satellite-map','imagery-layer','labels-layer','marker','marker-label','load-warning','fallback-link','labels-toggle','zoom-in','zoom-out','recenter'];
 for(const name of names){const el=new El(name);el.attached=true;elements.set(name,el)}
 const doc={getElementById:id=>elements.get(id),createElement:tag=>{const el=new El(tag);if(tag==='img')images.push(el);return el}};
 const window={SatelliteMath:M,addEventListener(){},parent:{postMessage(){}}};
 vm.runInNewContext(script,{window,document:doc,location:{search:`?lat=49.2827&lng=-123.1207&zoom=${initialZoom}`,origin:'http://localhost'},URLSearchParams,Number,String,Math,Map,Set,Date,encodeURIComponent,
 setTimeout:(fn,ms)=>{const id=++nextTimer;pendingTimers.set(id,{fn,ms});return id},
 clearTimeout:id=>pendingTimers.delete(id),
 ResizeObserver:class{observe(){}}
 },{filename:'satellite-map.js'});
 return {elements,images,runTimers(ms){for(const[id,t]of [...pendingTimers])if(t.ms===ms){pendingTimers.delete(id);t.fn()}},networkCount(){return images.filter(i=>typeof i.src==='string'&&i.src.includes('?blankTile=false')).length},imagery(){return elements.get('imagery-layer')}};
}

test('zoom displays existing satellite tiles immediately and delays intermediate network loads',()=>{
 const h=harness(14);
 const initialRequests=h.networkCount();
 assert(initialRequests>8,'source images requested on initial load');
 for(const img of h.images)if(img.src?.includes('?blankTile=false'))img.onload?.();
 h.elements.get('zoom-in').fire('click');
 assert.equal(h.networkCount(),initialRequests,'do not download tiles until short zoom gesture settles');
 assert(h.imagery().children.some(tile=>tile.children[0].ctx.draws.length),'zoomed in view should immediately crop cached parent imagery');
 h.runTimers(115);
 assert(h.networkCount()>initialRequests,'once zoom settles the new level can download');
 for(const img of h.images)if(img.src?.includes('/tile/15/'))img.onload?.();
 const at15=h.networkCount();
 h.elements.get('zoom-out').fire('click');
 assert(h.imagery().children.some(tile=>tile.children[0].ctx.draws.length),'zoom out should display cached imagery immediately');
 h.runTimers(115);
 assert.equal(h.networkCount(),at15,'zooming back to a previously visited view reuses cached tiles');
});

test('adjacent overzoom view tiles coalesce fallback downloads of a shared source',()=>{
 const h=harness(18);
 const initial=h.images.filter(i=>i.src?.includes('/tile/18/'));
 assert(initial.length>0);
 // Every high-detail tile fails: siblings should subscribe to the same parent
 // instead of each downloading an identical parent image.
 for(const img of initial)img.onerror?.();
 const parents=h.images.filter(i=>i.src?.includes('/tile/17/'));
 const keys=parents.map(img=>img.src);
 assert(keys.length>0);
 assert.equal(keys.length,new Set(keys).size,'each shared parent tile fetched once');
});
