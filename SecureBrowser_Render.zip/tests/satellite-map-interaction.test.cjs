 'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const M = require('../public/satellite-math.js');

class Element {
  constructor(tagName) {
    this.tagName = tagName;
    this.style = {};
    this.children = [];
    this.parentNode = null;
    this.events = new Map();
    this.clientWidth = 512;
    this.clientHeight = 512;
    this.hidden = false;
    this.classList = { add() {}, remove() {} };
  }
  appendChild(element) { this.children.push(element); element.parentNode = this; return element; }
  remove() {
    if (this.parentNode) this.parentNode.children = this.parentNode.children.filter(e => e !== this);
    this.parentNode = null;
  }
  get isConnected() { return Boolean(this.attached || (this.parentNode && this.parentNode.isConnected)); }
  addEventListener(name, cb) { this.events.set(name, cb); }
  setAttribute(name, value) { this[name] = value; }
  getBoundingClientRect() { return { left: 0, top: 0 }; }
  getContext() {
    this.ctx = {
      clearRect() {},
      drawImage(...args) { this.lastDraw = args; }
    };
    return this.ctx;
  }
  closest() { return null; }
  fire(name, details = {}) { assert(this.events.has(name), `Missing ${name} on ${this.tagName}`); this.events.get(name)(details); }
}
const elements = new Map();
for (const id of [
  'satellite-map', 'imagery-layer', 'labels-layer', 'marker', 'marker-label',
  'load-warning', 'fallback-link', 'labels-toggle', 'zoom-in', 'zoom-out', 'recenter'
]) elements.set(id, new Element(id));
for (const element of elements.values()) element.attached = true;
const requestedImages = [];
const document = {
  getElementById(id) { assert(elements.has(id), id); return elements.get(id); },
  createElement(name) {
    const element = new Element(name);
    if (name === 'img') requestedImages.push(element);
    return element;
  }
};
const map = elements.get('satellite-map');
const imagery = elements.get('imagery-layer');
const labels = elements.get('labels-layer');
const win = {
  SatelliteMath: M,
  addEventListener() {},
  parent: { postMessage() {} }
};
const code = fs.readFileSync(path.join(__dirname, '../public/satellite-map.js'), 'utf8');
vm.runInNewContext(code, {
  window: win, document, location: { search: '?lat=50.1163&lng=-122.9574&zoom=23', origin: 'http://localhost' },
  URLSearchParams, Number, String, Math, Map, Set, encodeURIComponent,
  setTimeout() { return 1; }, clearTimeout() {},
  ResizeObserver: class { observe() {} }
}, { filename: 'satellite-map.js' });
assert.equal(elements.get('zoom-in').disabled, true, 'Zoom-in control must stop at level 23');
assert.equal(elements.get('labels-toggle').disabled, true, 'Overzoomed map should not display stretched place names');
assert(imagery.children.length > 0, 'Map should render imagery tiles');
assert.equal(labels.children.length, 0, 'Labels should be hidden at very close zoom');
const tile = imagery.children[0];
const canvas = tile.children[0];
assert.equal(canvas.tagName, 'canvas', 'Extreme zoom should draw within a fixed-size canvas');
assert.equal(canvas.width, 256);
assert.equal(canvas.height, 256);
const image = requestedImages[0];
// Inspect tile image via canvas drawImage after simulating an image response.

assert(image.src.includes('/tile/23/'), 'Initially request actual high-resolution imagery');
assert(image.src.endsWith('?blankTile=false'), 'Missing Esri tiles must return errors, not a successful image of a missing-data notice');
image.onerror();
assert(image.src.includes('/tile/22/'), 'Missing 23-level tile retries level 22');
assert(image.src.endsWith('?blankTile=false'), 'Every ancestor fallback must reject missing-data placeholder images');
assert.equal(image.style.width, undefined, 'Canvas fallback must not create giant CSS tiles');
for (let z = 21; z >= 19; z--) {
  image.onerror();
  assert(image.src.includes(`/tile/${z}/`), `Fallback must continue to level ${z}`);
}
image.onload();
assert.equal(canvas.ctx.lastDraw[3], 16, 'Level 19 tile crop should use 16 source pixels at level 23');
assert.equal(canvas.ctx.lastDraw[7], 256, 'Crop must render into a 256px display tile');
elements.get('zoom-out').fire('click');
assert.equal(elements.get('zoom-in').disabled, false, 'Zoom-in reenabled after zooming out');
assert(imagery.children.length > 0);
for (let z = 22; z > 19; z--) elements.get('zoom-out').fire('click');
assert.equal(elements.get('labels-toggle').disabled, false, 'Labels can return at level 19');
assert(labels.children.length > 0, 'Place label tile layer restored at normal zoom');
console.log('PASS: Satellite zoom to level 23, real tiles followed by ancestor fallback, clean map controls, and label visibility.');
