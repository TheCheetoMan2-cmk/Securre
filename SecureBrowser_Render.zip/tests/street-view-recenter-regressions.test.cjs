'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname,'..');
const get = name=>fs.readFileSync(path.join(root,name),'utf8');

function harness(){
 const handlers = {}, posted=[];
 const state=new Map();
 const classes=initial=>{
  const c=new Set(initial);
  return {contains:s=>c.has(s),add:s=>c.add(s),remove:s=>c.delete(s),toggle:(s,on)=>{if(on)c.add(s);else c.delete(s)}};
 };
 const elements=new Map();
 function element(id){
  if(elements.has(id))return elements.get(id);
  const e={id,classList:classes(id==='photoPanel'?['sm-hide']:[]),style:{},dataset:{},children:[],value:'',hidden:true,attributes:{},textContent:'',src:'',contentWindow:null,
   addEventListener:(name,cb)=>{(e.listeners??={})[name]=cb},
   setAttribute:(name,value)=>{e.attributes[name]=value},
   replaceChildren(){e.children=[]},
   contains:()=>false,
   blur(){},getBoundingClientRect(){return {x:0,y:0}},
   append(c){e.children.push(c)}
  };
  if(id==='satelliteFrame')e.contentWindow={postMessage:(message,origin)=>posted.push({message,origin})};
  elements.set(id,e);return e;
 }
 const window={addEventListener:(name,cb)=>{(handlers[name]??=[]).push(cb)}};
 const document={documentElement:{style:{setProperty(){},removeProperty(){},fontFamily:''}},getElementById:element,addEventListener:()=>{},createElement:()=>({classList:classes([]),addEventListener(){},setAttribute(){},append(){}})};
 const location={origin:'https://securebrowser.example',href:'https://securebrowser.example/secure-maps.html?lat=50.1163&lng=-122.9574&name=Whistler',search:'?lat=50.1163&lng=-122.9574&name=Whistler'};
 const sandbox={window,document,location,URL,URLSearchParams,Date,Math,JSON,Number,String,Array,Object,setTimeout,clearTimeout,
   localStorage:{getItem:k=>state.get(k)||null,setItem:(k,v)=>state.set(k,v)},
   fetch:()=>Promise.resolve({ok:true,json:async()=>({clientToken:''})}),
   navigator:{clipboard:{writeText:async()=>{}}},console};
 vm.runInNewContext(get('public/secure-maps.js'),sandbox,{filename:'secure-maps.js'});
 const dispatch=(type,data)=>{
  const event={origin:location.origin,source:element('satelliteFrame').contentWindow,data:{type,...data}};
  for(const handler of handlers.message||[])handler(event);
 };
 return {posted,element,dispatch};
}

test('map READY does not bounce HELLO and reset the center while dragging',()=>{
 const h=harness();
 h.dispatch('secure-browser:satellite-ready');
 assert.ok(h.posted.some(e=>e.message.type==='secure-maps:coverage-toggle'));
 assert.ok(h.posted.some(e=>e.message.type==='secure-maps:mapillary-token'));
 assert.equal(h.posted.some(e=>e.message.type==='secure-maps:hello'),false);
 assert.equal(h.posted.some(e=>e.message.type==='secure-browser:satellite-center'),false);
 h.element('satelliteFrame').listeners.load();
 assert.equal(h.posted.filter(e=>e.message.type==='secure-maps:hello').length,1);
 h.dispatch('secure-browser:satellite-ready');
 assert.equal(h.posted.filter(e=>e.message.type==='secure-maps:hello').length,1);
 assert.equal(h.posted.filter(e=>e.message.type==='secure-browser:satellite-center').length,0);
});

test('Mapillary failure status does not throw an undeclared-variable error',()=>{
 const h=harness();
 assert.doesNotThrow(()=>h.dispatch('secure-maps:mapillary-status', {count:0,failed:true,error:'Coverage temporarily unavailable'}));
 assert.match(h.element('coverageStatus').textContent,/Mapillary unavailable/);
});

test('blue road tiles prioritize sequence geometry; panning does not abort all pending tiles',()=>{
 const map=get('public/satellite-map.js');
 assert.match(map,/const z=Math\.min\(13,Math\.max\(0,zoom\)\)/);
 assert.match(map,/const sourceZ=Math\.min\(13,Math\.max\(0,zoom\)\)/);
 const schedule=map.split('function scheduleMapillary(){')[1].split('async function loadMapillary(){')[0];
 assert.doesNotMatch(schedule,/\.abort\(\)|mapillaryGen\+\+/);
 assert.match(map,/bindCoverageTap\(el,/);
 assert.match(map,/viewport\.setPointerCapture\(e\.pointerId\)/);
 assert.doesNotMatch(map,/addEventListener\('pointerdown',e=>e\.stopPropagation\(\)\)/);
 assert.match(get('server.js'),/api\/mapillary\/nearest-image/);
});

test('Whistler coverage tile geometry projects to the map viewport after overzoom',()=>{
 const M=require('../public/satellite-math');
 const lat=50.1163,lng=-122.9574;
 const viewZoom=16,sourceZoom=13;
 const c=M.toPixel(lat,lng,sourceZoom),p=M.toPixel(lat,lng,viewZoom);
 const x=Math.floor(c.x/256),y=Math.floor(c.y/256),fractionX=c.x/256-x,fractionY=c.y/256-y;
 const ratio=2**(viewZoom-sourceZoom);
 const sx=650+((x+fractionX)*256*ratio-p.x);
 const sy=450+((y+fractionY)*256*ratio-p.y);
 assert.ok(Math.abs(sx-650)<.1);
 assert.ok(Math.abs(sy-450)<.1);
});
