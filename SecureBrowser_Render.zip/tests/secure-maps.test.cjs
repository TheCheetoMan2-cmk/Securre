'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {test}=require('node:test');
const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const core=require('../secure-panoramax-core');
const realItem=(overrides={})=>({
  id:'187baaa9-98f9-4234-8160-86b7f2ee18f7',collection:'7fb2060e-b00c-4dee-bfd1-76166664cfc4',
  geometry:{type:'Point',coordinates:[2.35,48.85]},properties:{datetime:'2025-07-01T09:00:00Z'},...overrides
});
test('Apps launcher includes only approved app routes and opens in browser tabs',()=>{
 const apps=require('../public/secure-apps.js');assert.equal(apps.length,1);
 assert.equal(apps[0].name,'Secure Maps');assert.equal(apps[0].url,'secure-maps.html');
 const page=read('public/index.html');assert.match(page,/id="openApps"/);assert.match(page,/id="appsLauncher"/);
 assert.match(page,/function isSecureMapsUrl\(/);assert.match(page,/\|\|isSecureMapsUrl\(url\)/);
 assert.match(page,/newTab\(new URL\(allowed.url,location.href\).href\)/);
});
test('Panoramax search bbox is bounded and rejects invalid input',()=>{
 assert.equal(core.validBBox('2.3,48.8,2.4,48.9'),'2.3,48.8,2.4,48.9');
 for(const x of ['abc','0,0,360,90','5,5,4,8','2,2,2.4,2.5','NaN,1,2,3','0,0,0,0'])assert.equal(core.validBBox(x),null);
});
test('Panoramax normalizes STAC point imagery without unsafe ids',()=>{
 const data={features:[realItem(),realItem({id:'<script>'}),realItem({geometry:{type:'Polygon',coordinates:[]}}),realItem({geometry:{type:'Point',coordinates:[200,90]}})]};
 assert.deepEqual(core.normalize(data),[{id:'187baaa9-98f9-4234-8160-86b7f2ee18f7',sequence:'7fb2060e-b00c-4dee-bfd1-76166664cfc4',lat:48.85,lng:2.35,date:'2025-07-01T09:00:00Z'}]);
});
test('Panoramax requests official public STAC API with limited bbox and caches results',async()=>{
 let calls=0;const fn=async u=>{calls++;assert.equal(u.hostname,'api.panoramax.xyz');assert.equal(u.pathname,'/api/search');assert.equal(u.searchParams.get('limit'),'180');assert.equal(u.searchParams.get('bbox'),'2.1,48.8,2.2,48.9');return {ok:true,json:async()=>({features:[realItem()]})}};
 const first=await core.nearby('2.1,48.8,2.2,48.9',{fetch:fn});const second=await core.nearby('2.1,48.8,2.2,48.9',{fetch:fn});
 assert.equal(calls,1);assert.equal(first.features.length,1);assert.deepEqual(second,first);
});
test('full-screen app links real satellite map and official Panoramax photo viewer',()=>{
 const ui=read('public/secure-maps.html'),map=read('public/satellite-map.js'),viewer=read('public/secure-panoramax.html');
 assert.match(ui,/id="placeResults"/);assert.match(ui,/id="satelliteFrame"/);assert.match(ui,/id="photoFrame"/);
 assert.match(ui,/id="streetAction"/);assert.match(ui,/id="coverageToggle"/);
 assert.match(map,/sourceTile/);assert.match(map,/secure-maps:panoramax-select/);assert.match(map,/secure-maps:coverage-toggle/);
 assert.match(map,/api\/panoramax\/nearby/);assert.match(map,/if\(distanceMeters\(a,b\)>85\)continue/);
 assert.match(viewer,/<pnx-photo-viewer/);assert.match(viewer,/api\.panoramax\.xyz\/api/);
 assert.match(read('server.js'),/app\.get\('\/api\/panoramax\/nearby'/);
});
test('search Maps tab also offers Secure Maps and existing features remain',()=>{
 assert.match(read('public/secure-search.html'),/Open in Secure Maps/);
 assert.match(read('public/index.html'),/error-demo\.js/);
 assert.match(read('public/index.html'),/theme-studio\.js/);
 assert.match(read('public/satellite-math.js'),/MAX_ZOOM = 23/);
 assert.ok(fs.existsSync(path.join(root,'Dockerfile')));
 assert.ok(fs.existsSync(path.join(root,'render.yaml')));
});
