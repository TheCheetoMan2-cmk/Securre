'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
const demoSource=fs.readFileSync(path.join(root,'public/error-demo.js'),'utf8');
const sandbox={URL};vm.runInNewContext(demoSource,sandbox);
const D=sandbox.SB_ERROR_DEMO;
assert(D,'Error demo helper available');
assert.equal(D.url,'https://err.test/');
for(const input of ['ERR.test','err.test','ERR.TEST/','https://ERR.test/','http://err.test/'])assert(D.isDemoInput(input),input);
for(const invalid of ['test ERR.test','err.test.evil.com','https://err.test.evil.com','http://err.test/about','https://err.test/?x=1','https://err.test:8080/'])assert(!D.isDemoInput(invalid),invalid);
assert(D.isDemoSearchUrl('http://localhost:10000/secure-search.html?q=ERR.test','http://localhost:10000/secure-search.html'));
assert(!D.isDemoSearchUrl('https://evil.test/secure-search.html?q=ERR.test','http://localhost:10000/secure-search.html'));
const want=[404,403,401,408,410,429,500,502,503,504,0];
assert.deepEqual(Array.from(D.codes),want);
let i=0;
for(let c=0;c<want.length*3;c++){assert.equal(D.codes[i],want[c%want.length]);i=D.next(i);}
assert.equal(i,0);
const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
assert(html.includes('src="error-demo.js?v=20261106"'));
for(const text of ['ERROR_DEMO.isDemoInput(q)?ERROR_DEMO.url:searchUrl(q,page,kind)',"add('Reload',()=>reloadTab(t)","function reloadTab(tab)","if(demoResume===null)newTab();else newTab(ERROR_DEMO.url,false,{demoIndex:demoResume});","saveErrorDemoSession()"]){assert(html.includes(text),text);}
const err=fs.readFileSync(path.join(root,'public/error.html'),'utf8');
for(const text of ['demo=params.get(\'demo\')===\'1\'','Next Error','demo-counter','performance.getEntriesByType(\'navigation\')','external.hidden=true'])assert(err.includes(text),text);
for(const file of ['public/index.html','public/error.html']){
 const source=fs.readFileSync(path.join(root,file),'utf8');
 const rx=/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g; let match;
 while((match=rx.exec(source)))if(match[1].trim())new vm.Script(match[1],{filename:file});
}
console.log('PASS: ERR.test matching, search interception, all error types and wraparound, refresh routes, safe page JS syntax.');
