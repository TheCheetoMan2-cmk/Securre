'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const read=name=>fs.readFileSync(path.join(__dirname,'..',name),'utf8');

test('Mapillary coverage tiles use a bounded same-origin relay with direct fallback',()=>{
 const server=read('server.js'),map=read('public/satellite-map.js');
 assert.match(server,/app\.get\('\/api\/mapillary\/tile\/:z\/:x\/:y'/);
 assert.match(server,/Number\.isSafeInteger/);
 assert.match(server,/tiles\.mapillary\.com\/maps\/vtp\/mly1_public\/2/);
 assert.match(server,/AbortSignal\.timeout\(10000\)/);
 assert.match(map,/localUrl=`\/api\/mapillary\/tile\/\$\{t\.z\}\/\$\{t\.x\}\/\$\{t\.y\}`/);
 assert.match(map,/directUrl=`https:\/\/tiles\.mapillary\.com\/maps\/vtp\/mly1_public\/2/);
 assert.match(map,/Mapillary client token was rejected/);
});

test('Street View coverage is on at startup and a cached iframe receives map settings',()=>{
 const parent=read('public/secure-maps.js'),child=read('public/satellite-map.js');
 assert.match(parent,/let coverageEnabled=true/);
 assert.doesNotMatch(parent,/coverageEnabled=localStorage\.getItem/);
 assert.match(parent,/map\.addEventListener\('load',syncMapConfig\)/);
 assert.match(parent,/type:'secure-maps:coverage-toggle'/);
 assert.match(parent,/type:'secure-maps:mapillary-token'/);
 assert.match(child,/type==='secure-maps:hello'/);
 assert.match(child,/secure-browser:satellite-ready/);
});

test('Actual Mapillary sequences show blue lines, global overview and network errors are visible',()=>{
 const map=read('public/satellite-map.js'),page=read('public/satellite-map.html'),app=read('public/secure-maps.js');
 assert.match(map,/feat\.type!==2/);
 assert.match(map,/tile\.sequence\|\|\[\]/);
 assert.match(map,/tile\.overview\|\|\[\]/);
 assert.match(page,/mapillary-line/);
 assert.match(app,/sm-coverage-error/);
 assert.match(map,/mapillaryRetryTimer=setTimeout/);
});
