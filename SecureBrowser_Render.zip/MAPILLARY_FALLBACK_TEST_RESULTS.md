# Secure Maps Street View coverage fallback checks

- Mapillary Graph API bbox validation: passed (invalid, reversed and overly broad bounds rejected)
- Image and sequence normalization: passed (precise string IDs preserved)
- Official Mapillary endpoint and fields through mock HTTP: passed
- Vector + Graph fallback integration and visible status: passed
- Existing Mapillary/Secure Maps/recenter/satellite performance tests: 25/25 passed
- Existing summary, media, satellite, `.SBT`, `ERR.test` checks: passed
- Live provider responses: **not tested**; external network unavailable in build container
- Full browser/render deployment: **not tested**

Only actual provider-sourced photo coordinates become blue coverage. Esri satellite imagery remains a separate source.
