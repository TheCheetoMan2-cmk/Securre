'use strict';
// Independent, bounded photo-coverage fallback using Mapillary's official Graph API.
// Unlike a generic street map, only real captured image coordinates are returned.
const bboxPattern=/^-?\d{1,3}(?:\.\d{1,8})?,-?\d{1,2}(?:\.\d{1,8})?,-?\d{1,3}(?:\.\d{1,8})?,-?\d{1,2}(?:\.\d{1,8})?$/;
function parseBbox(raw){
  if(typeof raw!=='string'||raw.length>100||!bboxPattern.test(raw))return null;
  const p=raw.split(',').map(Number),[west,south,east,north]=p;
  if(p.some(v=>!Number.isFinite(v))||west<-180||east>180||south<-85||north>85||west>=east||south>=north||east-west>.12||north-south>.12)return null;
  return p;
}
function parsePhotos(input){
  const seen=new Set(),out=[];
  for(const item of Array.isArray(input?.data)?input.data:[]){
    const id=String(item?.id||'');
    const coordinates=item?.geometry?.coordinates || item?.computed_geometry?.coordinates;
    if(!/^\d{4,25}$/.test(id)||seen.has(id)||!Array.isArray(coordinates)||coordinates.length!==2)continue;
    const [lng,lat]=coordinates.map(Number);
    if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>85||Math.abs(lng)>180)continue;
    const rawSequence=item.sequence;
    const sequence=typeof rawSequence==='string'?rawSequence:String(rawSequence?.id||'');
    out.push({id,lat,lng,sequence:sequence.slice(0,100),capturedAt:Number(item.captured_at)||0});
    seen.add(id);if(out.length>=600)break;
  }
  return out;
}
function createFetcher(request=fetch){
  return async function fetchPhotos(rawBbox,token){
    const bbox=parseBbox(rawBbox);
    if(!bbox){const e=Error('Invalid map bounds');e.status=400;throw e;}
    if(!/^[A-Za-z0-9_|.-]{12,500}$/.test(token||'')){const e=Error('Mapillary token missing');e.status=503;throw e;}
    const url=new URL('https://graph.mapillary.com/images');
    url.searchParams.set('bbox',bbox.join(','));
    url.searchParams.set('fields','id,geometry,sequence,captured_at');
    url.searchParams.set('limit','600');
    url.searchParams.set('access_token',token);
    let response;
    try{response=await request(url.toString(),{headers:{Accept:'application/json'},signal:AbortSignal.timeout(8500)});}
    catch{const e=Error('Mapillary photo service unavailable');e.status=502;throw e;}
    if(!response.ok){const e=Error([401,403].includes(response.status)?'Mapillary token rejected':response.status===429?'Mapillary rate limited':'Mapillary photo service unavailable');e.status=[401,403,429].includes(response.status)?response.status:502;throw e;}
    let json;
    try{json=await response.json();}catch{const e=Error('Invalid Mapillary response');e.status=502;throw e;}
    return {photos:parsePhotos(json),truncated:Array.isArray(json.data)&&json.data.length>=600};
  };
}
module.exports={parseBbox,parsePhotos,createFetcher};
